import {applyConfigSchema} from '../_host/config-schema.mjs';
import {parameters} from '../_host/schema.mjs';

const field=(type,description,value,hint='')=>({type,description,default:value,group:'安卓模拟器',hint});
export const androidSchema={
  web_enabled:field('bool','允许网页测试对话',true,'仅已认证的网页对话可使用；手机工具不开放给 QQ 群聊。'),
  adb_path:field('string','ADB 可执行文件路径','','留空自动查找 PATH、ANDROID_SDK_ROOT / ANDROID_HOME 和常见模拟器目录；不会重启 ADB 服务。'),
  serial:field('string','设备序列号','','填写 adb devices 中的完整序列号，例如 127.0.0.1:16416。不会自动选择其他设备。'),
  app_package:field('string','视频 App 包名','com.ss.android.ugc.aweme','抖音默认包名；只允许打开和观察这个 App。'),
  ffmpeg_path:field('string','FFmpeg 路径','','留空使用项目自带的 FFmpeg，将截图转换为模型可读的 JPEG。'),
  max_videos:{...field('int','每个任务最多浏览条数',5,'第一条加上最多四次上滑；模型不能修改上限。'),slider:{min:1,max:20,step:1}},
  max_task_seconds:{...field('int','单个任务最长秒数',180),slider:{min:15,max:600,step:1}}
};
export function androidConfig(value={}){
  const c=applyConfigSchema(androidSchema,value),fail=()=>{throw Object.assign(Error('安卓配置无效：请检查路径、序列号、包名和范围。'),{status:400});};
  if(Object.keys(c).some(k=>!Object.hasOwn(androidSchema,k)))fail();
  for(const key of ['adb_path','serial','app_package','ffmpeg_path'])if(/[\r\n\0]/.test(c[key]))fail();
  if(c.serial&&!/^[A-Za-z0-9_.:\[\]-]{1,128}$/.test(c.serial))fail();
  if(!/^[A-Za-z][A-Za-z0-9_]*(?:\.[A-Za-z][A-Za-z0-9_]*)+$/.test(c.app_package))fail();
  return c;
}
const args=(p,required=[])=>({...parameters(p),required});
export const androidTools=[
  {name:'android_status',effect:'read',description:'查询指定安卓模拟器的连接、前台 App、浏览上限与停止状态；不会操作手机。',parameters:args({})},
  {name:'android_observe',effect:'read',description:'采样当前手机画面供视觉模型观察，返回真实采样时间和 observation_id。只提供图片，没有音频。先确认是普通视频播放界面；登录、验证码、权限和协议弹窗交给用户处理。上滑前先简短记录本条可见事实。',parameters:args({frames:{type:'integer',minimum:1,maximum:3},interval_seconds:{type:'number',minimum:0.5,maximum:5}})},
  {name:'android_action',effect:'write',description:'只支持打开配置的视频 App，或在最近观察的前台 App 内上滑一次。没有点击、点赞、评论、关注、输入和任意 shell 权限。open_app 每任务一次；next_video 必须提供最近30秒的 observation_id。每个新动作用新的 operation_id。',parameters:args({action:{type:'string',enum:['open_app','next_video']},operation_id:{type:'string',minLength:1,maxLength:64},observation_id:{type:'string',maxLength:64}},['action','operation_id'])}
];
export const androidTemplate={schema:1,kind:'android-device',name:'安卓视频浏览',description:'通过指定 ADB 设备采样手机画面，让视觉模型在条数和时间上限内观看、上滑视频。',version:'1.0.0',source:'// 内置安卓 ADB 执行层，仅观察、打开指定 App 和上滑。\n',trigger:'',priority:0,timeout_ms:10000,
  scope:{private_users:[],groups:[],all_private:false,all_groups:false,require_at:true},config:androidConfig(),config_schema:androidSchema,tools:androidTools};
