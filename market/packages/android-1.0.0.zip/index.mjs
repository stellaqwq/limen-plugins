import { AndroidService } from './service.mjs';
import { androidConfig, androidTemplate, androidSchema, androidTools } from './config.mjs';
import { consumeAndroidSetup } from './local.mjs';

export const template = () => androidTemplate;
export const config = value => androidConfig(value);
export const schema = () => androidSchema;
export const tools = () => structuredClone(androidTools);

export function create(ctx) {
  const service = new AndroidService({ store: ctx.store, run: ctx.overrides.androidRun });
  service.pluginFor = (event, job) => ctx.plugins.find('android-device', event, job);
  return service;
}

export function visible(plugin, { job }) {
  return plugin.enabled && job?.channel === 'web' && !!plugin.config.web_enabled;
}

export async function setup(ctx) {
  try { await consumeAndroidSetup(ctx.plugins); }
  catch { ctx.log?.('warn', 'android_setup_unavailable'); }
}
