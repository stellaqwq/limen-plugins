import {readFile,writeFile,mkdir,rename} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {androidConfig} from './config.mjs';
import {runtimeDir} from '../_host/paths.mjs';

export const androidRoot=runtimeDir('android');
export async function applyAndroidSetup(plugins,patch){
  const old=plugins.find('android-device');let p=old||await plugins.install({kind:'android-device'});
  p=await plugins.save({id:p.id,revision:p.revision,plugin:{...p,config:androidConfig({...p.config,...patch})}});
  if(!old)p=await plugins.toggle({id:p.id,revision:p.revision,enabled:true});
  return {id:p.id,enabled:p.enabled,serial:p.config.serial,max_videos:p.config.max_videos};
}
export async function stageAndroidSetup(config,targetDataDir){
  await mkdir(androidRoot,{recursive:true});
  await writeFile(join(androidRoot,'setup.pending.json'),JSON.stringify({schema:1,target_data_dir:resolve(targetDataDir),config:androidConfig(config)},null,2)+'\n');
}
export async function consumeAndroidSetup(plugins){
  const path=join(androidRoot,'setup.pending.json');let data;
  try{data=JSON.parse(await readFile(path,'utf8'));}catch(e){if(e.code==='ENOENT')return null;throw e;}
  if(data.schema!==1||typeof data.target_data_dir!=='string')throw Error('安卓安装记录无效。');
  if(resolve(data.target_data_dir)!==resolve(plugins.config.dataDir))return null;
  const result=await applyAndroidSetup(plugins,data.config);await rename(path,join(androidRoot,'setup.applied.json'));return result;
}
