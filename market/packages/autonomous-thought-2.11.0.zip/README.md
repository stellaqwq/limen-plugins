# 自主思考 · 独处日记（市场包）

角色会自己挑话题、翻旧日记和近期交流，写一段简短随笔；配置开启后还会主动找你聊天。
**思考本身由独立后台完成**，这个市场包只是宿主侧的指令桥，负责把 `/think` 和「刷/别刷抖音」转过去，再把回执变成一句回复。

## 安装后要做两件事

1. 启动独立包里的「启动」入口，确认后台控制端口（默认 `127.0.0.1:18769`）在跑；
2. 工作台 → 插件 → 新增一个「自主思考」类型的插件，填两项配置：

| 配置 | 说明 |
| --- | --- |
| `daemon_url` | 独立后台地址，只接受 `http://127.0.0.1:<端口>` |
| `control_token` | 与独立包 `data/config.json` 里的 `control_token` 一致 |

令牌不对会被后台按 401 拒掉，聊天里表现为「控制令牌不正确」；后台没起时表现为「独立后台暂未连接」。

## 指令

| 指令 | 作用 |
| --- | --- |
| `/think diary` | 看最近保存的日记 |
| `/think videos` | 看收到的视频/图文摘要 |
| `/think status` | 看今日请求与主动聊天次数 |
| `/think now` | 立即安排一轮思考 |
| `/think pause` / `/think resume` | 暂停 / 恢复自动思考 |
| `/think monitor` | 抖音监听与任务队列 |
| `去刷一会儿抖音` / `别刷了` | 恢复 / 停止后台的浏览任务 |

指令只认一句话开头的那一段：提问、引用、解释和否定式（「不要停止」）都不会误触发。

## 与独立版的差别

- 独立版是 `kind: "script"` 的脚本插件，整段代码住在 `plugin.json` 的 `source` 字段里；市场包的安装器拒绝保留类型 `script`，所以这里改成宿主插件（`index.mjs` 导出 `template` / `config` / `schema` / `create` / `run`）；
- 宿主插件形态下，插件工具（`thought_diary_read` 等）暂不会进入模型工具列表，日记只能通过 `/think` 读取；脚本形态没有这个限制。

## 目录

```
plugin.json   市场与宿主读取的清单（api 1、id/kind = autonomous-thought）
index.mjs     宿主入口：template/config/schema/create/run
service.mjs   指令识别、后台调用、回执整理
config.mjs    配置定义与默认模板
```
