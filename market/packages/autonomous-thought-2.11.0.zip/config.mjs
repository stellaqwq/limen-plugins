// 自主思考 · 市场包配置定义。
// 后台地址与控制令牌是唯一的两个配置项：思考引擎、日记、主动聊天都在独立后台里跑，
// 宿主这边只负责把消息转过去，所以不需要把引擎参数再抄一份。
export const PLUGIN_SCHEMA = {
  daemon_url: {
    type: 'text', description: '独立后台地址', default: 'http://127.0.0.1:18769',
    hint: '只接受 127.0.0.1 的 http 地址，端口与独立包「启动.cmd」打印的控制端口一致（默认 18769）。'
  },
  control_token: {
    type: 'text', secret: true, description: '控制令牌', default: '',
    hint: '填独立包 data/config.json 里的 control_token。留空或填错会被后台拒绝（401），指令不会有回应。'
  }
};

export const PLUGIN_TEMPLATE = {
  schema: 1,
  kind: 'autonomous-thought',
  name: '自主思考 · 独处日记',
  version: '2.11.0',
  description: '把 /think 指令与「刷抖音」开关转给本机独立后台：看日记、看视频摘要、看思考状态、安排下一轮思考。思考本身由独立后台完成，需要先启动独立包。',
  trigger: '',
  priority: 0,
  timeout_ms: 10000,
  scope: { private_users: [], groups: [], all_private: false, all_groups: false, require_at: true },
  config: { daemon_url: PLUGIN_SCHEMA.daemon_url.default, control_token: '' },
  config_schema: PLUGIN_SCHEMA,
  source: '// 自主思考由本机独立后台执行，这里只做指令转发。\n',
  tools: []
};
