// 自主思考 · 独处日记（市场包 / 宿主插件形态）
// 市场包不能用保留类型 script，所以这里把独立版脚本插件的指令层抽成一个宿主插件：
// 消息进来 → 认指令 → 转给 127.0.0.1 的独立后台 → 把回执当成一句回复发回去。
import { applyConfigSchema } from '../_host/config-schema.mjs';
import { PLUGIN_SCHEMA, PLUGIN_TEMPLATE } from './config.mjs';
import { browseControlIntent, callDaemon, failureOf, replyOf, textOf, thinkAction, THINK_HELP } from './service.mjs';

export const template = () => PLUGIN_TEMPLATE;
export const schema = () => PLUGIN_SCHEMA;
export const config = value => applyConfigSchema(PLUGIN_SCHEMA, value ?? {});

export function create(context) {
  return { config: context?.config ?? {}, log: context?.log ?? (() => {}) };
}

export async function run(service, plugin, event, options = {}) {
  const text = textOf(event);
  const action = thinkAction(text);
  const intent = action ? null : browseControlIntent(text);
  if (!action && !intent) return null;

  const settings = plugin?.config ?? service?.config ?? {};
  if (options.mode === 'test' || options.dryRun) {
    return { handled: true, reply: '模拟：识别指令，不调用后台、不生成日记。' };
  }
  if (action === 'help') return { handled: true, reply: THINK_HELP };

  try {
    if (intent) {
      const data = await callDaemon(settings, { action: intent === 'stop' ? 'browse_stop' : 'browse_resume', event }, { signal: options.signal });
      // 开刷成功就不插话，把对话留给后面的模型回复。
      return intent === 'stop' || !data?.ok
        ? { handled: true, reply: data?.reply || '未确认浏览任务状态，请查看监控。' }
        : null;
    }
    const data = await callDaemon(settings, { action, event }, { signal: options.signal });
    return { handled: true, reply: replyOf(action, data) };
  } catch (error) {
    if (options.signal?.aborted) return null;
    return { handled: true, reply: failureOf(error, { intent: Boolean(intent) }) };
  }
}
