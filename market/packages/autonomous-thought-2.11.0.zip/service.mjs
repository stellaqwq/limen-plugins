// 自主思考 · 独立版桥接层。
// 思考、日记、主动聊天都在 127.0.0.1 的独立后台里跑；这里只做三件事：
// 认出用户自己的指令、把它转成一次 POST /plugin、把回执整理成一句回复。
const THINK_TIMEOUT = 3000, BROWSE_TIMEOUT = 8000;

export const THINK_HELP = [
  '/think diary 查看日记',
  '/think videos 查看收到的视频摘要',
  '/think status 查看状态',
  '/think now 立即安排思考',
  '/think pause 暂停',
  '/think resume 恢复',
  '自动思考不需要这些指令。'
].join('\n');

/** 只取文本段：群聊里的 @ 段不该混进指令判断。 */
export function textOf(event) {
  if (!event) return '';
  if (Array.isArray(event.message)) {
    return event.message.filter(segment => segment?.type === 'text')
      .map(segment => String(segment.data?.text ?? '')).join('').trim();
  }
  return String(event.raw_message ?? '').trim();
}

// 只在用户自己开头那一句里认指令：引用的、提问的、解释性的、否定式的都不算。
// 与独立版脚本插件的判断保持一致。
export function browseControlIntent(text = '') {
  const lead = String(text).trim().split(/[，,。！!；;\n]/u)[0].trim();
  if (/[?？]|(?:能不能|能否|可以|怎么|如何|为什么|是否|解释|意思|视频里|他说|她说|说过|不要停止|别停止|不用停止|不要停|别停|不用停|不要别刷)/u.test(lead)) return null;
  const command = lead.replace(/^(?:(?:请|麻烦你?|帮我|你|现在|先|暂时|今天|这会儿)\s*)+/u, '');
  if (/^(?:(?:别|不要|不用|不许|不准)(?:再|继续)?(?:刷|看)(?:抖音(?:视频)?|视频)?(?:了|啦|吧)?|(?:停|停止|暂停)(?:一下)?(?:刷(?:抖音(?:视频)?|视频)?|看(?:抖音(?:视频)?|视频)?|浏览(?:抖音|视频)|抖音))(?:吧|了)?$/u.test(command)) return 'stop';
  if (/^(?:去|继续|恢复|开始|打开)?(?:抖音(?:上|里)?(?:去)?)?(?:刷|看)(?:一会儿?|一下|几条|\d+条|[一二两三四五六七八九十]+条)?(?:抖音(?:视频)?|视频)(?:吧|了)?$/u.test(command)) return 'start';
  return null;
}

/** /think 后面那一段；没有命令时返回 null。 */
export function thinkAction(text = '') {
  const match = String(text ?? '').trim().match(/^\/think(?:\s+(\S+))?\s*$/u);
  return match ? (match[1] || 'help') : null;
}

export class BridgeError extends Error {
  constructor(code, message) { super(message); this.code = code; }
}

function daemonOrigin(config) {
  let url;
  try { url = new URL(String(config?.daemon_url ?? '')); }
  catch { throw new BridgeError('invalid_url', '独立后台地址无效'); }
  // 只允许本机：避免把控制令牌发给任意远端。
  if (url.protocol !== 'http:' || url.hostname !== '127.0.0.1' || url.username || url.password) {
    throw new BridgeError('invalid_url', '独立后台地址无效');
  }
  return url.origin;
}

function withDeadline(ms, signal) {
  const timeout = AbortSignal.timeout(ms);
  if (!signal) return timeout;
  return typeof AbortSignal.any === 'function' ? AbortSignal.any([signal, timeout]) : timeout;
}

export async function callDaemon(config, payload, { signal } = {}) {
  const origin = daemonOrigin(config);
  const budget = String(payload?.action ?? '').startsWith('browse_') ? BROWSE_TIMEOUT : THINK_TIMEOUT;
  let response;
  try {
    response = await fetch(origin + '/plugin', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + String(config?.control_token ?? '') },
      body: JSON.stringify(payload),
      signal: withDeadline(budget, signal),
      redirect: 'error'
    });
  } catch (error) {
    if (error?.name === 'TimeoutError' || error?.name === 'AbortError') throw new BridgeError('timeout', '独立后台响应超时');
    throw new BridgeError('offline', '独立后台未就绪');
  }
  if (response.status === 401 || response.status === 403) throw new BridgeError('unauthorized', '控制令牌不正确');
  if (!response.ok) throw new BridgeError('offline', '独立后台未就绪');
  try { return await response.json(); }
  catch { throw new BridgeError('offline', '独立后台返回了无法解析的内容'); }
}

/** 把后台回执整理成一句能直接发出去的话。 */
export function replyOf(action, data = {}) {
  if (data.reply) return data.reply;
  if (action === 'monitor') {
    const tasks = Array.isArray(data.tasks) ? data.tasks.slice(0, 5) : [];
    return ('抖音监听：' + (data.listener ?? '未启动') + '\n' + tasks.map(task => '#' + task.id + ' ' + task.kind + ' · ' + task.status + (task.reason ? '\n' + task.reason : '')).join('\n')).slice(0, 1900);
  }
  if (action === 'videos') return (Array.isArray(data.recent) ? data.recent.slice(0, 3) : [])
    .map(item => (item.summary || item.reason || item.status) + '\n' + (item.evidence?.url || 'https://www.douyin.com/' + (item.kind === 'image_share' ? 'note/' : 'video/') + item.video_id))
    .join('\n\n').slice(0, 1900) || '还没有视频或图文的阅读记录。';
  if (action === 'diary') return (Array.isArray(data.diary) ? data.diary.slice(0, 3) : [])
    .map(item => item.title + '\n' + item.note).join('\n\n').slice(0, 1900) || '暂时没有保存的日记。';
  if (data.scheduled) return '已安排思考，稍后可查看日记。';
  const status = data.status ?? {};
  return data.error || '自动思考：' + (status.paused ? '暂停' : '运行') +
    '；今日请求 ' + (status.today_requests || 0) + ' 次；主动聊天 ' + (status.today_outreach || 0) + ' 次。';
}

export function failureOf(error, { intent } = {}) {
  if (error?.code === 'invalid_url') return '独立后台地址无效：请在工作台插件设置里填 http://127.0.0.1:<控制端口>。';
  if (error?.code === 'unauthorized') return '控制令牌不正确：请与独立包 data/config.json 里的 control_token 保持一致。';
  if (error?.code === 'timeout') return intent ? '停止或恢复请求超时，请在独立包管理页确认浏览任务状态。' : '独立后台响应超时，稍后再试。';
  return intent ? '停止或恢复请求未获后台确认，请在管理页检查任务状态。' : '独立后台暂未连接，请运行独立包中的「启动」入口。';
}
