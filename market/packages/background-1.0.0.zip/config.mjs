import { applyConfigSchema } from '../_host/config-schema.mjs';

const field = (type, description, value, group, extra = {}) => ({ type, description, default: value, group, ...extra });
const number = (description, value, min, max, group, type, step) =>
  field(type, description, value, group, { slider: { min, max, step } });

export const MODES = ['cover', 'contain', 'tile'];

export const backgroundSchema = {
  enabled: field('bool', '应用背景', true, '背景'),
  mode: field('string', '图片适应方式', 'cover', '背景', {
    options: MODES, hint: 'cover 填满整个窗口（可能裁切）、contain 完整显示、tile 平铺重复。'
  }),
  blur: number('模糊（像素）', 0, 0, 24, '效果', 'int', 1),
  veil: number('白色遮罩', 0.34, 0, 0.9, '效果', 'float', 0.01),
  panel: number('面板不透明度', 0.9, 0.4, 1, '效果', 'float', 0.01)
};

const bounded = (value, min, max) => Number.isFinite(value) && value >= min && value <= max;

export function backgroundConfig(value = {}) {
  const config = applyConfigSchema(backgroundSchema, value);
  if (!bounded(config.blur, 0, 24) || !bounded(config.veil, 0, 0.9) || !bounded(config.panel, 0.4, 1)) {
    throw Object.assign(Error('背景效果数值超出允许范围。'), { status: 400 });
  }
  if (!MODES.includes(config.mode)) throw Object.assign(Error('背景图片适应方式无效。'), { status: 400 });
  return config;
}

export const backgroundTemplate = {
  schema: 1, kind: 'background', name: '背景壁纸', version: '1.0.0',
  description: '上传一张本机图片作为工作台背景，可调整适应方式、模糊、白色遮罩与面板不透明度。图片只保存在本机数据目录，不参与聊天消息处理。',
  source: '// 内置背景壁纸执行层；图片与显示参数由插件管理页维护，不处理聊天消息。\n',
  trigger: '', priority: 0, timeout_ms: 1000,
  scope: { private_users: [], groups: [], all_private: false, all_groups: false, require_at: true },
  // The wallpaper never handles chat messages; web_enabled lets the host accept
  // "enable" without a QQ session scope.
  config: { ...backgroundConfig(), web_enabled: true }, config_schema: backgroundSchema
};
