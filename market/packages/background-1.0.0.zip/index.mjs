import { BackgroundService } from './service.mjs';
import { BackgroundManagement } from './management.mjs';
import { backgroundConfig, backgroundTemplate, backgroundSchema } from './config.mjs';

export const template = () => backgroundTemplate;
export const config = value => backgroundConfig(value);
export const schema = () => backgroundSchema;

export function create(ctx) {
  const service = new BackgroundService({ config: ctx.config, log: ctx.log });
  service.plugins = ctx.plugins;
  ctx.plugins.admins.set('background', new BackgroundManagement(ctx.plugins));
  return service;
}

// Deleting the plugin record removes the wallpaper too, so a later reinstall
// starts from the default appearance instead of resurrecting an old image.
// The host does not await this hook, so cleanup stays synchronous.
export const destroy = service => service?.clearSync?.();
