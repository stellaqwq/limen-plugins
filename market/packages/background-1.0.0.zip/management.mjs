const fail = (message, status = 400) => Object.assign(Error(message), { status });

// The workbench only talks to this surface; the plugin owns the image file and
// the display parameters, so no appearance state leaks into the host settings.
export class BackgroundManagement {
  constructor(plugins) { this.plugins = plugins; }
  get service() {
    const service = this.plugins.service('background');
    if (!service) throw fail('背景壁纸插件包未安装到 plugins 目录，请重新启动服务。', 409);
    return service;
  }
  plugin() { return this.plugins.find('background'); }
  snapshot() { return this.service.snapshot(); }
  image() { return this.service.bytes(); }
  async action(params = {}) {
    if (params?.action === 'upload') {
      if (!this.plugin()) throw fail('请先安装背景壁纸插件，再选择图片。', 409);
      if (typeof params.data !== 'string' || !/^data:image\/(?:png|jpe?g|webp);base64,[a-z0-9+/=\s]+$/i.test(params.data)) {
        throw fail('请选择 PNG、JPEG 或 WebP 图片。');
      }
      return this.service.write({ data: params.data });
    }
    if (params?.action === 'remove') {
      if (!this.plugin()) throw fail('请先安装背景壁纸插件。', 409);
      return this.service.clear();
    }
    if (params?.action === 'save') {
      const plugin = this.plugin();
      if (!plugin) throw fail('请先安装背景壁纸插件。', 409);
      const config = { ...plugin.config };
      if (Object.hasOwn(params, 'enabled')) {
        if (typeof params.enabled !== 'boolean') throw fail('“应用背景”必须是开关值。');
        config.enabled = params.enabled;
      }
      if (Object.hasOwn(params, 'mode')) {
        if (typeof params.mode !== 'string') throw fail('图片适应方式无效。');
        config.mode = params.mode;
      }
      for (const key of ['blur', 'veil', 'panel']) {
        if (!Object.hasOwn(params, key)) continue;
        const value = Number(params[key]);
        if (!Number.isFinite(value)) throw fail('背景效果数值无效。');
        config[key] = value;
      }
      const saved = await this.plugins.save({ id: plugin.id, revision: plugin.revision, plugin: { ...plugin, config } });
      return { ...await this.service.snapshot(), plugin: saved };
    }
    throw fail('背景操作不存在。', 404);
  }
}
