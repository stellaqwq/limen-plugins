import { mkdir, readFile, writeFile, readdir, unlink } from 'node:fs/promises';
import { readdirSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { createHash } from 'node:crypto';
import { readImage } from '../_host/image.mjs';
import { MODES } from './config.mjs';

// Wallpapers are local-only: one image file plus a small metadata record. The
// host never uploads them anywhere, and the bytes are always re-verified
// against the stored SHA-256 before they are served back to the workbench.
const MIME = { png: 'image/png', jpg: 'image/jpeg', webp: 'image/webp' };
const EXT = { png: 'png', jpg: 'jpg', webp: 'webp' };
const MAX_BYTES = 8 * 1024 * 1024;
const STATE = 'state.json';
const fail = (message, status = 400) => Object.assign(Error(message), { status });

export class BackgroundService {
  constructor({ config, log }) {
    this.log = log;
    this.root = join(config.dataDir, 'background');
    this.maxBytes = MAX_BYTES;
    this.state = null;
    this.loading = null;
    this.queue = Promise.resolve();
  }
  /** Serialize mutations so two uploads cannot leave a record pointing at a pruned file. */
  serial(operation) {
    const task = this.queue.then(operation);
    this.queue = task.catch(() => {});
    return task;
  }
  plugin() { return this.plugins?.find?.('background') || null; }
  /** Read the stored image record once; a missing or corrupt file means "no wallpaper". */
  load() {
    if (this.state) return this.state;
    if (!this.loading) this.loading = (async () => {
      try {
        const value = JSON.parse(await readFile(join(this.root, STATE), 'utf8'));
        const usable = MIME[value?.format] && Number.isSafeInteger(value.size) && value.size > 0 &&
          typeof value.hash === 'string' && /^[a-f0-9]{64}$/.test(value.hash);
        this.state = usable ? {
          format: value.format, width: value.width >>> 0, height: value.height >>> 0, size: value.size,
          hash: value.hash, updated_at: Number(value.updated_at) || 0
        } : { format: '' };
      } catch { this.state = { format: '' }; }
      return this.state;
    })();
    return this.loading;
  }
  async appearance() {
    const state = await this.load(), plugin = this.plugin(), config = plugin?.config || {};
    const image = state.format ? {
      url: '/background/image?v=' + state.hash.slice(0, 12), format: state.format,
      width: state.width, height: state.height, size: state.size, updated_at: state.updated_at
    } : null;
    return {
      available: true, installed: !!plugin, plugin_enabled: plugin?.enabled === true,
      enabled: !!(plugin?.enabled && config.enabled !== false && image),
      mode: MODES.includes(config.mode) ? config.mode : 'cover',
      blur: Number.isFinite(config.blur) ? config.blur : 0,
      veil: Number.isFinite(config.veil) ? config.veil : 0.34,
      panel: Number.isFinite(config.panel) ? config.panel : 0.9,
      image, max_bytes: this.maxBytes
    };
  }
  async snapshot() {
    const plugin = this.plugin();
    return {
      plugin: plugin ? {
        id: plugin.id, name: plugin.name, enabled: plugin.enabled, revision: plugin.revision, config: plugin.config
      } : null,
      ...await this.appearance()
    };
  }
  write({ data } = {}) {
    return this.serial(async () => {
      if (typeof data !== 'string' || data.length > 4 * Math.ceil(this.maxBytes / 3) + 256) {
        throw fail('请选择 PNG、JPEG 或 WebP 图片，大小不超过 8 MiB。');
      }
      let image;
      try { image = await readImage(data, { maxBytes: this.maxBytes }); }
      catch { throw fail('图片内容无效或超过 8 MiB，请使用 PNG、JPEG 或 WebP。'); }
      if (!MIME[image.format]) throw fail('背景只支持 PNG、JPEG 或 WebP，不支持动图。');
      const hash = createHash('sha256').update(image.bytes).digest('hex');
      const state = {
        format: image.format, width: image.width, height: image.height,
        size: image.bytes.length, hash, updated_at: Date.now()
      };
      await mkdir(this.root, { recursive: true });
      await writeFile(join(this.root, 'wallpaper.' + EXT[image.format]), image.bytes);
      await this.prune(image.format);
      await writeFile(join(this.root, STATE), JSON.stringify(state, null, 2) + '\n');
      this.state = state; this.loading = null;
      this.log?.('info', 'background_saved', { format: image.format, size: state.size });
      return this.snapshot();
    });
  }
  clear() {
    return this.serial(async () => {
      this.state = { format: '' }; this.loading = null;
      await this.prune('').catch(() => {});
      await unlink(join(this.root, STATE)).catch(() => {});
      this.log?.('info', 'background_cleared');
      return this.snapshot();
    });
  }
  /** Same as clear(), for the synchronous plugin-destroy hook. */
  clearSync() {
    this.state = { format: '' }; this.loading = null;
    try {
      for (const name of readdirSync(this.root)) {
        if (/^(?:state\.json|wallpaper\.(?:png|jpg|webp))$/.test(name)) rmSync(join(this.root, name), { force: true });
      }
    } catch { /* Nothing stored yet. */ }
  }
  /** Remove wallpaper files that do not match the active format (and the record). */
  async prune(keep = '') {
    let names;
    try { names = await readdir(this.root); } catch { return; }
    const extension = EXT[keep] || '';
    for (const name of names) {
      if (name === STATE) continue;
      if (extension && name === 'wallpaper.' + extension) continue;
      if (/^wallpaper\.(?:png|jpg|webp)$/.test(name)) await unlink(join(this.root, name)).catch(() => {});
    }
  }
  async bytes() {
    const state = await this.load();
    if (!state.format) throw fail('尚未设置背景图片。', 404);
    let bytes;
    try { bytes = await readFile(join(this.root, 'wallpaper.' + EXT[state.format])); }
    catch { throw fail('背景图片文件不存在，请重新上传。', 404); }
    if (bytes.length > this.maxBytes) throw fail('背景图片文件超过大小限制。', 413);
    if (createHash('sha256').update(bytes).digest('hex') !== state.hash) throw fail('背景图片文件校验失败，请重新上传。', 409);
    return { bytes, mime: MIME[state.format] };
  }
}
