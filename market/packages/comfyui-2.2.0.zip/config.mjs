import {applyConfigSchema} from '../_host/config-schema.mjs';
import {parameters} from '../_host/schema.mjs';

const field=(type,description,value,group,hint='')=>({type,description,default:value,group,hint});
export const comfySchema={
  base_url:field('string','ComfyUI 地址','http://127.0.0.1:8188','连接','远程运行Limen时填写 ComfyUI 所在电脑的局域网地址。'),
  web_enabled:field('bool','允许网页测试对话',true,'访问范围'),
  use_workflow:field('bool','默认使用提供的工作流',false,'工作流','关闭时自动创建基础文生图流程；模型也可按用户要求单次切换。'),
  workflow_json:field('text','提供的 API 工作流 JSON','','工作流','粘贴 ComfyUI 导出的 API 格式 JSON。普通画布 JSON 需先导出为 API 格式。'),
  workflow_path:field('string','API 工作流文件路径','','工作流','可选，指Limen所在主机的文件路径；优先使用上方 JSON。'),
  bindings:field('text','工作流参数节点映射','{}','工作流','可选 JSON，例如 {"prompt":["11.text"],"negative_prompt":["12.text"],"seed":["19.seed"],"width":["28.width"],"height":["28.height"]}。留空自动识别标准节点。'),
  checkpoint:field('string','基础流程 checkpoint 名称','','基础流程','留空自动选择已安装的 checkpoint；没有 checkpoint 时自动选择 Anima。'),
  timeout_seconds:{...field('int','生图等待上限（秒）',600,'连接'),slider:{min:30,max:1800,step:1}},
  max_tasks:{...field('int','单次最多生图任务',8,'批量与队列','同一提示词生成多张时逐张提交，各占一个任务，后台串行执行。'),slider:{min:1,max:16,step:1}},
  max_images:{...field('int','单次最多回传图片',8,'批量与队列','包括工作流自带批量输出；超出部分仍可在 ComfyUI 历史中查看。'),slider:{min:1,max:16,step:1}},
  max_queue:{...field('int','最多等待中的对话任务',8,'批量与队列','其他对话正在生图时进入队列，按先后顺序处理。'),slider:{min:1,max:32,step:1}},
  batch_timeout_seconds:{...field('int','整批等待上限（秒）',1800,'批量与队列','包含排队、生成与下载；单个生图任务仍受上方生图等待上限限制。'),slider:{min:60,max:7200,step:1}},
};
export const fail=message=>Object.assign(new Error(message),{status:400});
export function apiWorkflow(value){
  let graph;try{graph=typeof value==='string'?JSON.parse(value):structuredClone(value);}catch{throw fail('工作流不是有效 JSON。');}
  graph=graph?.prompt??graph;
  if(!graph||Array.isArray(graph)||typeof graph!=='object'||graph.nodes||!Object.keys(graph).length||Object.values(graph).some(n=>!n||typeof n.class_type!=='string'||!n.inputs||typeof n.inputs!=='object'||Array.isArray(n.inputs)))throw fail('请使用 ComfyUI 导出的 API 格式工作流，不能使用普通画布 JSON。');
  if(Object.keys(graph).length>500)throw fail('工作流节点过多。');
  return graph;
}
export function comfyConfig(value={}){
  const c=applyConfigSchema(comfySchema,value);let url;
  try{url=new URL(c.base_url);}catch{throw fail('ComfyUI 地址无效。');}
  if(!['http:','https:'].includes(url.protocol)||url.username||url.password||url.search||url.hash)throw fail('ComfyUI 地址必须为 HTTP(S) 地址，不能包含账号、密码或查询参数。');
  c.base_url=c.base_url.replace(/\/+$/,'');
  if(c.workflow_json.trim())apiWorkflow(c.workflow_json);
  let bindings;try{bindings=JSON.parse(c.bindings||'{}');}catch{throw fail('节点映射不是有效 JSON。');}
  const keys=['prompt','negative_prompt','seed','width','height','steps','cfg'];
  if(!bindings||Array.isArray(bindings)||typeof bindings!=='object'||Object.entries(bindings).some(([k,v])=>!keys.includes(k)||!Array.isArray(v)||v.some(s=>typeof s!=='string'||!/^\d+\.[A-Za-z_][A-Za-z0-9_]*$/.test(s))))throw fail('节点映射应为参数名到节点输入路径数组，例如 {"prompt":["11.text"]}。');
  return c;
}
const imageArguments={
  prompt:{type:'string',minLength:1,maxLength:6000,description:'图片的详细描述；多组任务的每一项分别填写。'},
  negative_prompt:{type:'string',maxLength:3000},use_workflow:{type:'boolean'},
  seed:{type:'integer',minimum:0,maximum:9007199254740991},
  width:{type:'integer',minimum:64,maximum:2048},height:{type:'integer',minimum:64,maximum:2048},
  steps:{type:'integer',minimum:1,maximum:100},cfg:{type:'number',minimum:0,maximum:30},
  loras:{type:'array',minItems:1,maxItems:32,description:'调整现有工作流中的 LoRA 强度。先调用 comfyui_status 查看 workflow_loras，按 node_id 指定。只修改明确提供的强度；省略保留原值。不添加或更换 LoRA。根级可作为各组默认值，各组 loras 完整覆盖根级列表。',items:{...parameters({
    node_id:{type:'string',minLength:1,maxLength:100,description:'comfyui_status 返回的工作流 LoRA 节点编号。'},
    strength_model:{type:'number',minimum:-100,maximum:100,description:'模型强度，0 表示该模型分支不应用 LoRA，通常在 0–1 范围内调整。'},
    strength_clip:{type:'number',minimum:-100,maximum:100,description:'CLIP 强度，仅适用于支持 CLIP 的 LoRA 节点；省略保留原值。'}
  }),required:['node_id']}},
  count:{type:'integer',minimum:1,maximum:16,description:'此提示词生成几张，默认1；受插件任务和图片上限限制，逐张提交，提供种子时后续图片递增种子。'}
};
export const comfyTools=[
  {name:'comfyui_status',effect:'read',description:'检查 ComfyUI 连接、可用模型、工作流模式和工作流内每个 LoRA 的节点编号、名称及当前模型/CLIP强度。调整 LoRA 前先查询 workflow_loras。',parameters:parameters({})},
  {name:'comfyui_generate',effect:'write',description:'按用户要求生成一张或多张图片，排队等待并直接回复真实图片。相同提示词用 prompt+count；多组不同提示词一次放入 requests 数组，每项也可指定 count。prompt 与 requests 二选一，根级其他参数可作各项默认值。默认最多8个任务、8张回传，以 status 返回的配置为准。串行执行，不重复调用补交同一批。use_workflow=false 为基础流程，true 为提供的工作流；省略遵循配置。未明确指定的尺寸、CFG和步数保留工作流默认。',parameters:parameters({
    ...imageArguments,requests:{type:'array',minItems:1,maxItems:16,description:'多组不同图片任务；受插件任务上限限制，必须一次提交整批，不能在多个工具调用中拆分同一批。',items:{...parameters(imageArguments),required:['prompt']}}
  })}
];
export const comfyTemplate={schema:1,kind:'comfyui',name:'ComfyUI 生图',description:'模型批量调用 ComfyUI 生图，支持逐个调整工作流 LoRA 的模型/CLIP强度、排队、多图回复和生成图片上下文回看。',version:'2.2.0',source:'// ComfyUI 内置批量生图执行层。\n',trigger:'',priority:0,timeout_ms:10000,
  scope:{private_users:[],groups:[],all_private:false,all_groups:false,require_at:true},config:comfyConfig(),config_schema:comfySchema,tools:comfyTools};
