import { ComfyService } from './service.mjs';
import { comfyConfig, comfyTemplate, comfySchema, comfyTools } from './config.mjs';

export const template = () => comfyTemplate;
export const config = value => comfyConfig(value);
export const schema = () => comfySchema;
export const tools = () => structuredClone(comfyTools);

export function create(ctx) {
  const service = new ComfyService({ store: ctx.store, plugins: ctx.plugins, config: ctx.config, fetcher: ctx.overrides.comfyFetch ?? fetch });
  return service;
}

export function visible(plugin, { event, job, host }) {
  if (job?.channel === 'web') return plugin.enabled && !!plugin.config.web_enabled;
  return plugin.enabled && !host.isGroupUserBlocked(event) && host.matches(plugin, event, true);
}
