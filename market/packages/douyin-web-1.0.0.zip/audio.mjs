import {randomUUID,createHash} from 'node:crypto';
import {setTimeout as delay} from 'node:timers/promises';
import {pageHelpers,snapshotExpression} from './page.mjs';

// Fixed operations on the visible video element only. No microphone, desktop
// loopback, arbitrary URL, credentials, or page-supplied script is accepted.
export const audioStartExpression=(token,seconds,expected)=>'(()=>{'+pageHelpers+'\nconst p='+JSON.stringify({token,seconds,expected})+';const initial='+snapshotExpression+';'+String.raw`
if(blocked||socialPanelOpen||!active||active.e.paused)return {ok:false,status:blocked?'blocked':socialPanelOpen?'social_panel':'paused'};
if((p.expected.video_id&&initial.video_id!==p.expected.video_id)||(!p.expected.video_id&&p.expected.media_key&&initial.media_key!==p.expected.media_key))return {ok:false,status:'source_changed'};
if(typeof active.e.captureStream!=='function'||typeof MediaRecorder!=='function'||(!initial.video_id&&!initial.media_key))return {ok:false,status:'unsupported'};
if(globalThis.__xuqiaoAudioCapture&&!globalThis.__xuqiaoAudioCapture.done)return {ok:false,status:'busy'};
const video=active.e,originalSrc=video.currentSrc||video.src,originalObject=video.srcObject;
let captured,stream,recorder;
try{
  captured=video.captureStream();const tracks=captured.getAudioTracks();
  if(!tracks.length){captured.getTracks().forEach(t=>t.stop());return {ok:false,status:'no_audio_track'};}
  stream=new MediaStream(tracks.map(t=>t.clone()));captured.getTracks().forEach(t=>t.stop());
  const mime=['audio/webm;codecs=opus','audio/webm','audio/ogg;codecs=opus'].find(m=>MediaRecorder.isTypeSupported(m));
  if(!mime){stream.getTracks().forEach(t=>t.stop());return {ok:false,status:'unsupported'};}
  recorder=new MediaRecorder(stream,{mimeType:mime,audioBitsPerSecond:64000});
}catch{captured?.getTracks().forEach(t=>t.stop());stream?.getTracks().forEach(t=>t.stop());return {ok:false,status:'capture_restricted'};}
const s={token:p.token,done:false,started:performance.now(),captured_at:new Date().toISOString(),video_start_seconds:initial.video.current_seconds,bytes:0,chunks:[],status:'recording'};
globalThis.__xuqiaoAudioCapture=s;
const finish=reason=>{if(s.stopping)return;s.stopping=true;s.reason=reason||null;clearTimeout(s.timer);clearInterval(s.watch);if(recorder.state!=='inactive')recorder.stop();};
s.cancel=()=>finish('cancelled');
recorder.ondataavailable=event=>{if(event.data.size){s.bytes+=event.data.size;if(s.bytes>2097152){finish('too_large');return;}s.chunks.push(event.data);}};
recorder.onerror=()=>finish('capture_failed');
recorder.onstop=()=>{
  clearTimeout(s.timer);clearInterval(s.watch);stream.getTracks().forEach(t=>t.stop());
  const duration=(performance.now()-s.started)/1000;
  if(s.reason||!s.bytes||duration<0.25){s.result={ok:false,status:s.reason||'empty'};s.done=true;s.chunks=[];return;}
  const reader=new FileReader();reader.onload=()=>{s.result={ok:true,status:'captured',mime:recorder.mimeType,data:String(reader.result).split(',')[1],bytes:s.bytes,duration_seconds:Math.min(31,duration),captured_at:s.captured_at,video_start_seconds:s.video_start_seconds,video_end_seconds:Number.isFinite(video.currentTime)?video.currentTime:null};s.done=true;s.chunks=[];};
  reader.onerror=()=>{s.result={ok:false,status:'capture_failed'};s.done=true;s.chunks=[];};reader.readAsDataURL(new Blob(s.chunks,{type:recorder.mimeType}));
};
s.watch=setInterval(()=>{
  const current=`+snapshotExpression+String.raw`;
  if(current.blocked||current.social_panel_open){finish('blocked');return;}
  if((initial.video_id&&current.video_id!==initial.video_id)||(!initial.video_id&&current.media_key!==initial.media_key)||(video.currentSrc||video.src)!==originalSrc||video.srcObject!==originalObject){finish('source_changed');return;}
  if(video.paused||video.ended){finish();return;}
  if(performance.now()-s.started>1000&&stream.getAudioTracks().every(t=>t.muted||t.readyState==='ended'))finish('capture_restricted');
},200);
s.timer=setTimeout(()=>finish(),p.seconds*1000);try{recorder.start(250);}catch{clearTimeout(s.timer);clearInterval(s.watch);stream.getTracks().forEach(t=>t.stop());delete globalThis.__xuqiaoAudioCapture;return {ok:false,status:'capture_failed'};}return {ok:true,status:'recording'};
})()`;

export const audioReadExpression=token=>'(()=>{const s=globalThis.__xuqiaoAudioCapture;if(!s||s.token!=='+JSON.stringify(token)+')return {ok:false,status:"missing"};if(!s.done)return {ok:true,status:"recording"};const result=s.result;delete globalThis.__xuqiaoAudioCapture;return result;})()';
export const audioCancelExpression=token=>'(()=>{const s=globalThis.__xuqiaoAudioCapture;if(s?.token==='+JSON.stringify(token)+'){s.cancel();delete globalThis.__xuqiaoAudioCapture;}return {ok:true};})()';

export class DouyinAudio {
  constructor(service){this.service=service;}
  async begin(plugin,page,signal){
    const service=this.service;
    if(!plugin.config.audio_enabled)return null;
    if(!service.audioReady?.())return {finish:async()=>({status:'unconfigured'}),cancel:async()=>{}};
    const token=randomUUID(),seconds=plugin.config.audio_sample_seconds;
    let started;
    try{started=await service.browser.evaluate(audioStartExpression(token,seconds,{video_id:page.video_id,media_key:page.media_key}),signal);}catch{signal?.throwIfAborted();started={ok:false,status:'capture_failed'};}
    if(!started?.ok)return {finish:async()=>({status:started?.status||'capture_failed'}),cancel:async()=>{}};
    let disposed=false;
    const cancel=async()=>{if(disposed)return;disposed=true;try{await service.browser.evaluate(audioCancelExpression(token),AbortSignal.timeout(2000));}catch{}};
    return {cancel,finish:async evidence=>{
      if(evidence.blocked||evidence.mixed){await cancel();return {status:'source_changed'};}
      try{
        const deadline=Date.now()+(seconds+3)*1000;let recording;
        do{signal?.throwIfAborted();recording=await service.browser.evaluate(audioReadExpression(token),signal);if(recording?.status!=='recording')break;await delay(200,undefined,{signal});}while(Date.now()<deadline);
        if(!recording?.ok||recording.status!=='captured')return {status:recording?.status==='recording'?'capture_failed':recording?.status||'capture_failed'};
        const bytes=Buffer.from(recording.data||'','base64');if(!bytes.length||bytes.length>2*1048576||bytes.length!==recording.bytes)return {status:'capture_failed'};
        const result=await service.transcribeAudio(bytes,{mime:recording.mime,duration_seconds:recording.duration_seconds},signal);
        signal?.throwIfAborted();
        const text=result.text?.trim().slice(0,2000)||'',segments=[];let size=0;
        for(const segment of result.segments||[]){if(segments.length>=20||size+segment.text.length>2000)break;size+=segment.text.length;segments.push({offset_start_seconds:segment.start_seconds,offset_end_seconds:segment.end_seconds,text:segment.text});}
        const outcome={status:text?'transcribed':'no_speech',audio_sha256:createHash('sha256').update(bytes).digest('hex'),captured_at:recording.captured_at,duration_seconds:Math.round(recording.duration_seconds*1000)/1000,video_start_seconds:recording.video_start_seconds,video_end_seconds:recording.video_end_seconds,text,segments,model:result.model,timestamps:segments.length>0,note:result.note};
        while(Buffer.byteLength(JSON.stringify(outcome))>7000){outcome.truncated=true;if(outcome.segments.length)outcome.segments.pop();else outcome.text=outcome.text.slice(0,Math.floor(outcome.text.length*0.75));}outcome.timestamps=outcome.segments.length>0;return outcome;
      }catch{signal?.throwIfAborted();return {status:'transcription_failed'};}
      finally{await cancel();}
    }};
  }
}
