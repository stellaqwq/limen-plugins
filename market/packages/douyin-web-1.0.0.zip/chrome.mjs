import {spawn} from 'node:child_process';
import {access,mkdir} from 'node:fs/promises';
import {join} from 'node:path';

export const home='https://www.douyin.com/?recommend=1&from_nav=1';
export const allowedPage=value=>{try{const u=new URL(value);return u.protocol==='https:'&&u.hostname==='www.douyin.com'&&u.port===''&&!u.username&&!u.password;}catch{return false;}};
const fail=message=>Object.assign(Error(message),{status:409});

// A local pipe, rather than a debugging TCP port. No browser endpoint, cookies,
// arbitrary script, target ID, or URL is accepted from the model.
export class ChromeBrowser {
  constructor({profile,headless=false}){this.profile=profile;this.headless=headless;this.pending=new Map();this.sequence=0;this.buffer=Buffer.alloc(0);}
  get running(){return !!this.child&&this.child.exitCode===null&&!this.child.killed&&!!this.session;}
  async executable(path){
    if(path)return path;
    for(const root of [process.env.ProgramFiles,process.env['ProgramFiles(x86)'],process.env.LOCALAPPDATA].filter(Boolean)){
      const candidate=join(root,'Google/Chrome/Application/chrome.exe');try{await access(candidate);return candidate;}catch{}
    }
    if(process.platform==='darwin')return '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
    if(process.platform!=='win32')return 'google-chrome';throw fail('未找到 Chrome，请在插件设置中填写可执行文件路径。');
  }
  async start(path,signal){
    if(this.running)return;
    signal?.throwIfAborted();if(this.starting)return this.starting;
    this.starting=this.launch(path,signal).finally(()=>{this.starting=null;});return this.starting;
  }
  async launch(path,signal){
    await mkdir(this.profile,{recursive:true});const exe=await this.executable(path);signal?.throwIfAborted();
    this.buffer=Buffer.alloc(0);
    // This visible window is the user's dedicated playback/login window.
    const child=this.child=spawn(exe,['--remote-debugging-pipe','--user-data-dir='+this.profile,'--no-first-run','--no-default-browser-check','--window-size=1280,900',...(this.headless?['--headless=new']:[]),'about:blank'],{windowsHide:this.headless,stdio:['ignore','ignore','ignore','pipe','pipe']});
    const disconnected=()=>{if(this.child===child){this.session=null;this.target=null;for(const item of this.pending.values())item.reject(fail('抖音浏览器已关闭，请重新打开。'));this.pending.clear();}};
    child.once('error',disconnected);child.once('exit',disconnected);child.stdio[3].on('error',()=>{});child.stdio[4].on('data',data=>this.receive(data));
    try{
      await this.send('Browser.getVersion',{},signal);
      const {targetId}=await this.send('Target.createTarget',{url:'about:blank'},signal);this.target=targetId;
      const {sessionId}=await this.send('Target.attachToTarget',{targetId,flatten:true},signal);this.session=sessionId;
      await this.page('Page.enable',{},signal);
    }catch(error){await this.close();throw error;}
  }
  receive(data){
    this.buffer=Buffer.concat([this.buffer,data]);if(this.buffer.length>8*1024*1024){void this.close();return;}
    let end;while((end=this.buffer.indexOf(0))>=0){const frame=this.buffer.subarray(0,end);this.buffer=this.buffer.subarray(end+1);if(!frame.length)continue;
      let message;try{message=JSON.parse(frame.toString('utf8'));}catch{continue;}
      const item=this.pending.get(message.id);if(!item)continue;this.pending.delete(message.id);message.error?item.reject(fail('浏览器操作失败，请重新观察页面。')):item.resolve(message.result);
    }
  }
  send(method,params={},signal,sessionId){
    signal?.throwIfAborted();const child=this.child;if(!child||child.exitCode!==null||child.killed)throw fail('浏览器尚未打开。');
    const id=++this.sequence;
    return new Promise((resolve,reject)=>{
      const cleanup=()=>{clearTimeout(timer);signal?.removeEventListener('abort',abort);this.pending.delete(id);};
      const abort=()=>{cleanup();reject(signal.reason||fail('浏览器操作已停止。'));};
      const timer=setTimeout(()=>{cleanup();reject(fail('浏览器操作超时，请核对页面。'));},15000);
      this.pending.set(id,{resolve:r=>{cleanup();resolve(r);},reject:e=>{cleanup();reject(e);}});
      signal?.addEventListener('abort',abort,{once:true});if(signal?.aborted){abort();return;}
      child.stdio[3].write(JSON.stringify({id,method,params,...(sessionId?{sessionId}:{})})+'\0',error=>{if(error){cleanup();reject(fail('浏览器连接中断。'));}});
    });
  }
  page(method,params,signal){if(!this.session)throw fail('抖音浏览器尚未打开。');return this.send(method,params,signal,this.session);}
  async url(signal){return (await this.send('Target.getTargetInfo',{targetId:this.target},signal)).targetInfo.url;}
  async guard(signal){const url=await this.url(signal);if(!allowedPage(url))throw fail('浏览器当前不是抖音网站，请重新打开抖音；未读取其他页面。');return url;}
  async evaluate(expression,signal){
    await this.guard(signal);
    const result=await this.page('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true},signal);
    if(result.exceptionDetails)throw fail('网页播放器状态读取失败。');await this.guard(signal);return result.result.value;
  }
  async open(path,signal){
    await this.start(path,signal);signal?.throwIfAborted();
    // Never navigate an existing tab that the user moved to another site.
    const url=await this.url(signal);if(url!=='about:blank'&&!allowedPage(url))throw fail('专用标签页已离开抖音，请关闭专用窗口后重新打开。');
    const r=await this.page('Page.navigate',{url:home},signal);if(r.errorText)throw fail('抖音网页打开失败，请检查网络。');
    for(let i=0;i<60;i++){signal?.throwIfAborted();if(allowedPage(await this.url(signal)))return;await new Promise(r=>setTimeout(r,100));}
    throw fail('页面加载尚未完成，请稍后观察。');
  }
  async screenshot(signal,{maxWidth=1280,maxHeight=960}={}){
    await this.guard(signal);await this.page('Page.bringToFront',{},signal);
    const metrics=await this.page('Page.getLayoutMetrics',{},signal),v=metrics.cssVisualViewport||metrics.visualViewport;
    if(!v||v.clientWidth<1||v.clientHeight<1)throw fail('浏览器画面尺寸不可用。');
    const r=await this.page('Page.captureScreenshot',{format:'jpeg',quality:65,fromSurface:true,captureBeyondViewport:false,clip:{x:v.pageX||0,y:v.pageY||0,width:v.clientWidth,height:v.clientHeight,scale:Math.min(1,maxWidth/v.clientWidth,maxHeight/v.clientHeight)}},signal);
    await this.guard(signal);if(typeof r.data!=='string'||r.data.length>1800000||!r.data.startsWith('/9j/'))throw fail('浏览器截图过大或格式无效。');return 'data:image/jpeg;base64,'+r.data;
  }
  async next(x,y,signal){
    await this.guard(signal);
    await this.page('Input.dispatchMouseEvent',{type:'mouseWheel',x,y,deltaX:0,deltaY:650},signal);
  }
  async close(){
    const child=this.child;if(!child)return;
    try{await this.send('Browser.close',{},AbortSignal.timeout(1500));}catch{}
    this.child=null;this.session=null;this.target=null;child.stdio[3].destroy();child.stdio[4].destroy();
    for(const item of this.pending.values())item.reject(fail('浏览器连接已结束。'));this.pending.clear();
    if(child.exitCode===null){await new Promise(resolve=>{const timer=setTimeout(()=>{child.kill();resolve();},2000);child.once('exit',()=>{clearTimeout(timer);resolve();});});}
  }
}
