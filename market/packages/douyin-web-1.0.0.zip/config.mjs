import {applyConfigSchema} from '../_host/config-schema.mjs';
import {parameters} from '../_host/schema.mjs';

const field=(type,description,value,hint='')=>({type,description,default:value,group:'抖音网页端',hint});
export const douyinSchema={
  web_enabled:field('bool','允许网页测试对话',true,'允许已认证的网页对话使用抖音浏览、知识库和已开启的社交工具。'),
  qq_private_enabled:field('bool','允许 QQ 管理员私聊观看',false,'允许本插件好友范围内的 QQ 管理员私聊调用浏览与视频知识库工具，同时遵守 AI 白名单。开启后请填写上方好友 QQ 号；不开放群聊或普通抖音社交工具。另开自主分享后可向固定默认好友推荐。'),
  chrome_path:field('string','Chrome 可执行文件路径','','留空查找本机 Chrome。使用独立浏览器资料，不读取日常浏览器的 Cookie。'),
  max_videos:{...field('int','每任务最多浏览条数',5,'指定条数的任务包含第一条；模型不能修改上限。未指定数量的持续/自主浏览每轮只处理一条，后台逐轮继续，直到用户叫停或自主模式结束。'),slider:{min:1,max:20,step:1}},
  min_observe_frames:{...field('int','每批至少采样画面数',1,'模型任务的采样下限，最多8幅；手动预览仍只取1幅。当前视频临近结尾、页面变化或达到图片预算时可提前结束。'),group:'画面采样',slider:{min:1,max:8,step:1}},
  min_observe_interval_seconds:{...field('float','采样最短间隔（秒）',0.5,'增大间隔可观察更长的前后变化；6幅、间隔3秒通常跨约15秒。'),group:'画面采样',slider:{min:0.5,max:10,step:0.5}},
  audio_enabled:{...field('bool','自动转写当前视频对白',false,'采集当前可见视频的短音轨，复用已启用“视频理解”插件的语音转写服务。转写文字用于理解和入库；不采集麦克风或系统声音，不长期保留录音。'),group:'声音与对白'},
  audio_sample_seconds:{...field('int','每批音频采集秒数',15,'与画面采样同时进行；仅覆盖这段实际采集的对白，不代表听完整条视频。'),group:'声音与对白',slider:{min:3,max:30,step:1}},
  social_enabled:{...field('bool','启用分享与私信草稿',false,'允许读取已打开面板中的好友标识，生成单个收件人的分享/私信草稿。默认在管理页核对后发送；开启自动聊天后可自动回复默认好友；开启自主分享后可在刷视频时自动推荐给默认好友，不群发。'),group:'分享与私信'},
  social_default_friend:{...field('string','默认好友（抖音号或昵称）','','省略收件人时使用这个好友；优先填写唯一抖音号，同名时需在管理页绑定。'),group:'分享与私信'},
  browse_share_enabled:{...field('bool','刷视频时自动分享给默认好友',false,'开启后，QQ 管理员或默认抖音好友明确要求刷视频时，模型可挑选实际观看的视频，自动分享给已绑定的默认好友并私信几句感想。抖音入口还需开启聊天读取；无需开启普通自动聊天。只处理开启后的新指令，结果未知不重发。'),group:'自主刷视频'},
  browse_share_max_per_task:{...field('int','每任务最多分享视频数',2,'持续/自主浏览按整个会话累计，不随每轮重置。只发送模型认为有意思的内容，也可以不分享；同一视频不会重复自动分享。'),group:'自主刷视频',slider:{min:1,max:5,step:1}},
  browse_reasoning_effort:{...field('string','刷视频的模型思考强度','','留空沿用 AI 设置；none 使用快速判断，适合连续观看。仅影响刷视频的分析、笔记和决定，不改变普通聊天。模型服务需支持对应取值。'),group:'自主刷视频',options:['','none','minimal','low','medium','high','xhigh']},
  browse_max_output_tokens:{...field('int','刷视频单次生成 Token 上限',0,'0 沿用 AI 设置。快速判断可设2048；保留思考时需要为思考和工具参数共同预留额度。该限制不会减少画面或音轨采样。'),group:'自主刷视频',slider:{min:0,max:32768,step:256}},
  chat_read_enabled:{...field('bool','允许读取默认好友的最近消息',false,'仅限已核对的默认好友当前会话；聊天内容会交给当前模型，不写入视频知识库。'),group:'抖音聊天'},
  chat_auto_enabled:{...field('bool','自动聊天',false,'开启并保存后，自动读取默认好友的新消息、生成回复并发送，无需逐条确认。需启用分享与私信、聊天读取并绑定默认好友，保持专用抖音窗口打开。首次开启及重启跳过已有消息；结果不明会停止，不自动重发。'),group:'抖音聊天'},
  chat_auto_interval_seconds:{...field('int','自动聊天检查间隔（秒）',15,'没有新消息时只检查网页，不请求模型；浏览器被其他任务使用时等待。'),group:'抖音聊天',slider:{min:10,max:300,step:1}},
  chat_auto_max_per_hour:{...field('int','每小时最多自动回复数',20,'达到上限后等待下一小时；每条新消息最多处理一次。'),group:'抖音聊天',slider:{min:1,max:120,step:1}},
  knowledge_enabled:{...field('bool','启用视频知识库',false,'允许模型根据实际采样画面保存观看记忆与知识笔记；独立于用户个人记忆。'),group:'视频学习'},
  knowledge_auto_archive:{...field('bool','观看后自动归档',true,'启用知识库后，模型每条视频先保存笔记再切换；无可学知识时只保存观看记忆。会增加工具调用次数。'),group:'视频学习'},
  knowledge_auto_recall:{...field('bool','回答前自动检索',true,'从管理员共享视频库中检索相关笔记，标明视频来源和未核实状态。'),group:'视频学习'},
  knowledge_max_entries:{...field('int','最多保留有效笔记数',1000),group:'视频学习',slider:{min:10,max:5000,step:1}},
  max_task_seconds:{...field('int','每任务最长秒数',180,'持续/自主浏览时约束每轮观看，整个会话可跨多轮运行。失败、未知结果、停止、配置变更或退出均结束会话，重启不会自动续刷。'),slider:{min:15,max:600,step:1}}
};
export function douyinConfig(value={}){
  const c=applyConfigSchema(douyinSchema,value);
  if(typeof c.social_default_friend!=='string'||c.social_default_friend.length>80||/[\r\n\0]/.test(c.social_default_friend))throw Object.assign(Error('默认好友需为最多80字的抖音号或昵称。'),{status:400});
  if(Object.keys(c).some(k=>!Object.hasOwn(douyinSchema,k))||/[\r\n\0]/.test(c.chrome_path))throw Object.assign(Error('抖音网页配置无效，请检查浏览器路径和范围。'),{status:400});
  return c;
}
const args=(p,required=[])=>({...parameters(p),required});
export const douyinTools=[
  {name:'douyin_web_status',effect:'read',description:'查询独立抖音浏览器、播放状态、验证或登录阻挡、任务浏览上限。不启动浏览器或改变页面。',parameters:args({})},
  {name:'douyin_web_observe',effect:'read',description:'按时间顺序采样抖音网页1–8幅画面，返回各帧播放器秒数、采样时间和 observation_id。至少遵守管理员配置的画面数及间隔；可省略参数使用配置。支持图片的模型据此看前后变化；管理员开启对白转写时，还会返回实际采集音轨的 audio_transcript，机器识别可能有误。没有转写时不能猜测声音。遇登录、验证或风控仅报告给用户。换下一条前简短记录本条事实。',parameters:args({frames:{type:'integer',minimum:1,maximum:8},interval_seconds:{type:'number',minimum:0.5,maximum:10}})},
  {name:'douyin_web_action',effect:'write',description:'在独立浏览器打开抖音推荐页，或基于最近30秒的观察播放、暂停、切换下一条。close_social 只关闭无未发送正文的社交面板，便于继续观看。每个新动作用新的 operation_id；不会处理登录、验证码、风控，不提供任意网址、脚本、点击、点赞、评论或关注。',parameters:args({action:{type:'string',enum:['open_home','play','pause','next_video','close_social']},operation_id:{type:'string',minLength:1,maxLength:64},observation_id:{type:'string',maxLength:64}},['action','operation_id'])}
];
export const douyinTemplate={schema:1,kind:'douyin-web',name:'抖音网页浏览',description:'使用独立 Chrome 窗口采样抖音画面，让视觉模型在条数和时间上限内观看并切换视频。登录和验证由用户完成。',version:'1.0.0',source:'// 内置抖音网页浏览执行层，只观察和操作视频播放器。\n',trigger:'',priority:0,timeout_ms:10000,
  scope:{private_users:[],groups:[],all_private:false,all_groups:false,require_at:true},config:douyinConfig(),config_schema:douyinSchema,tools:douyinTools};
