import {createHash} from 'node:crypto';

const norm=s=>String(s||'').normalize('NFKC').trim().replace(/^@/,'').toLowerCase();
const hashAccount=account=>createHash('sha256').update(JSON.stringify({name:account.name,avatar:account.avatar})).digest('hex');
// Douyin rotates the CDN shard for an unchanged avatar asset between launches.
const avatarIdentity=avatar=>String(avatar||'').replace(/^https:\/\/p\d+-pc-sign\.douyinpic\.com\//,'https://douyinpic.com/');
export const accountKey=account=>hashAccount({...account,avatar:avatarIdentity(account.avatar)});
const legacyAccountMatches=(account,hash)=>{
  if(hashAccount(account)===hash)return true;
  if(!/^https:\/\/p\d+-pc-sign\.douyinpic\.com\//.test(account.avatar||''))return false;
  for(let shard=1;shard<=99;shard++)if(hashAccount({...account,avatar:account.avatar.replace(/^https:\/\/p\d+-pc-sign\./,'https://p'+shard+'-pc-sign.')})===hash)return true;
  return false;
};
export const peerKey=recipient=>recipient.canonical_id||recipient.uid;
const fail=message=>Object.assign(Error(message),{status:409});

export class DefaultFriend {
  constructor(db){this.db=db;db.exec('CREATE TABLE IF NOT EXISTS douyin_default_friends (plugin_id TEXT PRIMARY KEY,requested TEXT NOT NULL,account_hash TEXT NOT NULL,recipient TEXT NOT NULL,updated_at INTEGER NOT NULL); CREATE TABLE IF NOT EXISTS douyin_chat_replies (plugin_id TEXT NOT NULL,peer_key TEXT NOT NULL,message_key TEXT NOT NULL,draft_id TEXT NOT NULL,PRIMARY KEY(plugin_id,peer_key,message_key));');}
  info(plugin){const requested=plugin?.config.social_default_friend||'',row=plugin&&this.db.prepare('SELECT * FROM douyin_default_friends WHERE plugin_id=?').get(plugin.id);return {configured:!!requested,requested,bound:!!row&&row.requested===norm(requested),name:row&&row.requested===norm(requested)?JSON.parse(row.recipient).name:null,chat_enabled:!!plugin?.config.chat_read_enabled};}
  bind(plugin,contact){
    if(!plugin.config.social_default_friend)throw fail('请先配置默认好友。');
    this.db.prepare('INSERT INTO douyin_default_friends VALUES (?,?,?,?,?) ON CONFLICT(plugin_id) DO UPDATE SET requested=excluded.requested,account_hash=excluded.account_hash,recipient=excluded.recipient,updated_at=excluded.updated_at').run(plugin.id,norm(plugin.config.social_default_friend),accountKey(contact.account),JSON.stringify(contact.recipient),Date.now());
    return this.info(plugin);
  }
  resolve(plugin,entries,{bindExact=true}={}){
    const desired=norm(plugin.config.social_default_friend);if(!desired)throw fail('尚未配置默认好友，请在插件设置中填写抖音号或昵称。');
    const row=this.db.prepare('SELECT * FROM douyin_default_friends WHERE plugin_id=?').get(plugin.id),values=[...entries];
    if(row&&row.requested===desired){const saved=JSON.parse(row.recipient),matches=values.filter(([,c])=>peerKey(c.recipient)===peerKey(saved)&&(accountKey(c.account)===row.account_hash||legacyAccountMatches(c.account,row.account_hash)));if(matches.length===1){if(accountKey(matches[0][1].account)!==row.account_hash)this.db.prepare('UPDATE douyin_default_friends SET account_hash=? WHERE plugin_id=?').run(accountKey(matches[0][1].account),plugin.id);return matches[0];}throw fail('当前账号或好友标识与已绑定的默认好友不同，请重新核对绑定。');}
    const exact=values.filter(([,c])=>[c.recipient.handle,c.recipient.name,c.recipient.uid,c.recipient.canonical_id].filter(Boolean).some(s=>norm(s)===desired));
    if(exact.length!==1)throw fail(exact.length?'默认好友存在同名或重复标识，请在管理页重新选定。':'当前联系人中未确认默认好友，请先打开对应面板并刷新，或在管理页选择绑定。');
    if(bindExact)this.bind(plugin,exact[0][1]);return exact[0];
  }
}
