import { DouyinWebService } from './service.mjs';
import { douyinConfig, douyinTemplate, douyinSchema, douyinTools } from './config.mjs';
import { socialTools } from './social.mjs';
import { knowledgeTools } from './knowledge/service.mjs';
import { consumeDouyinSetup } from './local.mjs';
import { browseMode, stopBrowseIntent } from './browse-session.mjs';
import { replyPrompt } from './auto-chat.mjs';

export const template = () => douyinTemplate;
export const config = value => douyinConfig(value);
export const schema = () => douyinSchema;
export const browse = { mode: browseMode, stopIntent: stopBrowseIntent };

export function tools(config = {}) {
  return structuredClone([
    ...douyinTools,
    ...(config.knowledge_enabled ? knowledgeTools : []),
    ...(config.social_enabled ? socialTools.filter(tool => tool.name !== 'douyin_chat_read' || config.chat_read_enabled) : [])
  ]);
}

export function create(ctx) {
  const service = new DouyinWebService({
    store: ctx.store, config: ctx.config,
    ...(ctx.overrides.douyinBrowser ? { browser: ctx.overrides.douyinBrowser } : {})
  });
  service.browseMode = browseMode;
  service.replyPrompt = replyPrompt;
  service.stopBrowseIntent = stopBrowseIntent;
  service.pluginFor = (event, job) => {
    if (event?.douyin_session) {
      const round = service.browsing.round(event, job);
      return ctx.plugins.find('douyin-web', round.event, round.job);
    }
    return ctx.plugins.find('douyin-web', event, job);
  };
  service.audioReady = () => {
    const plugin = ctx.plugins.find('video-analysis');
    return !!plugin?.enabled && !!plugin.config.asr_url;
  };
  service.transcribeAudio = (bytes, metadata, signal) => {
    const video = ctx.get('video-analysis');
    return video.transcribeCapturedAudio(bytes, metadata, signal);
  };
  return service;
}

export function visible(plugin, { event, job, host }) {
  const config = plugin.config;
  if (job?.channel === 'web') return plugin.enabled && !!config.web_enabled;
  return plugin.enabled && job?.channel === 'qq' && !!config.qq_private_enabled &&
    event.message_type === 'private' && host.isChatAdmin(event) && !host.isGroupUserBlocked(event) &&
    host.matches(plugin, event, true);
}

export async function setup(ctx) {
  try { await consumeDouyinSetup(ctx.plugins); }
  catch { ctx.log?.('warn', 'douyin_setup_unavailable'); }
}
