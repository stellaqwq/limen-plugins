import {readFile,writeFile,mkdir,rename} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {douyinConfig} from './config.mjs';
import {runtimeDir} from '../_host/paths.mjs';

export const douyinRoot=runtimeDir('douyin-web');
export async function applyDouyinSetup(plugins,patch={}){
  const old=plugins.find('douyin-web');let p=old||await plugins.install({kind:'douyin-web'});
  p=await plugins.save({id:p.id,revision:p.revision,plugin:{...p,config:douyinConfig({...p.config,...patch})}});
  if(!old)p=await plugins.toggle({id:p.id,revision:p.revision,enabled:true});
  // The web trial replaces emulator use. Preserve its settings, but revoke its
  // tools so a model cannot choose the emulator after a website restriction.
  const android=plugins.find('android-device');if(android?.enabled)await plugins.toggle({id:android.id,revision:android.revision,enabled:false});
  return {id:p.id,enabled:p.enabled,max_videos:p.config.max_videos};
}
export async function stageDouyinSetup(config,targetDataDir){
  await mkdir(douyinRoot,{recursive:true});await writeFile(join(douyinRoot,'setup.pending.json'),JSON.stringify({schema:1,target_data_dir:resolve(targetDataDir),config:douyinConfig(config)},null,2)+'\n');
}
export async function consumeDouyinSetup(plugins){
  const path=join(douyinRoot,'setup.pending.json');let data;
  try{data=JSON.parse(await readFile(path,'utf8'));}catch(e){if(e.code==='ENOENT')return null;throw e;}
  if(data.schema!==1||typeof data.target_data_dir!=='string')throw Error('抖音网页安装记录无效。');if(resolve(data.target_data_dir)!==resolve(plugins.config.dataDir))return null;
  const result=await applyDouyinSetup(plugins,data.config);await rename(path,join(douyinRoot,'setup.applied.json'));return result;
}
