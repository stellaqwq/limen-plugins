// Fixed first-party browser operations. Page content is data, never executable
// input from a model or a downloaded page.
export const pageHelpers=String.raw`
if(location.protocol!=='https:'||location.hostname!=='www.douyin.com'||location.port)return {ok:false,error:'outside_douyin'};
const visible=e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);return s.visibility!=='hidden'&&s.display!=='none'&&Number(s.opacity)!==0&&r.width>8&&r.height>8&&r.bottom>0&&r.right>0&&r.top<innerHeight&&r.left<innerWidth;};
const videos=[...document.querySelectorAll('video')].filter(visible).map(e=>{const r=e.getBoundingClientRect();return {e,r,area:Math.max(0,Math.min(r.right,innerWidth)-Math.max(0,r.left))*Math.max(0,Math.min(r.bottom,innerHeight)-Math.max(0,r.top))};}).sort((a,b)=>b.area-a.area);
const active=videos[0];
const socialPanelOpen=[...document.querySelectorAll('[data-e2e="im-dialog"],[data-e2e="im-panel"],[data-e2e="share-panel"],.lC5eOSqy')].some(visible);
const text=socialPanelOpen?'社交面板已打开，页面正文已隐藏。':(document.body?.innerText||'').slice(0,14000);
const modal=[...document.querySelectorAll('[role="dialog"],[aria-modal="true"],.douyin_login_new_class,[class*="login-modal"],[class*="captcha"]')].filter(visible).map(e=>(e.innerText||'').slice(0,1500)).join('\n');
const verification=/请完成.{0,8}验证|安全验证|拖动滑块|拖动下方滑块|访问过于频繁|操作过于频繁|访问受限|网络环境存在风险|请通过验证|验证码错误|检测到异常|扫码验证/.test(text+'\n'+modal);
const login=/登录|扫码|手机号/.test(modal)&&/登录|扫码/.test(modal);
const blocked=verification?'verification_required':login?'login_required':null;
`;
const helpers=pageHelpers;
export const snapshotExpression='(()=>{'+helpers+String.raw`
const addressId=location.pathname.match(/^\/video\/(\d{5,25})(?:\/|$)/)?.[1]||location.href.match(/[?&]modal_id=(\d{5,25})(?:[&#]|$)/)?.[1];
const anchor=active?.e.closest?.('[data-e2e="feed-active-video"]')?.querySelector('a[href*="/video/"]')?.getAttribute('href')||'';
const activeClass=active?.e.closest?.('[data-e2e="feed-active-video"]')?.className||'';
const videoId=/^\d{5,25}$/.test(addressId||'')?addressId:anchor.match(/\/video\/(\d{5,25})(?:[/?#]|$)/)?.[1]||String(activeClass).match(/\bvideo_(\d{5,25})\b/)?.[1]||null;
let mediaKey=null;const mediaSource=active?.e.currentSrc||active?.e.src||'';
if(mediaSource){let h=2166136261;for(let i=0;i<mediaSource.length;i++)h=Math.imul(h^mediaSource.charCodeAt(i),16777619);mediaKey='media-'+(h>>>0).toString(16);}

return {social_panel_open:socialPanelOpen,video_id:videoId,media_key:mediaKey,url:location.href,title:document.title.slice(0,200),text:text.slice(0,8000),blocked,visible_videos:videos.length,
 video:active?{paused:active.e.paused,ready_state:active.e.readyState,current_seconds:Number.isFinite(active.e.currentTime)?Math.round(active.e.currentTime*1000)/1000:null,duration_seconds:Number.isFinite(active.e.duration)?Math.round(active.e.duration*1000)/1000:null,x:Math.max(1,Math.min(innerWidth-1,active.r.left+active.r.width/2)),y:Math.max(1,Math.min(innerHeight-1,active.r.top+active.r.height/2)),width:active.r.width,height:active.r.height}:null};
})()`;
export const playbackExpression=action=>' (async()=>{'+helpers+String.raw`
if(blocked)return {ok:false,blocked};if(!active)return {ok:false,error:'no_video'};
`+(action==='play'?'await active.e.play();':'active.e.pause();')+String.raw`
return {ok:true,paused:active.e.paused};})()`;
