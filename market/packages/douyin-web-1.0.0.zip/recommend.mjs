import {setTimeout as delay} from 'node:timers/promises';
import {parameters} from '../_host/schema.mjs';
import {chatText} from '../_host/messages.mjs';
import {accountKey,peerKey} from './default-friend.mjs';

const fail=message=>Object.assign(Error(message),{status:409});
// Recognize only a direct request in the current message, never history or page text.
export function browseIntent(input=''){
  const text=input.trim().replace(/^(?:(?:请|你|麻烦你?|帮我|替我|现在|自己|去)\s*)+/u,'');
  const consent=text.replace(/(?:不感兴趣|没意思|没兴趣|不好玩|无趣)(?:的|就|时|可以|可|则|也|视频|内容|，|,|\s)*(?:不分享|不用分享|不发|不用发|跳过|略过)/gu,'');
  return !/(?:能否|能不能|可以吗|[?？]|(?:不要|别|不用|无需|不必|不)(?:自动)?(?:分享|转发|发给|发送)|(?:别|不要|不用|无需|停止|取消)(?:去|再)?(?:刷|看|浏览)|只看|只观看)/u.test(consent)&&
    /^(?:(?:打开|到|在)?抖音(?:上|里)?(?:去)?(?:刷|看)|(?:刷|看)(?:一会儿?|会儿?|一下|几条|几个|点|些|\d+条|[一二两三四五六七八九十]+条)?(?:抖音|视频))/u.test(text);
}
export function browseCount(text,maximum){
  const raw=text.match(/(?:刷|看)(\d{1,2})(?:条|个)/)?.[1]||text.match(/(?:刷|看)([一二两三四五六七八九十]{1,3})(?:条|个)/)?.[1];
  const digits={'一':1,'二':2,'两':2,'三':3,'四':4,'五':5,'六':6,'七':7,'八':8,'九':9};
  const n=/^\d+$/.test(raw||'')?Number(raw):raw==='十'?10:raw?.includes('十')?(digits[raw[0]]||1)*10+(digits[raw.at(-1)]||0):digits[raw];
  return Math.max(1,Math.min(maximum,n||5));
}

export const recommendTool={name:'douyin_recommend_current',effect:'write',description:'对当前实际采样的视频作明确决定：有意思时 decision=share 自动分享给默认好友并私信2–3句；无趣时 decision=skip，content 写简短原因；需结束本次任务时 decision=stop。skip/stop 不发送。先观察画面，引用最新 observation_id；content 根据真实可见内容撰写，不猜声音。收件人固定，不接受好友参数。同一视频持久去重，每任务有分享上限。提交不代表已送达；结果未知必须停止，不重发。工具会关闭社交面板以继续观看。',parameters:{...parameters({decision:{type:'string',enum:['share','skip','stop']},operation_id:{type:'string',minLength:1,maxLength:64},observation_id:{type:'string',maxLength:64},content:{type:'string',minLength:1,maxLength:1000}}),required:['decision','operation_id','observation_id','content']}};

export class DouyinRecommendations {
  constructor(service){
    this.service=service;this.db=service.store.db;
    this.db.exec(`CREATE TABLE IF NOT EXISTS douyin_recommendations (
      plugin_id TEXT NOT NULL,account_key TEXT NOT NULL,peer_key TEXT NOT NULL,source_key TEXT NOT NULL,
      job_id INTEGER NOT NULL,share_draft_id TEXT,message_draft_id TEXT,state TEXT NOT NULL,created_at INTEGER NOT NULL,
      PRIMARY KEY(plugin_id,account_key,peer_key,source_key));
      UPDATE douyin_recommendations SET state='uncertain' WHERE state NOT IN ('submitted','uncertain');`);
  }
  allowed(p,event,job){return !!p?.enabled&&!!p.config.browse_share_enabled&&!!p.config.social_enabled&&!!p.config.social_default_friend&&!event?.douyin_reply&&browseIntent(chatText(event));}
  summary(p,job){
    if(!p)return '任务权限已变化，请核对管理页中的执行记录。';
    const observations=this.service.owner?.id===job.id?[...this.service.owner.observations.values()].filter(e=>!e.blocked&&!e.mixed):[];
    const viewed=new Set(observations.map(e=>e.source_key)).size;
    const count=this.db.prepare("SELECT COUNT(*) n FROM douyin_recommendations WHERE plugin_id=? AND job_id=? AND state='submitted'").get(p.id,job.id).n;
    return '本次已采样 '+viewed+' 条视频；'+(count?'已向默认抖音好友 '+p.config.social_default_friend+' 提交 '+count+' 条视频分享及对应私信。':'本次没有提交视频分享或私信。');
  }
  prompt(p,event,job){return this.allowed(p,event,job)?'\n自主刷视频已获授权：只在本次明确刷视频指令中挑选自己觉得有意思的内容，通过 douyin_recommend_current 分享当前视频并给默认好友私信2–3句感想。接收人固定为已绑定的默认好友，不需要逐条确认，不使用普通草稿工具代替。先 status；社交面板打开时用 douyin_web_action(close_social) 关闭后观察。根据实际画面、当前人格和用户本次偏好判断，可以不分享，不要每条都发。每任务最多分享 '+p.config.browse_share_max_per_task+' 条，最多观看 '+p.config.max_videos+' 条；未指定数量时最多看 '+Math.min(5,p.config.max_videos)+' 条。每轮返回工具调用或简短可见正文，不要仅返回思考。每条观察后先按已开启的知识库规则归档，再必须调用 douyin_recommend_current，以 decision=share/skip/stop 明确决定；不能只在文字中说已分享。分享后需要先重新观察，再 next_video，不能再次决定同一条；skip 后直接 next_video。每次推荐用新的 operation_id；返回 submitted 只能称已提交，不能称已送达。遇到 uncertain、登录验证或页面无法确认时结束任务，不尝试其他发送方法。':'';}
  async send(p,job,args,signal,guard){
    const service=this.service,social=service.social,session=service.owner;
    const response=(result,stop=false)=>({result:{...result,next_action:'next_video'},...((stop||session?.videos>=(session?.browseTarget||p.config.max_videos))?{finish:true,reply:this.summary(p,job)}:{})});
    guard();service.checkOperation(args);
    const evidence=session?.observations.get(args.observation_id),lastId=session?.observations.keys().toArray().at(-1);
    const sampledAt=Date.parse(evidence?.samples.at(-1)?.captured_at||'');
    if(!Number.isSafeInteger(job.id)||!evidence||evidence.job_id!==job.id||lastId!==args.observation_id||!Number.isFinite(sampledAt)||Date.now()-sampledAt>p.config.max_task_seconds*1000||evidence.blocked||evidence.mixed)throw fail('请先采样当前视频，再决定是否分享。');
    if(!args.content?.trim()||args.content.length>1000)throw fail('请为视频写几句真实的私信感想。');
    const page=await service.page(signal);
    if(page.social_panel_open||page.blocked||!page.video||(page.video_id||page.media_key)!==(evidence.video_id||evidence.source_key))throw fail('当前视频已变化或被阻挡，请重新观察。');
    if(args.decision==='skip'||args.decision==='stop')return response({ok:true,decision:args.decision,skipped:true,reason:args.content},args.decision==='stop');
    const binding=social.defaults.info(p);
    if(!binding.bound)throw fail('请先在管理页核对并绑定默认抖音好友。');
    const count=this.db.prepare('SELECT COUNT(*) n FROM douyin_recommendations WHERE plugin_id=? AND job_id=?').get(p.id,job.id).n;
    if(count>=p.config.browse_share_max_per_task)return response({ok:true,decision:'skip',skipped:true,limited:true,message:'已达到自动分享上限，继续观看，不再发送。'});
    if(!evidence.video_id)throw fail('无法确认当前视频的唯一标识，未自动分享。');
    // Use a stable video ID to deduplicate across sessions and signed media URLs.
    let key,claimed=false,activated=false;
    const update=(state,share=null,message=null)=>this.db.prepare('UPDATE douyin_recommendations SET state=?,share_draft_id=COALESCE(?,share_draft_id),message_draft_id=COALESCE(?,message_draft_id) WHERE plugin_id=? AND account_key=? AND peer_key=? AND source_key=?').run(state,share,message,...key);
    const submit=async draft=>{
      guard();const options={guard,ownerJob:job,signal};
      const prepared=await social.action({id:draft.id,revision:draft.revision,action:'prepare'},options);
      guard();signal.throwIfAborted();activated=true;
      return social.action({id:draft.id,revision:prepared.draft.revision,action:'send',confirmation_token:prepared.confirmation_token},options);
    };
    try{
      await social.tool('douyin_social_open',{surface:'share'},p,signal);
      const inspected=await social.waitInspect('share',signal),[,contact]=social.defaultContact('share');
      const source=social.sources.get(inspected.source_ref);
      if(!source||source.key!==(evidence.video_id||evidence.source_key))throw fail('分享面板的视频与刚才采样不一致。');
      guard();key=[p.id,accountKey(contact.account),peerKey(contact.recipient),source.key];
      const prior=this.db.prepare('SELECT state FROM douyin_recommendations WHERE plugin_id=? AND account_key=? AND peer_key=? AND source_key=?').get(...key);
      if(prior){await social.closePanels(signal);return response({ok:prior.state==='submitted',decision:'skip',cached:true,uncertain:prior.state!=='submitted',state:prior.state,message:'这条视频已有自动分享记录，未重复发送。'});}
      this.db.prepare("INSERT INTO douyin_recommendations (plugin_id,account_key,peer_key,source_key,job_id,state,created_at) VALUES (?,?,?,?,?,'started',?)").run(...key,job.id,Date.now());claimed=true;
      const share=social.draft(p,{kind:'share_video',content:'',source_ref:inspected.source_ref});
      update('share_submitting',share.id);await submit(share);update('share_submitted');
      await social.closePanels(signal);
      guard();await social.tool('douyin_social_open',{surface:'messages',select_default:true},p,signal);
      const [,chatContact]=social.defaultContact('messages');
      if(accountKey(chatContact.account)!==key[1]||peerKey(chatContact.recipient)!==key[2])throw fail('私信会话与已分享的默认好友不一致，已停止。');
      const draft=social.draft(p,{kind:'private_message',content:args.content.trim()});
      update('message_submitting',null,draft.id);await submit(draft);update('submitted');
      // Read the outgoing record when chat reading is enabled; a button activation is never delivery proof.
      let messageObserved=false;
      if(p.config.chat_read_enabled){
        await delay(400,undefined,{signal});
        const messages=await social.readChat(20,signal);
        messageObserved=messages.messages.at(-1)?.direction==='self'&&messages.messages.at(-1)?.text===draft.content&&/^\d{10,25}$/.test(messages.messages.at(-1)?.server_id||'');
      }
      await social.closePanels(signal);session.observation=null;
      return response({ok:true,decision:'share',state:'submitted',share_submitted:true,message_submitted:true,message_observed:messageObserved,delivery_confirmed:false,recipient:p.config.social_default_friend,share_draft_id:share.id,message_draft_id:draft.id,notice:'已分别激活一次视频分享和私信发送；不代表对方已收到。'});
    }catch(error){
      if(claimed)update('uncertain');
      if(activated)return {result:{ok:false,uncertain:true,error:'自动分享或私信结果需核对，已停止且不会重发：'+error.message}};
      throw error;
    }
  }
}
