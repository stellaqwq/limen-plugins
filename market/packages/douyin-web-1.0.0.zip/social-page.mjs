// Site-scoped UI adapter. Chat text is read only in the verified default-chat phase.
// A message can only leave the page in the final `commit` branch.
export function socialPage(p){
  if(location.protocol!=='https:'||location.hostname!=='www.douyin.com'||location.port)return {ok:false,reason:'outside_douyin'};
  const visible=e=>{if(!e)return false;const r=e.getBoundingClientRect(),s=getComputedStyle(e);return s.display!=='none'&&s.visibility!=='hidden'&&s.opacity!=='0'&&r.width>4&&r.height>4&&r.right>0&&r.bottom>0&&r.left<innerWidth&&r.top<innerHeight;};
  const all=(root,s)=>[...root.querySelectorAll(s)].filter(visible),one=(root,s)=>{const a=all(root,s);return a.length===1?a[0]:null;};
  const text=e=>(e?.innerText||e?.getAttribute('aria-label')||e?.getAttribute('title')||'').trim().slice(0,100);
  if(p.phase==='diagnostic'){
    const attributes=e=>({tag:e.tagName,id:e.id||null,role:e.getAttribute('role'),e2e:e.getAttribute('data-e2e'),class:String(e.className?.baseVal||e.className||'').slice(0,180)});
    const inputs=all(document,'input,textarea,[contenteditable="true"]').slice(0,12).map(e=>({...attributes(e),placeholder:e.getAttribute('placeholder'),ancestors:[e.parentElement,e.parentElement?.parentElement,e.parentElement?.parentElement?.parentElement].filter(Boolean).map(attributes)}));
    const controls=all(document,'[data-e2e],button,[role="button"]').filter(e=>e.getAttribute('data-e2e')||/^(?:消息|私信|分享|发送|登录)$/.test(text(e))).slice(0,90).map(e=>({...attributes(e),label:/^(?:消息|私信|分享|发送|登录)$/.test(text(e))?text(e):null}));
    const chain=e=>{const a=[];for(let n=e,i=0;n&&i<7;n=n.parentElement,i++)a.push(attributes(n));return a;};
    const rows=all(document,'[data-e2e="conversation-item"]').slice(0,3).map(e=>{
      const propsKey=Object.keys(e).find(k=>k.startsWith('__reactProps$'));const fiberKey=Object.keys(e).find(k=>k.startsWith('__reactFiber$'));const fibers=[];let conversationMeta=null;for(let f=fiberKey?e[fiberKey]:null,i=0;f&&i<7;f=f.return,i++){fibers.push(Object.keys(f.memoizedProps||{}).slice(0,30));const c=f.memoizedProps?.conversation;if(c&&!conversationMeta)conversationMeta={keys:Object.keys(c).slice(0,40),id:c.id,type:c.type,conversationId:c.conversationId,conversationType:c.conversationType,core_keys:Object.keys(c.coreInfo||{}).slice(0,20)};}
      return {node:attributes(e),attributes:[...e.attributes].map(a=>({name:a.name,value:/^(?:data-user-id|data-conversation-id|data-id|aria-selected|data-selected)$/.test(a.name)?a.value:null})),children:[...e.querySelectorAll('*')].slice(0,18).map(attributes),prop_keys:propsKey?Object.keys(e[propsKey]||{}):[],fiber_keys:fibers,conversation_meta:conversationMeta};
    });
    const editor=all(document,'[contenteditable="true"]')[0];const avatars=all(document,'[data-e2e="live-avatar"]').map(e=>({ancestors:chain(e),profile_href:e.closest('a')?.getAttribute('href')||null,img_attributes:e.querySelector('img')?[...e.querySelector('img').attributes].map(a=>({name:a.name,value:/^(?:alt|title)$/.test(a.name)?a.value:null})):[]}));
    const entries=all(document,'[data-e2e="im-entry"]').map(e=>({ancestors:chain(e),controls:all(e.parentElement,'button,a,[role="button"]').slice(0,12).map(n=>({...attributes(n),label:text(n)}))}));const im=all(document,'[data-e2e="im-dialog"]')[0],headers=im?all(im,'[class*="Header"],[class*="header"]').slice(0,15).map(e=>({...attributes(e),leaf_text:e.children.length?null:text(e),children:[...e.children].slice(0,7).map(attributes)})):[];const send_controls=im?all(im,'button,[role="button"],[class*="send"],[class*="Send"]').slice(0,18).map(e=>({...attributes(e),label:text(e)})):[];const searches=all(document,'input[placeholder="搜索"]').map(e=>{let r=e;const ancestors=[];for(let i=0;r&&i<7;r=r.parentElement,i++)ancestors.push(attributes(r));const scope=e.parentElement?.parentElement?.parentElement?.parentElement;return {ancestors,children:scope?[...scope.querySelectorAll('*')].slice(0,60).map(attributes):[],images:scope?all(scope,'img').slice(0,4).map(img=>({chain:chain(img),fiber_keys:(()=>{const k=Object.keys(img).find(k=>k.startsWith('__reactFiber$')),a=[];for(let f=k?img[k]:null,i=0;f&&i<7;f=f.return,i++)a.push(Object.keys(f.memoizedProps||{}).slice(0,20));return a;})(),user_metadata:(()=>{const k=Object.keys(img).find(k=>k.startsWith('__reactFiber$'));for(let f=k?img[k]:null,i=0;f&&i<8;f=f.return,i++){const u=f.memoizedProps?.user;if(u)return {control_labels:all(img.closest('.otFjqQEX')||img.parentElement,'button,[role="button"],.xu0OjnsQ').map(text),keys:Object.keys(u).slice(0,40),has_sec_uid:!!(u.sec_uid||u.secUid||u.sec_user_id),type:u.conversation_type||u.conversationType};}return null;})()})):[]};});const selected_meta=im?all(im,'.StackLayoutStackChatHeadertitle').map(e=>{const k=Object.keys(e).find(k=>k.startsWith('__reactFiber$')),a=[];for(let f=k?e[k]:null,i=0;f&&i<35;f=f.return,i++){const c=f.memoizedProps?.conversation||f.memoizedProps?.currentConversation||f.memoizedProps?.curConversation;a.push({keys:Object.keys(f.memoizedProps||{}).slice(0,20),conversation:c?{id:c.id,type:c.type}:null});}return a;}):[];return {ok:true,share_layout:[...document.querySelectorAll('.lC5eOSqy,.VzoNDwLw,.Wl7JZ1MY,.WP9AZZAa,.otFjqQEX')].slice(0,10).map(e=>({class:e.className,width:e.getBoundingClientRect().width,height:e.getBoundingClientRect().height,display:getComputedStyle(e).display,visible:visible(e)})),selected_meta,inputs,controls,rows,entries,headers,send_controls,searches,editor_ancestors:editor?chain(editor):[],avatars};
  }
  const login=all(document,'.douyin_login_new_class,[class*="login-modal"],[class*="captcha"]');
  if(login.length)return {ok:false,reason:'login_or_verification'};
  if(p.phase==='close'){
    const panels=all(document,'[data-e2e="im-dialog"],[data-e2e="im-panel"],[data-e2e="share-panel"],.lC5eOSqy');
    if(!panels.length)return {ok:true,already_closed:true};
    if(panels.some(panel=>all(panel,'textarea,[contenteditable="true"]').some(e=>('value'in e?e.value:e.innerText).replace(/[\s\u200b]/g,'').length)))return {ok:false,reason:'existing_composer_text'};
    const buttons=panels.flatMap(panel=>all(panel,'[data-e2e="im-close"],[data-e2e="share-close"],button[aria-label="关闭"],[role="button"][aria-label="关闭"],.StackLayoutStackTitleBarclose'));
    const button=buttons.length===1?buttons[0]:panels.some(e=>e.matches('[data-e2e="im-dialog"],[data-e2e="im-panel"]'))?one(document,'[data-e2e="im-entry"]'):null;
    if(!button)return {ok:true,escape:true};
    const r=button.getBoundingClientRect(),point={x:r.left+r.width/2,y:r.top+r.height/2},hit=document.elementFromPoint(point.x,point.y);
    if(!hit||hit!==button&&!button.contains(hit))return {ok:false,reason:'open_manually'};
    return {ok:true,hover_point:point};
  }
  if(p.phase==='open'){
    if(all(document,p.surface==='messages'?'[data-e2e="im-dialog"],[data-e2e="im-panel"]':'[data-e2e="share-panel"],.lC5eOSqy').length)return {ok:true,already_open:true};
    const video=all(document,'video').sort((a,b)=>b.getBoundingClientRect().width*b.getBoundingClientRect().height-a.getBoundingClientRect().width*a.getBoundingClientRect().height)[0];
    const root=p.surface==='share'?(video?.closest('[data-e2e="feed-active-video"]')||video?.parentElement?.parentElement):document;
    if(!root)return {ok:false,reason:'no_video'};
    const selector=p.surface==='share'?'[data-e2e="video-player-share"],[data-e2e="video-share"],button[aria-label="分享"],[role="button"][aria-label="分享"]':'[data-e2e="im-entry"],[data-e2e="im-icon"],button[aria-label="消息"],[role="button"][aria-label="消息"]';
    let button=one(root,selector);
    if(!button&&p.surface==='messages')button=all(document,'header button,header [role="button"],[data-e2e="something-button"]').find(e=>text(e)==='消息');
    if(!button)return {ok:false,reason:'open_manually'};const rect=button.getBoundingClientRect();const point={x:rect.left+rect.width/2,y:rect.top+rect.height/2},hit=document.elementFromPoint(point.x,point.y);if(!hit||hit!==button&&!button.contains(hit))return {ok:false,reason:'open_manually'};return {ok:true,hover_point:point};
  }
  const conversation=e=>{const fkey=e&&Object.keys(e).find(k=>k.startsWith('__reactFiber$'));for(let f=fkey?e[fkey]:null,i=0;f&&i<16;f=f.return,i++){const c=f.memoizedProps?.conversation||f.memoizedProps?.currentConversation||f.memoizedProps?.curConversation;if(c&&typeof c.id==='string'&&c.id.length<160&&Number.isInteger(c.type))return {id:c.id,type:c.type,sec_uid:typeof c.toParticipantSecUserId==='string'?c.toParticipantSecUserId:''};}return null;};
  const roots=all(document,p.surface==='share'?'[data-e2e="share-panel"],[class*="share-panel"],[class*="sharePanel"],[role="dialog"],.lC5eOSqy':'[data-e2e="im-dialog"],[data-e2e="im-panel"],[class*="im-panel"],[class*="imPanel"],[class*="conversation-panel"],[class*="chat-panel"]');
  // Prefer the smallest visible root containing the expected controls.
  const valid=roots.filter(r=>p.surface==='share'?!!r.querySelector('[data-user-id],[data-e2e="share-contact"],[role="option"],.otFjqQEX'):!!r.querySelector('[data-e2e="conversation-item"],[data-e2e="im-contact"],[data-e2e="im-composer"],[contenteditable="true"],textarea'));
  const root=valid.sort((a,b)=>a.querySelectorAll('*').length-b.querySelectorAll('*').length)[0];
  if(!root)return {ok:false,reason:'open_manually'};
  const canonical=v=>{if(!v)return '';try{const u=new URL(v,location.origin);return (u.origin+u.pathname).slice(0,500);}catch{return '';}};
  const accountNodes=all(document,'header [data-e2e="user-avatar"],header [data-e2e="header-user-avatar"],[data-e2e="header-user-avatar"],[data-e2e="account-profile"]');
  const accounts=accountNodes.map(e=>{const a=e.matches('a')?e:e.querySelector('a[href*="/user/"]'),img=e.querySelector('img');return {uid:e.getAttribute('data-user-id')||a?.getAttribute('href')||'',name:e.getAttribute('aria-label')||img?.getAttribute('alt')||'',avatar:canonical(img?.getAttribute('src')||'')};}).filter(a=>a.uid||a.avatar);
  let account=accounts.length===1?accounts[0]:null;if(!account){const avatars=all(document,'[data-e2e="live-avatar"]').filter(e=>!e.closest('[data-e2e="feed-active-video"],[data-e2e="im-dialog"]')&&e.getBoundingClientRect().top<120&&e.closest('a')?.getAttribute('href')?.includes('/user/self'));if(avatars.length===1){const e=avatars[0],img=e.querySelector('img');account={uid:canonical(e.closest('a').getAttribute('href')),name:img?.getAttribute('alt')||'当前抖音账号',avatar:canonical(img?.getAttribute('src')||'')};}}
  const shareUser=e=>{const k=Object.keys(e).find(k=>k.startsWith('__reactFiber$'));for(let f=k?e[k]:null,i=0;f&&i<10;f=f.return,i++){const u=f.memoizedProps?.user;if(u&&typeof u==='object')return u;}return null;};
  const identity=e=>{
    const a=e.matches('a')?e:e.querySelector('a[href*="/user/"]'),img=e.querySelector('img');
    const name=e.getAttribute('data-contact-name')||text(e.querySelector('.conversationConversationItemtitle'))||text(e.querySelector('[data-e2e="contact-name"],[class*="nickname"],[class*="NickName"],[class*="contact-name"],[class*="conversation-name"],[class*="conversationConversationItemtitle"],.EnYt_IKl'))||img?.getAttribute('alt')||'';
    const metadata=conversation(e),shared=p.surface==='share'?shareUser(e):null;const user=e.getAttribute('data-user-id')||a?.getAttribute('href')||'',type=e.getAttribute('data-conversation-type')||'';
    const sec=shared?.sec_uid||shared?.secUid||shared?.sec_user_id||'';
    return {private:shared?!!sec&&shared.conversation_type!==2&&shared.conversationType!==2:metadata?metadata.type===1:!!user||/^(?:private|single)$/.test(type),uid:shared?'user:'+sec:metadata?'conversation:'+metadata.id:user||e.getAttribute('data-conversation-id')||'',name:(name||shared?.nickname||shared?.nick_name||'').trim().slice(0,80),avatar:canonical(img?.getAttribute('src')||''),canonical_id:shared?'user:'+sec:metadata?.sec_uid?'user:'+metadata.sec_uid:metadata?'conversation:'+metadata.id:user,handle:String(shared?.unique_id||shared?.short_id||'')};
  };
  const rows=all(root,'[data-e2e="share-contact"],[data-e2e="im-contact"],[data-e2e="conversation-item"],[data-conversation-id],[data-user-id],[role="option"],[class*="conversation-item"],[class*="conversationItem"],.otFjqQEX');
  const contacts=rows.map(e=>({element:e,...identity(e)})).filter(c=>c.private&&c.name&&(c.uid||c.avatar));
  const pairs=contacts.map(c=>c.uid.match(/^conversation:[^:]+:1:(\d+):(\d+)$/)).filter(Boolean).map(m=>m.slice(1));if(account&&pairs.length>=2){const shared=pairs[0].filter(id=>pairs.every(pair=>pair.includes(id)));if(shared.length===1)account={...account,uid:'im-user:'+shared[0]};}
  const avatarKey=v=>String(v||'').replace(/^https:\/\/p\d+-pc-sign\.douyinpic\.com\//,'https://douyinpic.com/');
  const key=c=>JSON.stringify({uid:c.uid,name:c.name,avatar:avatarKey(c.avatar)});
  const sameAccount=(a,b)=>JSON.stringify({...a,avatar:avatarKey(a.avatar)})===JSON.stringify({...b,avatar:avatarKey(b.avatar)});
  const groups=new Map();for(const c of contacts){const k=key(c);if(!groups.has(k))groups.set(k,[]);groups.get(k).push(c);}
  if(p.source_key){
    const videos=all(document,'video').sort((a,b)=>b.getBoundingClientRect().width*b.getBoundingClientRect().height-a.getBoundingClientRect().width*a.getBoundingClientRect().height),v=videos[0];
    const address=location.pathname.match(/^\/video\/(\d{5,25})(?:\/|$)/)?.[1]||location.href.match(/[?&]modal_id=(\d{5,25})(?:[&#]|$)/)?.[1];
    const container=v?.closest?.('[data-e2e="feed-active-video"]');
    const a=container?.querySelector('a[href*="/video/"]')?.getAttribute('href')||'';let k=address||a.match(/\/video\/(\d{5,25})(?:[/?#]|$)/)?.[1]||String(container?.className||'').match(/\bvideo_(\d{5,25})\b/)?.[1];
    if(!k&&v){const src=v.currentSrc||v.src||'';if(src){let h=2166136261;for(let i=0;i<src.length;i++)h=Math.imul(h^src.charCodeAt(i),16777619);k='media-'+(h>>>0).toString(16);}}
    if(k!==p.source_key)return {ok:false,reason:'source_changed'};
  }
  const recipient=p.recipient&&groups.get(key(p.recipient));
  const selected=()=>{
    if(!p.recipient)return false;
    const active=contacts.filter(c=>c.element.getAttribute('aria-selected')==='true'||c.element.getAttribute('data-selected')==='true'||c.element.querySelector('input[type="checkbox"]:checked'));
    if(p.surface==='share'&&recipient?.length===1&&recipient[0].element.matches('.otFjqQEX')&&one(recipient[0].element,'.xu0OjnsQ'))return true;
    if(p.surface==='share')return active.length===1&&key(active[0])===key(p.recipient);
    const header=one(root,'[data-e2e="im-chat-header"],[data-e2e="chat-title"],[class*="chat-header"] [class*="name"],[class*="chatHeader"] [class*="name"],.StackLayoutStackChatHeadertitle');
    if(!header||text(header)!==p.recipient.name)return false;
    const metadata=conversation(header);if(metadata)return metadata.type===1&&'conversation:'+metadata.id===p.recipient.uid;
    return active.length===1&&key(active[0])===key(p.recipient);
  };
  const composer=()=>one(root,p.surface==='share'?'[data-e2e="share-message"],textarea[placeholder*="留言"],textarea[placeholder*="说点"]':'[data-e2e="im-composer"],[data-e2e="msg-input"] [contenteditable="true"],textarea,[contenteditable="true"][role="textbox"]');
  const read=e=>{const value=e?('value'in e?e.value:e.innerText).replace(/\r\n/g,'\n').replace(/\u200b$/,''):'';return /^[\n\u200b]*$/.test(value)?'':value;};
  const send=()=>{if(p.surface==='share'&&recipient?.length===1&&recipient[0].element.matches('.otFjqQEX')){const button=one(recipient[0].element,'.xu0OjnsQ');return button&&['发送','分享'].includes(text(button))?button:null;}const buttons=all(root,'button,[role="button"],.e2e-send-msg-btn');const candidates=buttons.filter(e=>(text(e)==='发送'||p.surface==='share'&&text(e)==='分享'||p.surface==='messages'&&e.matches('.e2e-send-msg-btn'))&&!e.classList.contains('disabled')&&!e.parentElement?.classList.contains('disabled')&&!e.disabled&&e.getAttribute('aria-disabled')!=='true');return candidates.length===1?candidates[0]:null;};
  if(p.phase==='inspect')return {ok:true,account,contacts:[...groups.values()].filter(g=>g.length===1).slice(0,30).map(g=>({uid:g[0].uid,name:g[0].name,avatar:g[0].avatar,canonical_id:g[0].canonical_id,handle:g[0].handle})),ambiguous:groups.size!==contacts.length,composer_present:!!composer(),composer_empty:!read(composer()).trim(),send_control_present:!!send(),selected_uid:(()=>{const h=one(root,'[data-e2e="im-chat-header"],.StackLayoutStackChatHeadertitle');const c=h&&conversation(h);return c?'conversation:'+c.id:null;})()};
  if(!account||!p.account||!sameAccount(account,p.account))return {ok:false,reason:'account_changed'};
  if(!recipient||recipient.length!==1)return {ok:false,reason:'recipient_ambiguous'};
  if(p.phase==='select'){
    const selectedContacts=contacts.filter(c=>c.element.getAttribute('aria-selected')==='true'||c.element.getAttribute('data-selected')==='true'||c.element.querySelector('input[type="checkbox"]:checked'));
    if(p.surface==='share'&&selectedContacts.some(c=>key(c)!==key(p.recipient)))return {ok:false,reason:'other_recipient_selected'};
    if(p.surface==='share'&&recipient[0].element.matches('.otFjqQEX'))return {ok:true,direct_share:true};
    if(!selected()){const e=recipient[0].element;e.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,button:0,buttons:1,view:window}));if(typeof e.click==='function')e.click();}return {ok:true};
  }
  if(!selected())return {ok:false,reason:'recipient_changed'};
  if(p.phase==='read_chat'){
    if(p.surface!=='messages')return {ok:false,reason:'recipient_changed'};
    const nodes=all(root,'[data-e2e="msg-item-content"],[data-e2e="chat-message"]').slice(0,200);
    const messages=nodes.map(e=>{
      const k=Object.keys(e).find(k=>k.startsWith('__reactFiber$'));let m=null;for(let f=k?e[k]:null,i=0;f&&i<14;f=f.return,i++){const candidate=f.memoizedProps?.message||f.memoizedProps?.msg;if(candidate&&typeof candidate==='object'){m=candidate;break;}}
      const sender=String(m?.sender||m?.senderUid||m?.senderId||e.getAttribute('data-sender-id')||'');
      const direction=sender&&p.self_uid?(sender===p.self_uid?'self':sender===p.peer_uid?'peer':'unknown'):(e.getAttribute('data-direction')||'unknown');
      const id=String(m?.serverId||m?.clientId||m?.id||e.getAttribute('data-message-id')||'');
      const content=(e.innerText||'').trim().slice(0,1200);
      return {id:id.slice(0,160),direction,text:content,kind:content?'text':'attachment',server_id:m?.serverId?String(m.serverId):null};
    });
    const ordered=messages.every(m=>/^\d{10,25}$/.test(m.server_id||''));if(ordered)messages.sort((a,b)=>BigInt(a.server_id)<BigInt(b.server_id)?-1:BigInt(a.server_id)>BigInt(b.server_id)?1:0);
    return {ok:true,messages:messages.slice(-(p.limit||12)),order:ordered?'oldest_to_newest_by_server_id':'dom_order',scope:'selected_default_friend',partial_history:true};
  }
  if(p.expected_incoming_id){
    const ids=all(root,'[data-e2e="msg-item-content"],[data-e2e="chat-message"]').slice(0,200).map(e=>{const k=Object.keys(e).find(k=>k.startsWith('__reactFiber$'));for(let f=k?e[k]:null,i=0;f&&i<14;f=f.return,i++){const m=f.memoizedProps?.message||f.memoizedProps?.msg;if(m&&typeof m==='object')return String(m.serverId||'');}return e.getAttribute('data-message-id')||'';});
    if(!ids.length||ids.some(id=>!/^\d{10,25}$/.test(id)))return {ok:false,reason:'incoming_changed'};
    const latest=ids.reduce((a,b)=>BigInt(a)>BigInt(b)?a:b);if(latest!==p.expected_incoming_id)return {ok:false,reason:'incoming_changed'};
  }
  const editor=composer();
  if(p.phase==='focus'){
    if(!editor){if(p.surface==='share'&&!p.content)return {ok:true,no_editor:true};return {ok:false,reason:'no_composer'};}
    if(read(editor)===p.content)return {ok:true,already_filled:true};if(read(editor))return {ok:false,reason:'existing_composer_text'};editor.focus();return {ok:true};
  }
  if(p.phase==='preflight'||p.phase==='commit'){
    if((editor?read(editor):'')!==p.content)return {ok:false,reason:'content_changed'};
    const button=send();if(!button)return {ok:false,reason:'no_send_button'};
    if(p.phase==='preflight')return {ok:true};
    // Exactly one activation; no retry or Enter-key fallback.
    if(typeof button.click==='function')button.click();else button.dispatchEvent(new MouseEvent('click',{bubbles:true,button:0,view:window}));return {ok:true,submitted:true};
  }
  return {ok:false,reason:'invalid_phase'};
}
export const socialExpression=params=>'('+socialPage.toString()+')('+JSON.stringify(params)+')';
