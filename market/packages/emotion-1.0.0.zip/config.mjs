import {applyConfigSchema} from '../_host/config-schema.mjs';

const field=(type,description,value,group,extra={})=>({type,description,default:value,group,...extra});
const level=(description,value,group)=>field('float',description,value,group,{slider:{min:0,max:1,step:0.01}});
const integer=(description,value,min,max,group)=>field('int',description,value,group,{slider:{min,max,step:1}});
export const emotionSchema={
  intensity:level('情绪表达强度',0.65,'表达风格'),
  warmth:level('基础温暖程度',0.6,'表达风格'),
  spontaneity:level('自然活泼程度',0.45,'表达风格'),
  sensitivity:level('对情境的敏感度',0.55,'心理动力'),
  ego_strength:level('自我调节能力',0.75,'心理动力'),
  superego_strength:level('分寸与责任意识',0.7,'心理动力'),
  max_step:field('float','每轮最大情绪变化',0.25,'心理动力',{slider:{min:0.05,max:0.5,step:0.01}}),
  recovery_minutes:integer('短期情绪恢复半衰期（分钟）',45,1,1440,'情绪延续'),
  relationship_days:integer('熟悉感与信任恢复半衰期（天）',14,1,365,'情绪延续'),
  memory_resonance:field('bool','召回记忆时增加熟悉感',true,'情绪延续',{hint:'只根据本轮是否召回本人记忆增加轻微熟悉感，不把旧记忆中的情绪当成当前刺激。'}),
  appraisal_mode:field('string','情境理解方式','hybrid','情境理解',{options:['hybrid','rules'],hint:'hybrid 在本地规则不确定时额外调用模型，失败自动回退。rules 仅使用本地规则。'}),
  appraisal_model:field('string','情境理解模型（留空使用主模型）','','情境理解'),
  appraisal_timeout_ms:integer('情境理解超时（毫秒）',4000,100,15000,'情境理解'),
  appraisal_reasoning_effort:field('string','情境理解推理强度（留空沿用 AI 设置）','','情境理解',{options:['','none','minimal','low','medium','high','xhigh']}),
  retention_days:integer('情绪状态保留天数',90,1,365,'数据保留'),
  max_scopes:integer('最多保存的用户与人格状态数',2000,10,10000,'数据保留')
};
export function emotionConfig(value={}) {
  const c=applyConfigSchema(emotionSchema,value);
  if(Object.keys(c).some(key=>!Object.hasOwn(emotionSchema,key)))throw Object.assign(Error('情绪插件存在未知配置项。'),{status:400});
  if(c.appraisal_model.length>200)throw Object.assign(Error('情境理解模型标识不能超过 200 字。'),{status:400});
  return c;
}
export const emotionTemplate={
  schema:1,kind:'psychodynamic-emotion',name:'心绪 · 心理动力情绪',version:'1.0.0',
  description:'借鉴本我、自我与超我的协调机制：情绪积累与恢复、熟悉感、情境共情和克制表达，让对话语气自然连贯。/emotion help 查看指令。',
  source:'// 内置心理动力情绪执行层；在 AI 生成前注入本轮表达建议，不改变人格或工具权限。\n',
  trigger:'',priority:21,timeout_ms:10000,
  scope:{private_users:[],groups:[],all_private:false,all_groups:false,require_at:true},
  config:emotionConfig(),config_schema:emotionSchema
};
