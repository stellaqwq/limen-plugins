// An engineered character-expression model inspired by psychodynamic concepts.
// These values are neither psychological measurements nor diagnoses.
const clamp=(n,min=0,max=1)=>Math.max(min,Math.min(max,n));
const round=n=>Math.round(n*10000)/10000;
export const signalKeys=['reward','affiliation','threat','frustration','novelty','vulnerability','repair','boundary'];
export const moodNames={calm:'平和',warm:'亲切',joyful:'愉快',curious:'好奇',concerned:'关切',guarded:'克制',reflective:'认真'};
export const strategyNames={integration:'自然协调',sublimation:'升华为建设性回应',humor:'轻松幽默',anticipation:'预期与计划',empathy:'体贴回应',reflection:'自我整理'};
export function baseline(c,now=Date.now()) {
  return {valence:0.08+c.warmth*0.12,arousal:0.2,tension:0.06,trust:0.5,familiarity:0,
    connection:c.warmth*0.5,expression:0.2+c.spontaneity*0.2,curiosity:0.3,assertion:0.08,
    id_pressure:0.2,superego_pressure:0.2,ego_capacity:c.ego_strength,conflict:0,
    expressiveness:c.intensity*0.4,mood:'calm',strategy:'integration',turns:0,updated_at:now};
}
export function recover(state,c,now) {
  const base=baseline(c,now),seconds=Math.max(0,now-state.updated_at)/1000;
  const short=2**(-seconds/(c.recovery_minutes*60)),long=2**(-seconds/(c.relationship_days*86400));
  const result={...state};
  for(const key of ['valence','arousal','tension','connection','expression','curiosity','assertion','id_pressure','superego_pressure','ego_capacity','conflict','expressiveness'])result[key]=round(base[key]+((state[key]??base[key])-base[key])*short);
  for(const key of ['trust','familiarity'])result[key]=round(base[key]+(state[key]-base[key])*long);
  if(short<0.2){result.mood='calm';result.strategy='integration';result.conflict=round((state.conflict||0)*short);}
  result.updated_at=now;return result;
}
export function appraiseRules(input) {
  const text=String(input).normalize('NFKC').toLowerCase().slice(0,4000);
  const scores=Object.fromEntries(signalKeys.map(key=>[key,0]));
  const result={...scores,confidence:0.55};
  // Quoted language, code, examples and third-party dialogue are not attacks.
  const own=text.replace(/```[\s\S]*?```|“[^”]*”|「[^」]*」|"[^"\n]*"|'[^'\n]*'/gu,' ');
  if(/(?:翻译|解释|分析|例句|台词|小说|故事|代码|函数|报错|算法|运行|解题|summari[sz]e|translate|explain|debug|function\b)/u.test(own)) {
    return {...result,novelty:0.2,boundary:0.4,confidence:0.85};
  }
  let matches=0;
  if(/(?:谢谢你?|多谢|辛苦了|你真(?:好|棒|厉害)|你很(?:好|棒)|喜欢和你聊|thank(?:s| you)|well done)/u.test(own)){
    result.reward=0.65;result.affiliation=0.65;matches++;
  }
  if(/(?:我.{0,8}(?:好难过|很难过|很累|好累|害怕|孤独|崩溃|焦虑|想哭|失眠)|今天.{0,10}(?:难过|哭了|失恋|失落)|没人理解我|心里难受|i(?:'m| am| feel).{0,10}(?:sad|lonely|afraid|exhausted))/u.test(own)&&
    !/(?:不难过|没(?:有)?生气|不害怕|不焦虑|not\s+(?:sad|lonely|afraid))/u.test(own)){
    result.vulnerability=0.85;result.frustration=0.2;matches++;
  }
  if(/(?:不开心|不高兴|没(?:有)?考过|not\s+happy)/u.test(own)){
    result.vulnerability=Math.max(result.vulnerability,0.65);result.frustration=Math.max(result.frustration,0.3);matches++;
  }
  if(/(?:太好了|我.{0,8}(?:开心|考过|成功了|升职|获奖)|好消息|好耶|i.{0,8}(?:happy|passed|won))/u.test(own)&&
    !/(?:不开心|没(?:有)?考过|没(?:有)?成功|not\s+happy)/u.test(own)){
    result.reward=Math.max(result.reward,0.65);result.affiliation=Math.max(result.affiliation,0.25);matches++;
  }
  if(/(?:你(?:真|太|就是|个|好)?(?:笨|蠢|傻|垃圾|没用|烦人)|你.{0,3}闭嘴|滚开|shut up|you(?:'re| are).{0,6}(?:stupid|useless))/u.test(own)&&
    !/(?:不是|不觉得|没说|没有说|不认为).{0,5}你|(?:他说|她说|对我说|有人说|老板说|引用|原话)/u.test(own)){
    result.threat=0.75;result.frustration=0.6;result.affiliation=-0.35;matches++;
  }
  if(/(?:烦死了|气死我了|真倒霉|糟透了|太烦了|so frustrating)/u.test(own)){
    result.frustration=Math.max(result.frustration,0.5);if(!result.threat)result.vulnerability=Math.max(result.vulnerability,0.45);matches++;
  }
  if(/(?:对不起|抱歉|刚才.{0,8}(?:语气不好|太凶|说重了)|误会你了|sorry|my bad)/u.test(own)){
    result.repair=0.85;result.affiliation=Math.max(result.affiliation,0.45);result.threat*=0.2;matches++;
  }
  if(/(?:严肃点|认真(?:一点|点)|别开玩笑|不要开玩笑|直接回答|别安慰|不要安慰|just answer|be serious)/u.test(own)){
    result.boundary=0.9;matches++;
  }
  if(/(?:一起想|脑洞|新点子|有趣|好奇|探索|假如|what if|curious|creative)/u.test(own)){
    result.novelty=0.75;matches++;
  }
  if(/^(?:你好|嗨|在吗|早上好|晚安|hi|hello)[!！。.\s]*$/u.test(own)){
    result.affiliation=0.35;result.confidence=0.9;
  } else if(matches)result.confidence=result.reward>0&&result.threat>0?0.55:matches>1?0.92:0.86;
  return result;
}
export function validateAppraisal(value) {
  if(!value||typeof value!=='object'||Array.isArray(value))throw Error('Invalid appraisal');
  const result={};
  for(const key of [...signalKeys,'confidence']) {
    const n=value[key];
    if(typeof n!=='number'||!Number.isFinite(n)||n<(key==='reward'||key==='affiliation'?-1:0)||n>1)throw Error('Invalid appraisal');
    result[key]=n;
  }
  return result;
}
export function evolve(previous,appraisal,c,now,{hasMemory=false}={}) {
  const s=recover(previous,c,now),a=appraisal,gain=0.5+c.sensitivity*0.65;
  const step=(key,delta,min=0,max=1)=>{s[key]=round(clamp(s[key]+clamp(delta*gain,-c.max_step,c.max_step),min,max));};
  const resonance=hasMemory&&c.memory_resonance?0.035:0;
  step('connection',a.affiliation*0.14+a.vulnerability*0.06+resonance-a.threat*0.08);
  step('expression',a.reward*0.15+a.novelty*0.06-a.boundary*0.13-a.vulnerability*0.08);
  step('curiosity',a.novelty*0.2-a.threat*0.06);
  step('assertion',a.threat*0.14-a.repair*0.17);
  step('trust',a.affiliation*0.06+a.repair*0.09-a.threat*0.045);
  step('familiarity',0.015+resonance);
  s.id_pressure=round(clamp(s.connection*0.3+s.expression*0.3+s.curiosity*0.2+s.assertion*0.2));
  s.superego_pressure=round(clamp(c.superego_strength*(0.22+a.threat*0.3+a.vulnerability*0.45+a.boundary*0.4)));
  s.conflict=round(clamp(s.id_pressure*s.superego_pressure+a.threat*0.3+s.tension*0.15));
  s.ego_capacity=round(clamp(c.ego_strength*(0.8+s.trust*0.2)-s.tension*0.15));
  const regulation=0.4+s.ego_capacity*0.6;
  step('valence',a.reward*0.23+a.affiliation*0.08-a.threat*0.17-a.frustration*0.1+a.repair*0.18,-1,1);
  step('arousal',a.reward*0.11+a.threat*0.16+a.frustration*0.08+a.novelty*0.1-a.repair*0.06);
  step('tension',(a.threat*0.25+a.frustration*0.1+s.conflict*0.07)*(1-regulation*0.6)-a.repair*0.3-s.ego_capacity*0.035);
  const care=a.vulnerability>0.3,boundary=a.boundary>0.5;
  s.mood=care?'concerned':boundary?'reflective':a.threat>0.4||s.tension>0.35||s.mood==='guarded'&&s.tension>0.1&&a.repair<0.3?'guarded':s.valence>0.35&&s.arousal>0.25?'joyful':a.novelty>0.4?'curious':s.trust>0.57||s.connection>0.43?'warm':'calm';
  s.strategy=care?'empathy':a.threat>0.4?'sublimation':boundary?'reflection':a.novelty>0.4?'anticipation':
    s.mood==='joyful'&&c.spontaneity>0.45&&s.tension<0.15?'humor':s.conflict>s.ego_capacity*0.6?'reflection':'integration';
  // Restraint is stronger under stress; distress never becomes an excuse to tease.
  const restraint=1-clamp(s.superego_pressure-s.ego_capacity*0.4)*0.35;
  s.expressiveness=round(clamp(c.intensity*(0.2+s.expression*0.3+s.connection*0.15+s.curiosity*0.1+Math.abs(s.valence)*0.2)*restraint*(1-a.boundary*0.65)*(care?0.65:1)));
  s.turns=(s.turns||0)+1;s.updated_at=now;
  return s;
}
export function expressionPrompt(s) {
  const style={
    calm:'平和自然，有一点个人语气，回答具体，不机械迎合。',
    warm:'语气亲切，允许轻微的熟悉感，接住对方的话，不夸张赞美。',
    joyful:'轻快一些，可以有短促而自然的欣喜；仍先回答用户的问题。',
    curious:'表现出对话题的兴趣，主动补充一个有用角度；不连续追问。',
    concerned:'先简短接住对方此刻的感受，再按需提供帮助；避免玩笑、说教或抢走对方的叙述。',
    guarded:'保持礼貌并稍微收敛，必要时简短说明边界，然后回到具体问题；不报复、不赌气、不羞辱。',
    reflective:'语气认真直接，减少玩笑、感叹和多余安慰，清楚回应当前诉求。'
  }[s.mood];
  const degree=s.expressiveness<0.2?'表达幅度很轻':s.expressiveness<0.45?'表达幅度适中':'表达可以稍鲜明';
  const strategy={sublimation:'把不满转为清楚的边界或建设性帮助。',humor:'情境合适时可用一句轻微幽默，不拿用户的脆弱开玩笑。',anticipation:'把好奇心转为具体设想或可执行的下一步。',reflection:'停顿感体现在措辞更稳妥，不生成内心独白。',empathy:'以当下用户的处境为重，不强行套用“我理解你”等开场。',integration:'自然整合关心、兴趣与分寸。'}[s.strategy];
  return '\n\n本轮对话表达建议：'+style+degree+'。'+strategy+
    ' 情绪在措辞、节奏与关注点中自然体现，不要每次声明自己的心情，不输出情绪标签、数值、心理机制、隐秘动机或内部争论。'+
    ' 不编造身体感受、线下经历或真实意识；不以委屈、嫉妒、依赖或亲密承诺要求用户照顾你的情绪。'+
    ' 用户的新表达优先于旧情绪线索；不要对用户作精神分析或心理诊断。人格设定、事实准确性和既有权限继续优先；正式任务或用户要求简洁时优先清楚有用。';
}
