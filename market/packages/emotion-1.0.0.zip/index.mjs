import { EmotionService } from './service.mjs';
import { emotionConfig, emotionTemplate, emotionSchema } from './config.mjs';

export const template = () => emotionTemplate;
export const config = value => emotionConfig(value);
export const schema = () => emotionSchema;

export function create(ctx) {
  const service = new EmotionService({
    store: ctx.store, config: ctx.config, log: ctx.log,
    appraisalAI: ctx.overrides.emotionAI,
    ...(ctx.overrides.emotionNow ? { now: ctx.overrides.emotionNow } : {})
  });
  service.pluginFor = event => ctx.plugins.find('psychodynamic-emotion', event);
  service.plugins = () => ctx.plugins.rows().filter(row => row.kind === 'psychodynamic-emotion');
  return service;
}

export const run = (service, plugin, event, { dryRun }) => service.handle(plugin, event, { dryRun });
export const destroy = (service, id) => service?.remove?.(id);
