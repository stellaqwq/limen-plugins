import { FreeActivity, activityIntent, activityTemplate, activitySchema } from './service.mjs';
import { applyConfigSchema } from '../_host/config-schema.mjs';

export const template = () => activityTemplate;
export const config = value => applyConfigSchema(activitySchema, value ?? {});
export const schema = () => activitySchema;
export { activityIntent };

export function create(ctx) {
  const service = new FreeActivity({ store: ctx.store, config: ctx.config, plugins: ctx.plugins, adapter: ctx.adapter, log: ctx.log });
  service.intent = activityIntent;
  return service;
}
