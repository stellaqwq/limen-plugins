import {randomUUID} from 'node:crypto';
import {nextDaily} from './service.mjs';
const fail=(message,status=400)=>Object.assign(Error(message),{status});
export class ActivitySchedules {
  constructor(service){this.service=service;this.db=service.db;}
  plugin(id){const p=this.service.plugins.get(id);if(p.kind!=='free-activity')throw fail('请选择自由活动插件。');return p;}
  targets(p){const s=this.service;return [...s.config.adminIds].filter(id=>s.config.ai.allowedUsers.has(id)&&(p.scope.all_private||p.scope.private_users.includes(id)));}
  snapshot(id){
    const p=this.plugin(id),rows=this.db.prepare('SELECT * FROM free_activity_schedules WHERE plugin_id=? ORDER BY enabled DESC,created_at DESC LIMIT 100').all(id);
    return {plugin_id:p.id,plugin_revision:p.revision,enabled:p.enabled,timezone:'Asia/Shanghai',targets:this.targets(p),max_schedules:p.config.max_schedules,
      schedules:rows.map(r=>{const e=JSON.parse(r.event),pending=r.pending_job?this.service.store.get(r.pending_job):null;return {id:r.id,revision:r.revision,conversation:r.conversation,channel:r.channel,user_id:String(e.user_id),mode:r.mode,interval_minutes:r.interval_ms/60000,daily:r.daily,next_at:r.next_at,focus:r.focus,enabled:!!r.enabled,pending_status:pending?.status||null,delay_minutes:Math.max(1,Math.ceil((r.next_at-Date.now())/60000))};})};
  }
  action(params){return this.service.plugins.mutate(()=>this.perform(params));}
  perform(params){
    const {plugin_id,plugin_revision,action,id,revision}=params,p=this.plugin(plugin_id),s=this.service;
    s.plugins.checkRevision(p,plugin_revision);
    if(!['save','toggle','delete'].includes(action))throw fail('未知定时操作。');
    const old=id?this.db.prepare('SELECT * FROM free_activity_schedules WHERE id=? AND plugin_id=?').get(id,p.id):null;
    if(id&&!old)throw fail('定时已被删除，请刷新后重试。',404);
    if(old&&old.revision!==revision)throw fail('定时已被其他窗口或聊天指令修改，请刷新后重新编辑。',409);
    if(action!=='save'&&!old)throw fail('请选择定时。');
    const stop=()=>{this.db.prepare('UPDATE free_activity_schedules SET enabled=0,revision=revision+1 WHERE id=?').run(old.id);s.cancelPending(old.conversation);};
    if(action==='delete'){stop();this.db.prepare('DELETE FROM free_activity_schedules WHERE id=?').run(old.id);return this.snapshot(p.id);}
    if(action==='toggle'&&params.enabled===false){stop();return this.snapshot(p.id);}
    if(action==='toggle'&&params.enabled!==true)throw fail('请选择启用或停用。');
    const input=action==='toggle'?{...old,interval_minutes:old.interval_ms/60000,delay_minutes:Math.max(1,Math.ceil((old.next_at-Date.now())/60000)),enabled:true,user_id:String(JSON.parse(old.event).user_id)}:params;
    if(typeof input.enabled!=='boolean')throw fail('定时启用状态无效。');
    if(input.enabled&&!p.enabled)throw fail('请先保存并启用自由活动插件，再启用定时。');
    if(typeof input.focus!=='string'||input.focus.length>1000)throw fail('活动方向最多 1000 字。');
    const now=Date.now(),mode=input.mode;let next,interval=0,daily='';
    if(mode==='interval'){if(!Number.isSafeInteger(input.interval_minutes)||input.interval_minutes<1||input.interval_minutes>43200)throw fail('间隔应为 1–43200 分钟的整数。');interval=input.interval_minutes*60000;next=now+interval;}
    else if(mode==='daily'){if(typeof input.daily!=='string')throw fail('请选择每天执行的时间。');daily=input.daily;next=nextDaily(daily,now);}
    else if(mode==='once'){if(!Number.isSafeInteger(input.delay_minutes)||input.delay_minutes<1||input.delay_minutes>527040)throw fail('延后时间应为 1–527040 分钟的整数。');next=now+input.delay_minutes*60000;}
    else throw fail('请选择间隔、每天或延后一次。');
    let event,job;
    if(old?.channel==='web'){
      if(input.user_id!==String(JSON.parse(old.event).user_id))throw fail('已有网页定时不能改为 QQ 会话。');
      event=JSON.parse(old.event);job={channel:'web',conversation:old.conversation};
    }else{
      if(!this.targets(p).includes(input.user_id))throw fail('请选择同时符合管理员、AI 白名单和插件范围的好友 QQ。');
      const currentAccount=Number(s.adapter.driver.account),accountReady=Number.isSafeInteger(currentAccount)&&currentAccount>0;
      if(input.enabled&&!accountReady)throw fail('请先登录机器人账号，再启用 QQ 定时。');
      const account=accountReady?currentAccount:0;
      event={post_type:'message',message_type:'private',self_id:account,user_id:Number(input.user_id),message_id:randomUUID(),message:[{type:'text',data:{text:'自由活动'}}]};
      job={channel:'qq',conversation:account+':private:'+input.user_id};
    }
    if(input.enabled&&!s.allowed(event,job))throw fail('当前 AI、Agent 或会话权限未开启，请检查后重试。');
    const count=this.db.prepare('SELECT COUNT(*) n FROM free_activity_schedules WHERE plugin_id=? AND conversation=? AND enabled=1 AND id!=?').get(p.id,job.conversation,old?.id||'').n;
    if(input.enabled&&count>=p.config.max_schedules)throw fail('本会话定时数量已满，请先停用或删除旧定时。');
    // Replacing a schedule cancels its queued/running round before rebinding it.
    if(old)stop();
    const values=[JSON.stringify(event),job.conversation,job.channel,mode,interval,daily,next,input.focus.trim()||'按照兴趣自主选择',Number(input.enabled),s.persona(job)];
    if(old)this.db.prepare('UPDATE free_activity_schedules SET event=?,conversation=?,channel=?,mode=?,interval_ms=?,daily=?,next_at=?,focus=?,enabled=?,persona=?,pending_job=NULL WHERE id=?').run(...values,old.id);
    else this.db.prepare('INSERT INTO free_activity_schedules(event,conversation,channel,mode,interval_ms,daily,next_at,focus,enabled,persona,id,plugin_id,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)').run(...values,randomUUID().slice(0,8),p.id,now);
    return this.snapshot(p.id);
  }
}
