import {randomUUID} from 'node:crypto';
import {aiInput,chatText,chatCommandAllowed,isChatAdmin} from '../_host/messages.mjs';
import {parameters,validateArguments} from '../_host/schema.mjs';
import {ActivitySchedules} from './management.mjs';

const fail=message=>Object.assign(Error(message),{status:409,retryable:false});
const str=maxLength=>({type:'string',minLength:1,maxLength});
const list=(items,minItems,maxItems)=>({type:'array',items,minItems,maxItems});
export const activitySchema={
  interests:{type:'text',description:'活动兴趣',default:'画画、浏览抖音、探索有趣的主题、整理工作目录中的资料'},
  categories:{type:'list',description:'允许自主选择的工具类别',options:['image','douyin','powershell','desktop'],default:['image','douyin','powershell','desktop']},
  max_selected:{type:'int',description:'每轮最多选择的事项',slider:{min:1,max:3,step:1},default:2},
  timeout_seconds:{type:'int',description:'每轮活动最长秒数',slider:{min:30,max:900,step:1},default:300},
  max_schedules:{type:'int',description:'每个会话最多定时任务',slider:{min:1,max:10,step:1},default:5}
};
export const activityTemplate={schema:1,kind:'free-activity',name:'自由活动',version:'1.1.0',
  description:'说“自由活动”后先列出候选事项，再自主选择一项或多项调用现有工具；支持间隔、每日和延后定时。',
  trigger:'',priority:0,timeout_ms:3000,scope:{private_users:[],groups:[],all_private:false,all_groups:false,require_at:true},
  config:{interests:activitySchema.interests.default,categories:activitySchema.categories.default,max_selected:2,timeout_seconds:300,max_schedules:5},
  config_schema:activitySchema,source:'export default async function(){return null;}',tools:[]};
export const activityHelp='自由活动：现在自主安排一轮\n自由活动：画一张秋天的画\n定时 每隔30分钟 自由活动\n定时 每天20:30 自由活动\n定时 10分钟后 自由活动\n查看自由活动定时\n取消自由活动定时 <编号或全部>\n停止自由活动（同时取消本会话定时）\n时间按北京时间；定时需保持Limen运行。';
const chinese=value=>/^\d+(?:\.\d+)?$/.test(value)?Number(value):({一:1,二:2,两:2,三:3,四:4,五:5,六:6,七:7,八:8,九:9,十:10,半:0.5}[value]??NaN);
function duration(n,unit){return chinese(n)*({秒:1000,分钟:60000,分:60000,小时:3600000}[unit]);}
export function nextDaily(time,now){
  const [hour,minute]=time.split(':').map(Number);
  if(!/^\d{1,2}:\d{2}$/.test(time)||hour>23||minute>59)throw fail('每日时间应为 00:00–23:59。');
  const offset=8*3600000,local=new Date(now+offset),midnight=Date.UTC(local.getUTCFullYear(),local.getUTCMonth(),local.getUTCDate())-offset;
  const at=midnight+hour*3600000+minute*60000;return at>now?at:at+86400000;
}
export function activityIntent(input='',now=Date.now()){
  const text=input.trim().replace(/^(?:请|麻烦你|你可以|你|现在)\s*/u,'');
  if(/^(?:停止|暂停|取消)自由活动[。！!\s]*$/u.test(text)||/^\/free\s+stop$/u.test(text))return {action:'stop'};
  if(/^(?:查看|查询)?自由活动(?:定时|状态|清单)$|^查看定时$|^\/free\s+(?:list|status)$/u.test(text))return {action:'list'};
  const cancel=text.match(/^(?:取消自由活动定时|取消定时|\/free\s+cancel)\s*(\S+)$/u);
  if(cancel)return {action:'cancel',id:cancel[1]};
  if(/^(?:自由活动帮助|\/free(?:\s+help)?|定时)$/u.test(text))return {action:'help'};
  const scheduled=text.replace(/^(?:定时(?:自由活动)?|\/free\s+schedule)\s*[:：]?\s*/u,'');
  if(scheduled===text&&!/自由活动/u.test(text)&&!/^\/free\s+now/u.test(text))return null;
  const number='([0-9]+(?:\\.[0-9]+)?|一|二|两|三|四|五|六|七|八|九|十|半)';
  let m=scheduled.match(new RegExp('^(?:每隔|每)'+number+'(秒|分钟|分|小时)\\s*(.*)$','u'));
  if(m){const interval=duration(m[1],m[2]);return {action:'schedule',mode:'interval',interval_ms:interval,next_at:now+interval,focus:m[3]};}
  m=scheduled.match(/^每天\s*(\d{1,2}:\d{2})\s*(.*)$/u);
  if(m)return {action:'schedule',mode:'daily',daily:m[1],next_at:nextDaily(m[1],now),focus:m[2]};
  m=scheduled.match(new RegExp('^'+number+'(秒|分钟|分|小时)后\\s*(.*)$','u'));
  if(m)return {action:'schedule',mode:'once',next_at:now+duration(m[1],m[2]),focus:m[3]};
  if(scheduled!==text)return {action:'help'};
  const immediate=text.match(/^(?:自由活动(?:一下|一会儿?|吧)?|\/free\s+now)(?:[\s:：，,]+(.*))?[。！!\s]*$/u);
  return immediate?{action:'now',focus:immediate[1]||''}:null;
}
const category=name=>name.startsWith('comfyui_')?'image':/^(?:douyin_web_|video_knowledge_)/.test(name)?'douyin':name==='computer_run_command'?'powershell':/^(?:desktop_|computer_)/.test(name)?'desktop':null;

export class FreeActivity {
  constructor({store,config,plugins,adapter,log}){
    Object.assign(this,{store,config,plugins,adapter,log});this.active=new Map();this.closed=false;
    this.db=store.db;
    this.db.exec(`CREATE TABLE IF NOT EXISTS free_activity_schedules (
      id TEXT PRIMARY KEY,plugin_id TEXT NOT NULL,conversation TEXT NOT NULL,event TEXT NOT NULL,channel TEXT NOT NULL,
      mode TEXT NOT NULL,interval_ms INTEGER NOT NULL,daily TEXT NOT NULL,next_at INTEGER NOT NULL,focus TEXT NOT NULL,
      enabled INTEGER NOT NULL DEFAULT 1,pending_job INTEGER,persona TEXT NOT NULL,created_at INTEGER NOT NULL);
      CREATE TABLE IF NOT EXISTS free_activity_runs (job_id INTEGER PRIMARY KEY,plugin_id TEXT NOT NULL,conversation TEXT NOT NULL,
      plan TEXT,state TEXT NOT NULL,executed TEXT NOT NULL DEFAULT '[]',updated_at INTEGER NOT NULL);`);
    this.db.prepare("UPDATE free_activity_runs SET state='interrupted' WHERE state='running'").run();
    if(!this.db.prepare('PRAGMA table_info(free_activity_schedules)').all().some(c=>c.name==='revision'))this.db.exec('ALTER TABLE free_activity_schedules ADD COLUMN revision INTEGER NOT NULL DEFAULT 1');
    this.management=new ActivitySchedules(this);
  }
  plugin(event,job){return (this.plugins?.rows?.()||[]).find(p=>p.kind==='free-activity'&&p.enabled&&(job.channel==='web'||event.message_type==='private'&&isChatAdmin(event,this.config)&&(p.scope.all_private||p.scope.private_users.includes(String(event.user_id)))))||null;}
  allowed(event,job){return !this.closed&&this.config.ai.enabled&&this.config.agent.enabled&&!!this.plugin(event,job)&&(job.channel==='web'||!!aiInput(event,this.config.ai)&&chatCommandAllowed(event,this.config));}
  start(agent){this.agent=agent;this.timer=setInterval(()=>{try{this.tick();}catch{this.log('warn','free_activity_schedule_failed');}},1000);this.timer.unref();}
  persona(job){const p=this.agent?.state.persona(job.conversation);return JSON.stringify([p?.id||'',p?.revision||0]);}
  control(intent,event,job){
    if(!this.allowed(event,job))return '请先启用自由活动插件，并将当前管理员私聊加入插件及 AI 回复范围。';
    if(intent.action==='cancel'&&job.channel==='web'&&typeof event.free_activity_control_reply==='string')return event.free_activity_control_reply;
    if(intent.action==='help')return activityHelp;
    if(intent.action==='list'){
      const rows=this.db.prepare('SELECT * FROM free_activity_schedules WHERE conversation=? AND enabled=1 ORDER BY next_at').all(job.conversation);
      return rows.map(r=>r.id+' · '+(r.mode==='interval'?'每隔'+r.interval_ms/60000+'分钟':r.mode==='daily'?'每天'+r.daily:'一次')+' · 下次 '+new Date(r.next_at).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai',hour12:false})+' · '+r.focus).join('\n')||'当前会话没有启用的自由活动定时。';
    }
    if(intent.action==='stop'){this.stopConversation(job.conversation);return '已停止本会话自由活动，并取消本会话全部定时。已提交的操作请在任务记录中核对。';}
    if(intent.action==='cancel'){
      const result=intent.id==='全部'||intent.id==='all'?this.db.prepare('UPDATE free_activity_schedules SET enabled=0,revision=revision+1 WHERE conversation=? AND enabled=1').run(job.conversation):this.db.prepare('UPDATE free_activity_schedules SET enabled=0,revision=revision+1 WHERE conversation=? AND id=? AND enabled=1').run(job.conversation,intent.id);
      this.cancelPending(job.conversation);return result.changes?'已取消定时。':'未找到此会话的启用定时。';
    }
    if(intent.action==='schedule')return this.schedule(intent,event,job);
  }
  schedule(intent,event,job){
    const p=this.plugin(event,job),now=Date.now();
    if(!Number.isSafeInteger(intent.next_at)||intent.next_at<=now||intent.next_at>now+366*86400000||intent.mode==='interval'&&(!Number.isSafeInteger(intent.interval_ms)||intent.interval_ms<60000||intent.interval_ms>30*86400000))return '定时间隔最少 1 分钟、最多 30 天；单次延后最多 366 天。';
    if(this.db.prepare('SELECT COUNT(*) AS n FROM free_activity_schedules WHERE conversation=? AND enabled=1').get(job.conversation).n>=p.config.max_schedules)return '本会话定时数量已满，请先取消旧定时。';
    const id=randomUUID().slice(0,8),focus=(intent.focus||'').replace(/^自由活动\s*[:：]?\s*/u,'').slice(0,1000)||'按照兴趣自主选择';
    this.db.prepare('INSERT INTO free_activity_schedules(id,plugin_id,conversation,event,channel,mode,interval_ms,daily,next_at,focus,persona,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)').run(id,p.id,job.conversation,JSON.stringify(event),job.channel||'qq',intent.mode,intent.interval_ms||0,intent.daily||'',intent.next_at,focus,this.persona(job),now);
    return '已创建自由活动定时 '+id+'，下次：'+new Date(intent.next_at).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai',hour12:false})+'（北京时间）。\n取消：取消自由活动定时 '+id;
  }
  cancelPending(conversation){
    const rows=this.db.prepare('SELECT id,pending_job FROM free_activity_schedules WHERE conversation=? AND enabled=0 AND pending_job IS NOT NULL').all(conversation);
    for(const r of rows){const job=this.store.get(r.pending_job);if(job?.status==='queued')this.store.update(job.id,'ignored',{reason:'free_activity_cancelled'});this.active.get(r.pending_job)?.controller.abort(fail('自由活动定时已取消。'));}
  }
  stopConversation(conversation){
    this.db.prepare('UPDATE free_activity_schedules SET enabled=0,revision=revision+1 WHERE conversation=?').run(conversation);this.cancelPending(conversation);
    for(const run of this.active.values())if(run.job.conversation===conversation)run.controller.abort(fail('自由活动已停止。'));
  }
  receive(event,job){
    let intent;try{intent=activityIntent(chatText(event));}catch{return;}
    if(!this.allowed(event,job))return;
    if(intent?.action==='stop')this.stopConversation(job.conversation);
    if(intent?.action==='cancel'){const reply=this.control(intent,event,job);if(job.channel==='web')event.free_activity_control_reply=reply;}
  }
  cancel(pluginId,{preserveSchedules=false}={}){
    const conversations=this.db.prepare('SELECT DISTINCT conversation FROM free_activity_schedules WHERE plugin_id=? AND enabled=1').all(pluginId);
    if(!preserveSchedules){this.db.prepare('UPDATE free_activity_schedules SET enabled=0,revision=revision+1 WHERE plugin_id=?').run(pluginId);for(const row of conversations)this.cancelPending(row.conversation);}
    for(const run of this.active.values())if(run.plugin.id===pluginId)run.controller.abort(fail('自由活动插件已停用或更新。'));
  }
  tick(now=Date.now()){
    if(this.closed)return;
    for(const r of this.db.prepare('SELECT * FROM free_activity_schedules WHERE enabled=1 AND next_at<=? ORDER BY next_at LIMIT 20').all(now)){
      const event=JSON.parse(r.event),job={channel:r.channel,conversation:r.conversation};
      if(!this.allowed(event,job)||this.plugin(event,job).id!==r.plugin_id||this.persona(job)!==r.persona){this.db.prepare('UPDATE free_activity_schedules SET enabled=0,revision=revision+1 WHERE id=?').run(r.id);continue;}
      if(r.channel!=='web'&&!this.adapter.status().online)continue;
      if(this.db.prepare("SELECT 1 FROM jobs WHERE conversation=? AND status IN ('queued','generating','ready','sending','uncertain')").get(r.conversation))continue;
      if(r.mode==='once'&&r.pending_job){
        const pending=this.store.get(r.pending_job);
        if(!pending||!['queued','generating','ready','sending','uncertain'].includes(pending.status))this.db.prepare('UPDATE free_activity_schedules SET enabled=0,revision=revision+1 WHERE id=?').run(r.id);
        continue;
      }
      const next=r.mode==='daily'?nextDaily(r.daily,now):r.mode==='interval'?now+r.interval_ms:r.next_at;
      if(this.db.prepare("SELECT COUNT(*) n FROM jobs WHERE status IN ('queued','generating','ready','sending','uncertain')").get().n>=this.config.maxPending)continue;
      // Advance and enqueue in one transaction; missed intervals collapse into one round.
      this.db.exec('SAVEPOINT free_activity_enqueue');
      try{
        const scheduled={...event,message_id:'free-'+r.id+'-'+r.next_at,free_activity_schedule:r.id,message:[{type:'text',data:{text:'自由活动：'+r.focus}}]};
        const queued=this.store.ingest(scheduled,chatText(scheduled),this.config.maxPending,null,r.channel==='web'?r.conversation.slice(4):null,{eventKey:'free-activity:'+r.id+':'+r.next_at});
        if(queued.inserted&&queued.status==='queued')this.db.prepare('UPDATE free_activity_schedules SET next_at=?,pending_job=? WHERE id=?').run(next,queued.id,r.id);
        this.db.exec('RELEASE free_activity_enqueue');
      }catch(error){this.db.exec('ROLLBACK TO free_activity_enqueue; RELEASE free_activity_enqueue');throw error;}
    }
    this.db.prepare('DELETE FROM free_activity_schedules WHERE enabled=0 AND created_at<? AND (pending_job IS NULL OR pending_job NOT IN (SELECT job_id FROM free_activity_runs WHERE state=?))').run(now-90*86400000,'running');
    this.db.prepare("DELETE FROM free_activity_runs WHERE updated_at<? AND state!='running'").run(now-90*86400000);
  }
  begin(event,job,focus){
    if(!this.allowed(event,job))throw fail('自由活动权限已撤销。');
    if(event.free_activity_schedule){
      const s=this.db.prepare('SELECT * FROM free_activity_schedules WHERE id=? AND pending_job=?').get(event.free_activity_schedule,job.id);
      if(!s||!s.enabled||this.persona(job)!==s.persona)throw fail('定时已取消或人格已变更。');
    }
    if(this.db.prepare('SELECT 1 FROM free_activity_runs WHERE job_id=?').get(job.id))throw fail('此轮自由活动已经执行过，请核对任务记录；未重做。');
    const plugin=this.plugin(event,job),run={event,job,plugin,persona:this.persona(job),controller:new AbortController(),plan:null,executed:[],focus};
    this.db.prepare("INSERT INTO free_activity_runs(job_id,plugin_id,conversation,state,updated_at) VALUES (?,?,?,'running',?)").run(job.id,plugin.id,job.conversation,Date.now());
    this.active.set(job.id,run);return run;
  }
  eligible(run,tools){return tools.filter(t=>run.plugin.config.categories.includes(category(t.name))||['current_time','memory_search'].includes(t.name));}
  planTool(run,available){
    const names=new Set(available.map(t=>t.name));
    const item={...parameters({title:str(120),reason:str(300),tools:list({...str(64),enum:[...names]},1,12)}),required:['title','reason','tools']};
    const schema={...parameters({candidates:list(item,1,6),selected:list({type:'integer',minimum:1,maximum:6},1,run.plugin.config.max_selected)}),required:['candidates','selected']};
    return {name:'free_activity_plan',description:'先构思活动候选清单，再选择一项或多项执行。selected 是从 1 开始的候选序号；tools 只能填写本轮可用工具名。可用工具：'+available.map(t=>t.name+'：'+t.description.slice(0,160)).join('\n'),parameters:schema,effect:'write',invoke:async args=>{
      validateArguments(schema,args);
      if(run.plan)return {result:{ok:false,error:'本轮已经选好活动。'}};
      if(new Set(args.selected).size!==args.selected.length||args.selected.some(n=>n>args.candidates.length)||args.candidates.some(c=>c.tools.some(n=>!names.has(n))))return {result:{ok:false,error:'序号重复、越界或工具不可用，请修正清单。'}};
      run.plan=args;this.db.prepare('UPDATE free_activity_runs SET plan=?,updated_at=? WHERE job_id=?').run(JSON.stringify(args),Date.now(),run.job.id);
      return {result:{ok:true,selected:args.selected.map(i=>args.candidates[i-1]),instruction:'现在调用所选事项的工具，依据真实结果汇报。'}};
    }};
  }
  check(run,name){
    run.controller.signal.throwIfAborted();
    const current=this.plugin(run.event,run.job);
    if(!this.allowed(run.event,run.job)||current?.id!==run.plugin.id||current.revision!==run.plugin.revision)throw fail('自由活动权限或配置已变更。');
    if(this.persona(run.job)!==run.persona)throw fail('自由活动人格已变更。');
    if(run.event.free_activity_schedule&&!this.db.prepare('SELECT 1 FROM free_activity_schedules WHERE id=? AND pending_job=? AND enabled=1').get(run.event.free_activity_schedule,run.job.id))throw fail('自由活动定时已取消。');
    if(name==='free_activity_plan')return null;
    if(!run.plan)return '请先调用 free_activity_plan 生成并选择活动清单。';
    return run.plan.selected.some(i=>run.plan.candidates[i-1].tools.includes(name))?null:'此工具不在本轮所选事项中。';
  }
  record(run,name,outcome){if(name==='free_activity_plan')return;run.executed.push({tool:name,ok:outcome.result?.ok!==false,uncertain:!!outcome.result?.uncertain});this.db.prepare('UPDATE free_activity_runs SET executed=?,updated_at=? WHERE job_id=?').run(JSON.stringify(run.executed),Date.now(),run.job.id);}
  prompt(run){return '\n自由活动任务：用户授权你按兴趣自主安排本轮活动。先构思 2–6 个候选事项，通过 free_activity_plan 选择 1–'+run.plugin.config.max_selected+' 项；只调用所选事项列出的可用工具。兴趣：'+run.plugin.config.interests+'。本轮方向：'+run.focus+'。PowerShell 和桌面可以用于完成这些自主事项，继续遵守本机范围及各工具权限。优先选择能在一轮内完成的小事；先观察再操作，依据结果汇报候选清单、所选事项和未完成部分。不会自动授权发私信、发布内容或修改记忆。生图会进入最后回复阶段，需要与其他工具组合时最后再生图。定时触发是此前用户设置的系统任务，不是用户刚刚发来的新消息。';}
  summary(run,reply){return (run.plan?'活动清单：\n'+run.plan.candidates.map((c,i)=>(run.plan.selected.includes(i+1)?'✓ ':'· ')+c.title).join('\n')+'\n':'')+(run.executed.length?'':'本轮未执行实际工具操作。\n')+reply;}
  end(run,state){this.db.prepare('UPDATE free_activity_runs SET state=?,updated_at=? WHERE job_id=?').run(state,Date.now(),run.job.id);this.active.delete(run.job.id);}
  close(){this.closed=true;clearInterval(this.timer);for(const run of this.active.values())run.controller.abort(fail('自由活动服务已关闭。'));}
}
