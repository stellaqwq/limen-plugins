import { GroupChatPlus } from './service.mjs';
import { groupChatConfig, groupChatTemplate } from './config.mjs';
import { groupChatSchema } from './schema.mjs';
import { GroupChatManagement } from './management.mjs';

export const template = () => groupChatTemplate;
export const config = value => groupChatConfig(value);
export const schema = () => groupChatSchema;

export function create(ctx) {
  const service = new GroupChatPlus({
    store: ctx.store, adapter: ctx.adapter, config: ctx.config, log: ctx.log,
    groupContext: ctx.groupContext, ai: ctx.ai,
    decisionAI: ctx.overrides.groupChatDecisionAI, imageAI: ctx.overrides.groupChatImageAI,
    ...(ctx.overrides.groupChatRandom ? { random: ctx.overrides.groupChatRandom } : {}),
    ...(ctx.overrides.groupChatNow ? { now: ctx.overrides.groupChatNow } : {})
  });
  service.attachments = ctx.attachments;
  service.pluginFor = event => ctx.plugins.find('group-chat-plus', event);
  ctx.plugins.admins.set('groupchat', new GroupChatManagement(ctx.plugins));
  return service;
}

export const run = (service, plugin, event) => service.preview(plugin, event);
