import { applyConfigSchema } from '../_host/config-schema.mjs';

const field = (type, description, value, group, extra = {}) => ({ type, description, default:value, group, ...extra });
const number = (description, value, min, max, group, type = 'int') => field(type, description, value, group, {slider:{min,max,step:type === 'int' ? 1 : 0.01}});
export const livingMemorySchema = {
  auto_summarize:field('bool','自动整理对话',true,'自动记忆'),
  summary_turns:number('每多少轮整理一次',8,2,40,'自动记忆'),
  summary_model:field('string','总结模型（留空使用主模型）','','自动记忆'),
  summary_timeout_ms:number('总结超时（毫秒）',30000,1000,120000,'自动记忆'),
  recall_enabled:field('bool','生成回复前自动召回',true,'记忆召回'),
  recall_top_k:number('每次召回条数',5,1,12,'记忆召回'),
  context_chars:number('记忆注入字符预算',3000,500,8000,'记忆召回'),
  max_memories:number('每个用户及人格最多记忆数',500,10,2000,'生命周期'),
  decay_rate:number('每日重要性衰减率',0.01,0,0.5,'生命周期','float'),
  archive_threshold:number('低于此重要性时归档',0.08,0,0.5,'生命周期','float'),
  default_ttl_days:number('默认有效天数（0 为不设期限）',180,0,3650,'生命周期'),
  source_days:number('原文和待总结对话保留天数',30,1,365,'生命周期'),
  embedding_base_url:field('string','Embedding API 基础地址','','语义检索',{hint:'可选；填写兼容 OpenAI 的 /v1 地址。留空仅使用本地关键词检索。'}),
  embedding_model:field('string','Embedding 模型标识','','语义检索'),
  embedding_api_key:field('string','Embedding API Key','','语义检索',{secret:true}),
  embedding_timeout_ms:number('Embedding 超时（毫秒）',2500,100,10000,'语义检索')
};
export function livingMemoryConfig(value = {}) {
  const c = applyConfigSchema(livingMemorySchema,value);
  if (Object.keys(c).some(key => !Object.hasOwn(livingMemorySchema,key))) throw Object.assign(Error('记忆插件存在未知配置项。'),{status:400});
  if (!!c.embedding_base_url !== !!c.embedding_model) throw Object.assign(Error('Embedding 地址和模型需要同时填写。'),{status:400});
  if (c.embedding_base_url) {
    let url;
    try { url = new URL(c.embedding_base_url); } catch {}
    if (!url || !['http:','https:'].includes(url.protocol) || url.username || url.password || url.search || url.hash) throw Object.assign(Error('Embedding 地址必须是无凭据及查询参数的 HTTP(S) 基础地址。'),{status:400});
  }
  return c;
}
export const livingMemoryTemplate = {
  schema:1,kind:'living-memory',name:'流动记忆 Living Memory',version:'1.1.0',
  description:'参考 LivingMemory 的机制实现：自动总结、中文关键词与可选向量召回、访问强化、衰减归档及 Agent 记忆工具。/lmem help 查看指令。',
  source:'// 内置长期记忆执行层；通过生成前召回和回复后整理接入现有 AI。\n',
  trigger:'',priority:20,timeout_ms:10000,
  scope:{private_users:[],groups:[],all_private:false,all_groups:false,require_at:true},
  config:livingMemoryConfig(),config_schema:livingMemorySchema
};
