import { LivingMemory } from './service.mjs';
import { MemoryManagement } from './management.mjs';
import { livingMemoryConfig, livingMemoryTemplate, livingMemorySchema } from './config.mjs';

export const template = () => livingMemoryTemplate;
export const config = value => livingMemoryConfig(value);
export const schema = () => livingMemorySchema;

export function create(ctx) {
  const service = new LivingMemory({ store: ctx.store, config: ctx.config, log: ctx.log, summaryAI: ctx.overrides.memoryAI });
  service.pluginFor = event => ctx.plugins.find('living-memory', event);
  service.plugins = () => ctx.plugins.rows().filter(row => row.kind === 'living-memory');
  service.managementPlugin = () => ctx.plugins.find('living-memory');
  ctx.plugins.admins.set('memory', new MemoryManagement(ctx.plugins));
  return service;
}

export const run = (service, plugin, event, { dryRun }) => service.handle(plugin, event, { dryRun });
export const destroy = (service, id) => service?.remove?.(id);
