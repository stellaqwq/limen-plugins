import {createHash} from 'node:crypto';
import {conversation} from '../_host/messages.mjs';

const problem=(message,status=400)=>Object.assign(Error(message),{status});
const revision=row=>createHash('sha256').update(JSON.stringify([row.id,row.key,row.content,row.type,row.tags,row.pinned,row.status,row.expires_at,row.updated_at])).digest('hex');
const identity=scope=>{
  const m=/^([1-9]\d{0,15}):(private|group):([1-9]\d{0,15})(?::user:([1-9]\d{0,15}))?$/.exec(scope||'');
  if(!m||m[2]==='group'&&!m[4]||m[2]==='private'&&m[4])throw problem('请选择有效的会话和用户。');
  return {post_type:'message',message_type:m[2],self_id:Number(m[1]),user_id:Number(m[4]||m[3]),...(m[2]==='group'?{group_id:Number(m[3])}:{}),message:[]};
};
export class MemoryManagement {
  constructor(plugins){this.plugins=plugins;this.db=plugins.store.db;}
  get memory(){return this.plugins.service('living-memory');}
  plugin(){return this.plugins.find('living-memory');}
  catalog(plugin){
    if(!plugin)return [];
    const items=new Map(),personas=this.db.prepare('SELECT id,name FROM agent_personas').all();
    const add=(scope,persona='')=>{
      let event;try{event=identity(scope);}catch{return;}
      const key=JSON.stringify([scope,persona]);if(items.has(key))return;
      const session=conversation(event),name=personas.find(p=>p.id===persona)?.name||(persona?'历史人格':'默认人格');
      items.set(key,{scope,persona,conversation:session,persona_name:name,
        label:event.message_type==='group'?'群 '+event.group_id+' · QQ '+event.user_id:'私聊 QQ '+event.user_id,
        account:String(event.self_id),count:0,active:0,archived:0,pending:0});
    };
    const rows=this.db.prepare('SELECT scope,persona,status,COUNT(*) AS n FROM living_memories WHERE plugin_id=? GROUP BY scope,persona,status').all(plugin.id);
    for(const row of rows){add(row.scope,row.persona);const entry=items.get(JSON.stringify([row.scope,row.persona]));if(entry){entry.count+=row.n;entry[row.status==='active'?'active':'archived']+=row.n;}}
    for(const row of this.db.prepare('SELECT scope,persona,COUNT(*) AS n FROM living_memory_turns WHERE plugin_id=? GROUP BY scope,persona').all(plugin.id)){
      add(row.scope,row.persona);const entry=items.get(JSON.stringify([row.scope,row.persona]));if(entry)entry.pending=row.n;
    }
    const account=String(this.plugins.adapter.driver?.account||'');
    if(/^[1-9]\d{0,15}$/.test(account))for(const user of plugin.scope.private_users){const session=account+':private:'+user;add(session,this.memory.personaFor?.(session)||'');}
    // Contact IDs only; no message bodies or third-party group context enter the catalog.
    for(const row of this.db.prepare("SELECT conversation,json_extract(event,'$.user_id') AS user FROM jobs WHERE channel!='web' ORDER BY id DESC LIMIT 2000").all()){
      const session=row.conversation,m=/^([1-9]\d*):(private|group):([1-9]\d*)$/.exec(session);if(!m)continue;
      if(m[2]==='private'&&(plugin.scope.all_private||plugin.scope.private_users.includes(m[3])))add(session,this.memory.personaFor?.(session)||'');
      if(m[2]==='group'&&(plugin.scope.all_groups||plugin.scope.groups.includes(m[3]))&&/^[1-9]\d*$/.test(String(row.user||'')))add(session+':user:'+row.user,this.memory.personaFor?.(session)||'');
    }
    return [...items.values()].sort((a,b)=>b.count-a.count||a.scope.localeCompare(b.scope)||a.persona.localeCompare(b.persona));
  }
  context(scope,persona='',plugin=this.plugin()){
    if(!plugin)throw problem('请先安装流动记忆插件。',409);
    if(typeof persona!=='string'||persona.length>100)throw problem('人格编号无效。');
    if(!this.catalog(plugin).some(item=>item.scope===scope&&item.persona===persona))throw problem('该会话或人格不可用，请重新选择。',404);
    const event=identity(scope),key=JSON.stringify([plugin.id,scope,persona]);
    return {managed:true,plugin,scope,persona,event,session:conversation(event),key,epoch:this.memory.epochs.get(key)||0};
  }
  overview(scope,persona=''){
    const plugin=this.plugin();let scopes=this.catalog(plugin),selected=null,memories=[];
    if(plugin&&scopes.length){
      selected=scope?scopes.find(s=>s.scope===scope&&s.persona===persona):scopes[0];
      if(!selected)throw problem('该会话或人格已不存在，请重新选择。',404);
      const ctx=this.context(selected.scope,selected.persona,plugin);this.memory.maintain(ctx);
      scopes=this.catalog(plugin);selected=scopes.find(s=>s.scope===selected.scope&&s.persona===selected.persona);
      memories=this.memory.rows(ctx).map(row=>({...this.memory.public(row),revision:revision(row),created_at:row.created_at,updated_at:row.updated_at,has_source:!!row.source}));
    }
    return {plugin:plugin?{id:plugin.id,name:plugin.name,enabled:plugin.enabled,revision:plugin.revision,max_memories:plugin.config.max_memories}:null,
      scopes,selected,memories,counts:{total:memories.length,active:memories.filter(m=>m.status==='active').length,archived:memories.filter(m=>m.status==='archived').length}};
  }
  async action(params){
    if(!params||typeof params!=='object'||Array.isArray(params))throw problem('记忆操作参数无效。');
    const plugin=this.plugin();if(!plugin)throw problem('请先安装流动记忆插件。',409);
    if(plugin.revision!==params.plugin_revision)throw problem('插件配置已更新，请刷新后重试。',409);
    const ctx=this.context(params.scope,params.persona??'',plugin);
    const read=()=>this.memory.rows(ctx).find(m=>m.id===params.id);
    let current;
    if(params.id){current=read();if(!current)throw problem('这条记忆已被删除，请刷新。',404);if(revision(current)!==params.revision)throw problem('这条记忆已被更新，草稿已保留。请刷新并核对最新内容。',409);}
    if(['forget','archive','restore'].includes(params.action)){
      if(!current)throw problem('请选择一条记忆。');this.memory.change(ctx,current.id,params.action);return {ok:true};
    }
    if(params.action!=='save')throw problem('未知记忆操作。');
    const value=this.memory.validateMemory({key:params.key,content:params.content,type:params.type,tags:params.tags,importance:current?.importance??1,ttl_days:0},plugin.config);
    const vector=await this.memory.embed(value.key+' '+value.content,plugin.config);
    if(!this.memory.current(ctx))throw problem('插件或会话已更新，请刷新后重试。',409);
    if(current&&(!read()||revision(read())!==params.revision))throw problem('这条记忆已被更新，草稿已保留。请刷新并核对。',409);
    if(!current&&this.memory.rows(ctx).some(m=>m.key===value.key)||current&&this.memory.rows(ctx).some(m=>m.id!==current.id&&m.key===value.key))throw problem('这个记忆名称已存在，请使用其他名称。',409);
    // Editing must invalidate an old summarizer so it cannot overwrite the correction.
    this.memory.invalidate(ctx);ctx.epoch=this.memory.epochs.get(ctx.key)||0;
    this.db.exec('SAVEPOINT memory_admin_save');
    try{
      if(current)this.db.prepare('DELETE FROM living_memory_turns WHERE plugin_id=? AND scope=? AND persona=?').run(plugin.id,ctx.scope,ctx.persona);
      if(current&&current.key!==value.key)this.db.prepare('UPDATE living_memories SET key=? WHERE id=?').run(value.key,current.id);
      const saved=this.memory.put(ctx,value,{manual:current?!!current.pinned:true,vector,source:current?.source?JSON.parse(current.source):null});
      if(current)this.db.prepare('UPDATE living_memories SET status=?,expires_at=?,source_at=? WHERE id=?').run(current.status,current.expires_at,current.source_at,saved.id);
      this.db.exec('RELEASE memory_admin_save');return {ok:true,id:saved.id};
    }catch(error){this.db.exec('ROLLBACK TO memory_admin_save; RELEASE memory_admin_save');throw error;}
  }
}
