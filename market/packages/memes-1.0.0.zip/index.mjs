import { MemeService, memeConfig, memePluginTemplate } from './service.mjs';

export const template = () => memePluginTemplate;
export const config = value => memeConfig(value);

export function create(ctx) {
  const service = new MemeService({ store: ctx.store, adapter: ctx.adapter, config: ctx.config, log: ctx.log });
  service.pluginFor = event => ctx.plugins.find('meme-manager', event);
  return service;
}

export const run = (service, plugin, event, { dryRun }) => service.handle(plugin, event, { dryRun });
