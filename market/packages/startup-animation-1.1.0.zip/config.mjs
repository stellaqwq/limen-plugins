import { applyConfigSchema } from '../_host/config-schema.mjs';

const field = (type, description, value, group, extra = {}) =>
  ({ type, description, default: value, group, ...extra });

export const PRESETS = ['orbit', 'pulse', 'stars', 'curtain'];
export const THEMES = ['ink', 'paper', 'aurora'];
export const EXITS = ['fade', 'rise', 'zoom'];
export const SOURCES = ['preset', 'video'];
export const VIDEO_FITS = ['cover', 'contain'];

export const startupSchema = {
  enabled: field('bool', '显示启动动画', true, '基础', {
    hint: '关闭后工作台直接进入，不播放任何动画；已保存的样式会保留。'
  }),
  source: field('string', '动画来源', 'preset', '基础', {
    options: SOURCES,
    hint: 'preset 使用内置样式；video 播放已上传的本机视频。上传视频后会自动切换到视频。'
  }),
  video_fit: field('string', '视频填充方式', 'cover', '视频', {
    options: VIDEO_FITS,
    hint: 'cover 铺满窗口并裁切边缘；contain 完整显示，留白用底色补齐。'
  }),
  video_loop: field('bool', '视频循环播放', true, '视频', {
    hint: '短片会一直播放到工作台就绪；关闭后播完停在最后一帧，不会忽然变黑。'
  }),
  video_overlay: field('bool', '视频上叠加标题文案', true, '视频', {
    hint: '关闭后只显示视频，适合自带片头文字的素材。'
  }),
  preset: field('string', '动画风格', 'orbit', '外观', {
    options: PRESETS,
    hint: 'orbit 轨道、pulse 涟漪、stars 星屑、curtain 幕启。'
  }),
  theme: field('string', '底色', 'ink', '外观', {
    options: THEMES,
    hint: 'ink 墨黑、paper 纸白、aurora 极光。'
  }),
  accent: field('string', '强调色', '#8b7cf6', '外观', {
    hint: '十六进制颜色，例如 #8b7cf6；用于光环、进度线与标题细节。'
  }),
  title: field('string', '主标题', 'Limen', '文案'),
  subtitle: field('string', '副标题', '信号与回应之间', '文案'),
  caption: field('string', '启动提示', '正在启动本机工作台', '文案', {
    hint: '显示在进度线下方；留空则不显示。'
  }),
  min_ms: field('int', '最短展示时长', 1800, '节奏', {
    slider: { min: 600, max: 8000, step: 100 },
    hint: '毫秒。服务就绪后仍会留出这段时间，避免动画刚开始就被关掉。'
  }),
  exit: field('string', '退出方式', 'fade', '节奏', { options: EXITS }),
  show_progress: field('bool', '显示进度线', true, '细节'),
  skippable: field('bool', '点击任意处跳过', true, '细节'),
  once_per_session: field('bool', '每次会话只播放一次', false, '细节', {
    hint: '同一浏览器会话内刷新页面不再播放；关闭后每次打开工作台都会播放。'
  })
};

const COLOR = /^#[0-9a-f]{6}$/i;
const MAX_TEXT = { title: 24, subtitle: 60, caption: 40 };

// Titles are rendered with an HTML escaper, but rejecting control characters
// here keeps the copy clean and stops newlines from breaking the layout.
function clean(value, label, max) {
  if (typeof value !== 'string') throw Object.assign(Error(label + '必须是文本。'), { status: 400 });
  const text = value.replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim();
  if (text.length > max) throw Object.assign(Error(label + '最多 ' + max + ' 个字。'), { status: 400 });
  return text;
}

export function startupConfig(value = {}) {
  const config = applyConfigSchema(startupSchema, value);
  if (!PRESETS.includes(config.preset)) throw Object.assign(Error('启动动画风格无效。'), { status: 400 });
  if (!THEMES.includes(config.theme)) throw Object.assign(Error('启动动画底色无效。'), { status: 400 });
  if (!EXITS.includes(config.exit)) throw Object.assign(Error('启动动画退出方式无效。'), { status: 400 });
  if (!SOURCES.includes(config.source)) throw Object.assign(Error('启动动画来源无效。'), { status: 400 });
  if (!VIDEO_FITS.includes(config.video_fit)) throw Object.assign(Error('视频填充方式无效。'), { status: 400 });
  if (!COLOR.test(config.accent)) throw Object.assign(Error('强调色必须是 #rrggbb 形式的十六进制颜色。'), { status: 400 });
  if (!Number.isSafeInteger(config.min_ms) || config.min_ms < 600 || config.min_ms > 8000) {
    throw Object.assign(Error('最短展示时长需在 600 到 8000 毫秒之间。'), { status: 400 });
  }
  return {
    ...config,
    accent: config.accent.toLowerCase(),
    title: clean(config.title, '主标题', MAX_TEXT.title),
    subtitle: clean(config.subtitle, '副标题', MAX_TEXT.subtitle),
    caption: clean(config.caption, '启动提示', MAX_TEXT.caption)
  };
}

export const startupTemplate = {
  schema: 1, kind: 'startup-animation', name: '启动动画', version: '1.1.0',
  description: '打开工作台时播放一段自定义启动动画：可用内置样式，也可上传本机视频当片头；风格、底色、标题文案、强调色与过渡节奏都可调整，媒体只保存在数据目录。',
  source: '// 内置启动动画执行层；动画由工作台首屏与插件管理页维护，不处理聊天消息。\n',
  trigger: '', priority: 0, timeout_ms: 1000,
  scope: { private_users: [], groups: [], all_private: false, all_groups: false, require_at: true },
  // The animation never handles chat messages; web_enabled lets the host accept
  // "enable" without a QQ session scope.
  config: { ...startupConfig(), web_enabled: true }, config_schema: startupSchema
};
