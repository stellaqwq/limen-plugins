import { StartupAnimationService } from './service.mjs';
import { StartupAnimationManagement } from './management.mjs';
import { startupConfig, startupTemplate, startupSchema } from './config.mjs';

export const template = () => startupTemplate;
export const config = value => startupConfig(value);
export const schema = () => startupSchema;

// Called by the host after install/save/toggle so the desktop boot snapshot
// follows the saved configuration even when it changes outside this panel.
export const changed = service => service?.syncBoot?.();

export async function setup(ctx) {
  await ctx.plugins.service('startup-animation')?.syncBoot?.();
}

export function create(ctx) {
  const service = new StartupAnimationService({ config: ctx.config, log: ctx.log });
  service.plugins = ctx.plugins;
  ctx.plugins.admins.set('startup-animation', new StartupAnimationManagement(ctx.plugins));
  return service;
}

// Deleting the plugin record removes the uploaded logo too, so a later
// reinstall starts from the built-in mark instead of resurrecting an old file.
// The host does not await this hook, so cleanup stays synchronous.
export const destroy = service => service?.clearSync?.();
