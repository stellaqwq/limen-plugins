import { startupConfig } from './config.mjs';

const fail = (message, status = 400) => Object.assign(Error(message), { status });
const KEYS = ['enabled', 'source', 'video_fit', 'video_loop', 'video_overlay',
  'preset', 'theme', 'accent', 'title', 'subtitle', 'caption', 'min_ms', 'exit',
  'show_progress', 'skippable', 'once_per_session'];

// The workbench only talks to this surface; the plugin owns the optional logo
// and the animation parameters, so no appearance state leaks into settings.
export class StartupAnimationManagement {
  constructor(plugins) { this.plugins = plugins; }
  get service() {
    const service = this.plugins.service('startup-animation');
    if (!service) throw fail('启动动画插件包未安装到 plugins 目录，请重新启动服务。', 409);
    return service;
  }
  plugin() { return this.plugins.find('startup-animation'); }
  snapshot() { return this.service.snapshot(); }
  media() { return this.service.bytes(); }
  video() { return this.service.videoBytes(); }
  /** Uploading a video switches the intro to it right away: no second save is needed. */
  async setSource(source) {
    const plugin = this.plugin();
    if (!plugin || plugin.config?.source === source) return plugin;
    try {
      await this.plugins.save({ id: plugin.id, revision: plugin.revision,
        plugin: { ...plugin, config: { ...plugin.config, source } } });
    } catch { /* The file is already stored; appearance() still falls back safely. */ }
    return this.plugin() || plugin;
  }
  async uploadVideo(bytes, { type, name } = {}) {
    if (!this.plugin()) throw fail('请先安装启动动画插件，再上传视频。', 409);
    if (typeof type === 'string' && type && !/^(?:video\/(?:mp4|webm|x-m4v|quicktime)|application\/octet-stream)$/i.test(type)) {
      throw fail('请选择 MP4 或 WebM 视频。');
    }
    await this.service.writeVideo({ bytes, name });
    await this.setSource('video');
    return this.snapshot();
  }
  async removeVideo() {
    if (!this.plugin()) throw fail('请先安装启动动画插件。', 409);
    await this.setSource('preset');
    await this.service.clearVideo();
    return this.snapshot();
  }
  async action(params = {}) {
    if (params?.action === 'upload-logo') {
      if (!this.plugin()) throw fail('请先安装启动动画插件，再上传 Logo。', 409);
      if (typeof params.data !== 'string' || !/^data:image\/(?:png|jpe?g|webp|gif);base64,[a-z0-9+/=\s]+$/i.test(params.data)) {
        throw fail('请选择 PNG、JPEG、WebP 或 GIF 图片。');
      }
      return this.service.write({ data: params.data });
    }
    if (params?.action === 'remove-logo') {
      if (!this.plugin()) throw fail('请先安装启动动画插件。', 409);
      return this.service.clearLogo();
    }
    if (params?.action === 'remove-video') return this.removeVideo();
    if (params?.action === 'upload-video') {
      throw fail('请通过 /startup-animation/video 上传视频文件。');
    }
    if (params?.action === 'save') {
      const plugin = this.plugin();
      if (!plugin) throw fail('请先安装启动动画插件。', 409);
      const config = { ...plugin.config };
      for (const key of KEYS) if (Object.hasOwn(params, key)) config[key] = params[key];
      // Validate before saving so a forged value never reaches the page renderer.
      startupConfig(config);
      const saved = await this.plugins.save({ id: plugin.id, revision: plugin.revision, plugin: { ...plugin, config } });
      return { ...await this.service.snapshot(), plugin: saved };
    }
    throw fail('启动动画操作不存在。', 404);
  }
}
