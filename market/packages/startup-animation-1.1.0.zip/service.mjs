import { mkdir, readFile, writeFile, readdir, unlink } from 'node:fs/promises';
import { readdirSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { createHash } from 'node:crypto';
import { readImage } from '../_host/image.mjs';
import { PRESETS, THEMES, EXITS, SOURCES, VIDEO_FITS } from './config.mjs';

// The startup animation is local-only: one optional logo, one optional video
// and two small metadata records. Everything else is configuration, so the
// workbench can render the overlay on the first paint without another round trip.
const MIME = { png: 'image/png', jpg: 'image/jpeg', webp: 'image/webp', gif: 'image/gif' };
const EXT = { png: 'png', jpg: 'jpg', webp: 'webp', gif: 'gif' };
const MAX_BYTES = 2 * 1024 * 1024;
const STATE = 'state.json';
// MP4 (ftyp box) and WebM/Matroska (EBML header) are the two containers
// Chromium can play on every supported desktop platform. MOV/AVI are sniffed
// out rather than silently stored as an unplayable intro.
const VIDEO_MIME = { mp4: 'video/mp4', webm: 'video/webm' };
const VIDEO_EXT = { mp4: 'mp4', webm: 'webm' };
const MAX_VIDEO_BYTES = 40 * 1024 * 1024;
const VIDEO_STATE = 'video.json';
const fail = (message, status = 400) => Object.assign(Error(message), { status });

function sniffVideo(bytes) {
  if (bytes.length >= 12 && bytes.subarray(4, 8).toString('latin1') === 'ftyp') return 'mp4';
  if (bytes.length >= 4 && bytes.subarray(0, 4).equals(Buffer.from('1a45dfa3', 'hex'))) return 'webm';
  return null;
}

export class StartupAnimationService {
  constructor({ config, log }) {
    this.log = log;
    this.root = join(config.dataDir, 'startup-animation');
    this.maxBytes = MAX_BYTES;
    this.maxVideoBytes = MAX_VIDEO_BYTES;
    this.state = null;
    this.loading = null;
    this.videoState = null;
    this.videoLoading = null;
    this.queue = Promise.resolve();
    this.bootQueue = Promise.resolve();
  }
  /** Serialize mutations so two uploads cannot leave a record pointing at a pruned file. */
  serial(operation) {
    const task = this.queue.then(operation);
    this.queue = task.catch(() => {});
    return task;
  }
  plugin() { return this.plugins?.find?.('startup-animation') || null; }
  load() {
    if (this.state) return this.state;
    if (!this.loading) this.loading = (async () => {
      try {
        const value = JSON.parse(await readFile(join(this.root, STATE), 'utf8'));
        const usable = MIME[value?.format] && Number.isSafeInteger(value.size) && value.size > 0 &&
          typeof value.hash === 'string' && /^[a-f0-9]{64}$/.test(value.hash);
        this.state = usable ? {
          format: value.format, width: value.width >>> 0, height: value.height >>> 0, size: value.size,
          hash: value.hash, updated_at: Number(value.updated_at) || 0
        } : { format: '' };
      } catch { this.state = { format: '' }; }
      return this.state;
    })();
    return this.loading;
  }
  /** Video metadata lives in its own record so the logo state stays compatible with older installs. */
  loadVideo() {
    if (this.videoState) return this.videoState;
    if (!this.videoLoading) this.videoLoading = (async () => {
      try {
        const value = JSON.parse(await readFile(join(this.root, VIDEO_STATE), 'utf8'));
        const usable = VIDEO_MIME[value?.format] && Number.isSafeInteger(value.size) &&
          value.size > 0 && value.size <= this.maxVideoBytes &&
          typeof value.hash === 'string' && /^[a-f0-9]{64}$/.test(value.hash);
        this.videoState = usable ? {
          format: value.format, size: value.size, hash: value.hash,
          name: typeof value.name === 'string' ? value.name.replace(/[\u0000-\u001f\u007f]/g, ' ').slice(0, 80) : '',
          updated_at: Number(value.updated_at) || 0
        } : { format: '' };
      } catch { this.videoState = { format: '' }; }
      return this.videoState;
    })();
    return this.videoLoading;
  }
  async appearance() {
    const state = await this.load(), videoState = await this.loadVideo(), plugin = this.plugin(), config = plugin?.config || {};
    const logo = state.format ? {
      url: '/startup-animation/media?v=' + state.hash.slice(0, 12), format: state.format,
      width: state.width, height: state.height, size: state.size, updated_at: state.updated_at
    } : null;
    const video = videoState.format ? {
      url: '/startup-animation/video?v=' + videoState.hash.slice(0, 12), format: videoState.format,
      mime: VIDEO_MIME[videoState.format], size: videoState.size, hash: videoState.hash.slice(0, 12),
      name: videoState.name, updated_at: videoState.updated_at
    } : null;
    const title = typeof config.title === 'string' ? config.title : 'Limen';
    const subtitle = typeof config.subtitle === 'string' ? config.subtitle : '信号与回应之间';
    const caption = typeof config.caption === 'string' ? config.caption : '正在启动本机工作台';
    const preset = PRESETS.includes(config.preset) ? config.preset : 'orbit';
    const theme = THEMES.includes(config.theme) ? config.theme : 'ink';
    const exit = EXITS.includes(config.exit) ? config.exit : 'fade';
    const accent = /^#[0-9a-f]{6}$/i.test(config.accent || '') ? config.accent.toLowerCase() : '#8b7cf6';
    const minMs = Number.isSafeInteger(config.min_ms) ? Math.min(8000, Math.max(600, config.min_ms)) : 1800;
    // A deleted or missing video must never leave an empty intro: fall back to
    // the built-in composition rather than showing a blank frame.
    const source = SOURCES.includes(config.source) && config.source === 'video' && video ? 'video' : 'preset';
    const videoFit = VIDEO_FITS.includes(config.video_fit) ? config.video_fit : 'cover';
    const videoLoop = config.video_loop !== false;
    const videoOverlay = config.video_overlay !== false;
    // The signature keys the optional "play once per session" memory, so a
    // replaced video or a changed transition plays again next time.
    const signature = createHash('sha256').update([preset, theme, exit, accent, title, subtitle, caption,
      minMs, config.show_progress !== false, config.skippable !== false, state.hash || '',
      source, videoState.hash || '', videoFit, videoLoop, videoOverlay].join('|'))
      .digest('hex').slice(0, 12);
    return {
      available: true, installed: !!plugin, plugin_enabled: plugin?.enabled === true,
      enabled: !!(plugin?.enabled && config.enabled !== false),
      preset, theme, exit, accent, title, subtitle, caption, min_ms: minMs,
      show_progress: config.show_progress !== false,
      skippable: config.skippable !== false,
      once_per_session: config.once_per_session === true,
      source, video, video_fit: videoFit, video_loop: videoLoop, video_overlay: videoOverlay,
      signature, logo, max_bytes: this.maxBytes, max_video_bytes: this.maxVideoBytes
    };
  }
  async snapshot() {
    const plugin = this.plugin();
    return {
      plugin: plugin ? {
        id: plugin.id, name: plugin.name, enabled: plugin.enabled, revision: plugin.revision, config: plugin.config
      } : null,
      ...await this.appearance()
    };
  }
  /**
   * The Electron main process cannot query the backend before it is up, so the
   * plugin mirrors the current look into a tiny snapshot next to the logo. The
   * desktop window renders that snapshot and the workspace skips its overlay
   * once (the `?boot=1` handoff) so the animation never restarts mid-flight.
   */
  syncBoot() {
    const task = this.bootQueue.then(() => this.writeBoot());
    this.bootQueue = task.catch(() => {});
    return task;
  }
  async writeBoot() {
    try {
      const value = await this.appearance(), state = await this.load(), videoState = await this.loadVideo();
      const record = {
        updated_at: Date.now(), enabled: value.enabled,
        preset: value.preset, theme: value.theme, exit: value.exit, accent: value.accent,
        title: value.title, subtitle: value.subtitle, caption: value.caption,
        min_ms: value.min_ms, show_progress: value.show_progress, signature: value.signature,
        source: value.source, video_fit: value.video_fit, video_loop: value.video_loop, video_overlay: value.video_overlay,
        logo: state.format ? { file: 'logo.' + EXT[state.format], mime: MIME[state.format], hash: state.hash } : null,
        video: videoState.format ? { file: 'video.' + VIDEO_EXT[videoState.format], mime: VIDEO_MIME[videoState.format], hash: videoState.hash } : null
      };
      await mkdir(this.root, { recursive: true });
      await writeFile(join(this.root, 'boot.json'), JSON.stringify(record, null, 2) + '\n');
      return record;
    } catch (error) {
      this.log?.('warn', 'startup_boot_snapshot_failed', { detail: String(error.message).slice(0, 160) });
      return null;
    }
  }
  write({ data } = {}) {
    return this.serial(async () => {
      if (typeof data !== 'string' || data.length > 4 * Math.ceil(this.maxBytes / 3) + 256) {
        throw fail('请选择 PNG、JPEG、WebP 或 GIF 图片，大小不超过 2 MiB。');
      }
      let image;
      try { image = await readImage(data, { maxBytes: this.maxBytes }); }
      catch { throw fail('图片内容无效或超过 2 MiB，请使用 PNG、JPEG、WebP 或 GIF。'); }
      if (!MIME[image.format]) throw fail('Logo 只支持 PNG、JPEG、WebP 或 GIF。');
      const hash = createHash('sha256').update(image.bytes).digest('hex');
      const state = { format: image.format, width: image.width, height: image.height,
        size: image.bytes.length, hash, updated_at: Date.now() };
      await mkdir(this.root, { recursive: true });
      await writeFile(join(this.root, 'logo.' + EXT[image.format]), image.bytes);
      await this.prune(image.format);
      await writeFile(join(this.root, STATE), JSON.stringify(state, null, 2) + '\n');
      this.state = state; this.loading = null;
      this.log?.('info', 'startup_logo_saved', { format: image.format, size: state.size });
      await this.syncBoot();
      return this.snapshot();
    });
  }
  clearLogo() {
    return this.serial(async () => {
      this.state = { format: '' }; this.loading = null;
      await this.prune('').catch(() => {});
      await unlink(join(this.root, STATE)).catch(() => {});
      this.log?.('info', 'startup_logo_cleared');
      await this.syncBoot();
      return this.snapshot();
    });
  }
  /** Store a locally uploaded intro video; bytes arrive raw, never as a base64 JSON string. */
  writeVideo({ bytes, name } = {}) {
    return this.serial(async () => {
      if (!Buffer.isBuffer(bytes) || !bytes.length || bytes.length > this.maxVideoBytes) {
        throw fail('请选择不超过 40 MiB 的 MP4 或 WebM 视频。', 413);
      }
      const format = sniffVideo(bytes);
      if (!format) throw fail('视频内容无效，请使用 MP4（H.264）或 WebM 文件。');
      const hash = createHash('sha256').update(bytes).digest('hex');
      const state = { format, size: bytes.length, hash,
        name: typeof name === 'string' ? name.replace(/[\u0000-\u001f\u007f]/g, ' ').slice(0, 80) : '',
        updated_at: Date.now() };
      await mkdir(this.root, { recursive: true });
      await writeFile(join(this.root, 'video.' + VIDEO_EXT[format]), bytes);
      await this.pruneVideo(format);
      await writeFile(join(this.root, VIDEO_STATE), JSON.stringify(state, null, 2) + '\n');
      this.videoState = state; this.videoLoading = null;
      this.log?.('info', 'startup_video_saved', { format, size: state.size });
      await this.syncBoot();
      return this.snapshot();
    });
  }
  clearVideo() {
    return this.serial(async () => {
      this.videoState = { format: '' }; this.videoLoading = null;
      await this.pruneVideo('').catch(() => {});
      await unlink(join(this.root, VIDEO_STATE)).catch(() => {});
      this.log?.('info', 'startup_video_cleared');
      await this.syncBoot();
      return this.snapshot();
    });
  }
  async pruneVideo(keep = '') {
    let names;
    try { names = await readdir(this.root); } catch { return; }
    const wanted = VIDEO_EXT[keep] ? 'video.' + VIDEO_EXT[keep] : '';
    for (const name of names) {
      if (wanted && name === wanted) continue;
      if (/^video\.(?:mp4|webm)$/.test(name)) await unlink(join(this.root, name)).catch(() => {});
    }
  }
  async videoBytes() {
    const state = await this.loadVideo();
    if (!state.format) throw fail('尚未上传启动视频。', 404);
    let bytes;
    try { bytes = await readFile(join(this.root, 'video.' + VIDEO_EXT[state.format])); }
    catch { throw fail('启动视频文件不存在，请重新上传。', 404); }
    if (bytes.length > this.maxVideoBytes) throw fail('启动视频超过大小限制。', 413);
    if (createHash('sha256').update(bytes).digest('hex') !== state.hash) throw fail('启动视频校验失败，请重新上传。', 409);
    return { bytes, mime: VIDEO_MIME[state.format] };
  }
  /** Same as clearLogo(), for the synchronous plugin-destroy hook. */
  clearSync() {
    this.state = { format: '' }; this.loading = null;
    this.videoState = { format: '' }; this.videoLoading = null;
    try {
      for (const name of readdirSync(this.root)) {
        if (/^(?:state\.json|video\.json|boot\.json|logo\.(?:png|jpg|webp|gif)|video\.(?:mp4|webm))$/.test(name)) rmSync(join(this.root, name), { force: true });
      }
    } catch { /* Nothing stored yet. */ }
  }
  async prune(keep = '') {
    let names;
    try { names = await readdir(this.root); } catch { return; }
    const extension = EXT[keep] || '';
    for (const name of names) {
      if (name === STATE) continue;
      if (extension && name === 'logo.' + extension) continue;
      if (/^logo\.(?:png|jpg|webp|gif)$/.test(name)) await unlink(join(this.root, name)).catch(() => {});
    }
  }
  async bytes() {
    const state = await this.load();
    if (!state.format) throw fail('尚未上传启动动画 Logo。', 404);
    let bytes;
    try { bytes = await readFile(join(this.root, 'logo.' + EXT[state.format])); }
    catch { throw fail('Logo 文件不存在，请重新上传。', 404); }
    if (bytes.length > this.maxBytes) throw fail('Logo 文件超过大小限制。', 413);
    if (createHash('sha256').update(bytes).digest('hex') !== state.hash) throw fail('Logo 文件校验失败，请重新上传。', 409);
    return { bytes, mime: MIME[state.format] };
  }
}
