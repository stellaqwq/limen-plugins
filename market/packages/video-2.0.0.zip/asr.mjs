const fail=message=>Object.assign(Error(message),{status:400});
const round=n=>Math.round(n*1000)/1000;

// Shared, bounded ASR transport for owned video files and captured video audio.
export async function recognizeAudio(c,bytes,{start=0,end,source,name},signal,fetcher=fetch){
  if(!c.asr_url)throw fail('语音转写服务尚未配置。');
  if(bytes.length>20*1048576)throw fail('音轨超过转写大小上限，请缩短时间段。');
  const body=new FormData();body.append('file',new Blob([bytes],{type:'audio/wav'}),'audio.wav');body.append('model',c.asr_model);body.append('response_format',c.asr_format);
  if(c.asr_format==='verbose_json')body.append('timestamp_granularities[]','segment');if(c.asr_language)body.append('language',c.asr_language);
  let response;const timeout=AbortSignal.timeout(c.asr_timeout_seconds*1000),combined=AbortSignal.any([timeout,...(signal?[signal]:[])]);
  try{response=await fetcher(c.asr_url,{method:'POST',body,redirect:'error',headers:c.asr_api_key?{Authorization:'Bearer '+c.asr_api_key}:{},signal:combined});}
  catch{signal?.throwIfAborted();throw fail(timeout.aborted?'语音转写超时。':'无法连接语音转写服务，请检查地址与服务状态。');}
  if(!response.ok){await response.body?.cancel().catch(()=>{});throw fail('语音转写服务返回 HTTP '+response.status+'，请检查配置或切换响应格式；未自动重试。');}
  const chunks=[];let size=0;
  try{for await(const chunk of response.body){combined.throwIfAborted();if((size+=chunk.length)>1048576)throw fail('语音转写响应超过大小限制。');chunks.push(chunk);}}
  catch(error){signal?.throwIfAborted();if(error.status)throw error;throw fail('语音转写响应读取失败或超时。');}
  let data;try{data=JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{throw fail('语音转写服务没有返回有效 JSON。');}
  if(typeof data.text!=='string')throw fail('语音转写服务没有返回文字内容。');
  const segments=[];let length=0,truncated=data.text.length>8000;
  if(data.segments!==undefined&&!Array.isArray(data.segments))throw fail('语音转写分段格式无效。');
  for(const segment of data.segments||[]){
    if(!Number.isFinite(segment.start)||!Number.isFinite(segment.end)||segment.start<0||segment.end<segment.start||segment.end>end-start+0.5||typeof segment.text!=='string')throw fail('语音转写时间戳无效，不能据此生成时间线。');
    if(segments.length>=100||length+segment.text.length>5000){truncated=true;break;}length+=segment.text.length;
    segments.push({start_seconds:round(start+segment.start),end_seconds:round(Math.min(end,start+segment.end)),text:segment.text});
  }
  const result={ok:true,source,name,start_seconds:start,end_seconds:end,text:data.text.slice(0,8000),segments,timestamps:segments.length>0,truncated,note:segments.length?data.timestamp_source==='vad'?'时间戳为 VAD 检测到的语音段边界，非逐词对齐。':'分段时间戳来自语音识别服务。':'服务只返回正文，没有逐句时间戳；不能推测精确发言时间。'};
  while(Buffer.byteLength(JSON.stringify(result))>28000){result.truncated=true;if(result.segments.length)result.segments.pop();else result.text=result.text.slice(0,Math.floor(result.text.length/2));}
  result.timestamps=result.segments.length>0;return {result};
}
