import {readFile,writeFile,mkdir,rename,open} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawn} from 'node:child_process';
import {randomBytes} from 'node:crypto';
import {existsSync} from 'node:fs';
import {setTimeout as delay} from 'node:timers/promises';
import {runtimeDir} from '../../_host/paths.mjs';

export const asrRoot=existsSync(resolve('runtime/asr/settings.json'))?resolve('runtime/asr'):runtimeDir('asr');
export const asrSettings=join(asrRoot,'settings.json');
export async function readLocalASR(){
  let c;try{c=JSON.parse(await readFile(asrSettings,'utf8'));}catch(error){if(error.code==='ENOENT')return null;throw error;}
  if(c.schema!==1||!Number.isSafeInteger(c.port)||c.port<1024||c.port>65535||typeof c.token!=='string'||c.token.length<32||typeof c.python_path!=='string')throw Error('本地 ASR 配置无效。');
  return c;
}
export async function initializeLocalASR(){
  const old=await readLocalASR();if(old)return old;
  await mkdir(asrRoot,{recursive:true});
  const c={schema:1,python_path:join(asrRoot,'venv',process.platform==='win32'?'Scripts/python.exe':'bin/python'),port:8766,token:randomBytes(32).toString('base64url'),threads:2,idle_seconds:300,
    model_path:join(asrRoot,'models/sensevoice/model.int8.onnx'),tokens_path:join(asrRoot,'models/sensevoice/tokens.txt'),vad_path:join(asrRoot,'models/silero_vad.onnx')};
  await writeFile(asrSettings,JSON.stringify(c,null,2)+'\n',{flag:'wx',mode:0o600});return c;
}
export async function localASRRequest(c,path,body){
  const response=await fetch('http://127.0.0.1:'+c.port+path,{method:body===undefined?'GET':'POST',headers:{Authorization:'Bearer '+c.token,'Content-Type':'application/json'},...(body!==undefined?{body:JSON.stringify(body)}:{}),redirect:'error',signal:AbortSignal.timeout(5000)});
  const data=await response.json();if(!response.ok)throw Object.assign(Error('本地 ASR 接口返回 '+response.status),{status:response.status});return data;
}
export async function ensureLocalASR(c){
  try{const status=await localASRRequest(c,'/healthz');if(status.service!=='xuqiao-sensevoice')throw Error('ASR 端口被其他服务占用。');return {reused:true,status};}
  catch(error){if(error.cause?.code!=='ECONNREFUSED')throw error;}
  const log=await open(join(asrRoot,'service.log'),'a');let child;
  try{
    child=spawn(c.python_path,['-I',fileURLToPath(new URL('./server.py',import.meta.url)),'--config',asrSettings],{detached:true,windowsHide:true,stdio:['ignore',log.fd,log.fd],env:{...process.env,PYTHONUNBUFFERED:'1'}});
    let launchError;child.on('error',error=>{launchError=error;});child.unref();
    for(let i=0;i<60;i++){if(launchError)throw launchError;try{const status=await localASRRequest(c,'/healthz');if(status.service==='xuqiao-sensevoice')return {reused:false,status};}catch{}await delay(100);}
    throw Error('本地 ASR 未启动，请检查 runtime/asr/service.log。');
  }finally{await log.close();}
}
export const localVideoPatch=c=>({asr_url:'http://127.0.0.1:'+c.port+'/v1/audio/transcriptions',asr_api_key:c.token,asr_model:'sensevoice-small-int8',asr_language:'auto',asr_format:'verbose_json',asr_timeout_seconds:120});
export async function applyLocalVideo(service,c){
  const old=(await service.list()).plugins.find(p=>p.kind==='video-analysis');
  let plugin=old?await service.get(old.id):await service.install({kind:'video-analysis'});
  plugin=await service.save({id:plugin.id,revision:plugin.revision,plugin:{...plugin,config:{...plugin.config,...localVideoPatch(c)}}});
  if(!old)plugin=await service.toggle({id:plugin.id,revision:plugin.revision,enabled:true});
  return {id:plugin.id,name:plugin.name,enabled:plugin.enabled,model:plugin.config.asr_model,endpoint:plugin.config.asr_url};
}
export async function stageLocalVideo(c,targetDataDir){
  await writeFile(join(asrRoot,'video-setup.pending.json'),JSON.stringify({schema:1,model:'sensevoice-small-int8',target_data_dir:resolve(targetDataDir),requested_at:Date.now()})+'\n',{mode:0o600});
}
export async function consumeLocalVideoSetup(plugins){
  const pending=join(asrRoot,'video-setup.pending.json');
  try{const data=JSON.parse(await readFile(pending,'utf8'));if(data.schema!==1||data.model!=='sensevoice-small-int8'||typeof data.target_data_dir!=='string')throw Error('本地 ASR 安装记录无效。');if(resolve(data.target_data_dir)!==resolve(plugins.config.dataDir))return null;}
  catch(error){if(error.code==='ENOENT')return null;throw error;}
  const c=await readLocalASR();if(!c)throw Error('请先完成本地 ASR 配置。');
  const result=await applyLocalVideo(plugins,c);await rename(pending,join(asrRoot,'video-setup.applied.json'));return result;
}
export async function startConfiguredLocalASR(plugins){
  const c=await readLocalASR();if(!c)return null;
  const plugin=plugins.find('video-analysis');
  if(!plugin?.enabled||plugin.config.asr_url!==localVideoPatch(c).asr_url||plugin.config.asr_api_key!==c.token||plugin.config.asr_model!=='sensevoice-small-int8')return null;
  return ensureLocalASR(c);
}
