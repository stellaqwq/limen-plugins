"""Loopback-only SenseVoice service. Models live in a disposable CPU worker."""
import argparse
import base64
import ctypes
from email.parser import BytesParser
from email.policy import default as email_policy
import hmac
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import io
import json
import os
from pathlib import Path
import queue
import re
import subprocess
import sys
import threading
import time
import wave

MODEL_ID = "sensevoice-small-int8"
MAX_BODY = 5 * 1024 * 1024
MAX_SECONDS = 120


def memory(pid):
    if sys.platform != "win32":
        return {}
    from ctypes import wintypes
    class Counters(ctypes.Structure):
        _fields_ = [("cb", wintypes.DWORD), ("faults", wintypes.DWORD)] + [(name, ctypes.c_size_t) for name in ["peak_working", "working", "peak_paged", "paged", "peak_nonpaged", "nonpaged", "pagefile", "peak_pagefile", "private"]]
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.OpenProcess.restype = wintypes.HANDLE
    kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    process = kernel.OpenProcess(0x0410, False, pid)
    if not process:
        return {}
    try:
        counters = Counters()
        counters.cb = ctypes.sizeof(counters)
        psapi = ctypes.WinDLL("psapi")
        psapi.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.POINTER(Counters), wintypes.DWORD]
        if not psapi.GetProcessMemoryInfo(process, ctypes.byref(counters), counters.cb):
            return {}
        return {"working_set_mib": round(counters.working / 1048576, 1), "private_mib": round(counters.private / 1048576, 1)}
    finally:
        kernel.CloseHandle(process)


def parse_wav(data):
    try:
        with wave.open(io.BytesIO(data), "rb") as audio:
            if audio.getnchannels() != 1 or audio.getsampwidth() != 2 or audio.getframerate() != 16000 or audio.getcomptype() != "NONE":
                raise ValueError("Expected mono 16 kHz PCM16 WAV")
            frames = audio.getnframes()
            if not 0 < frames <= MAX_SECONDS * 16000:
                raise ValueError("Audio duration must be within 120 seconds")
            pcm = audio.readframes(frames)
            if len(pcm) != frames * 2:
                raise ValueError("Incomplete WAV data")
            return pcm, frames / 16000
    except (wave.Error, EOFError) as error:
        raise ValueError("Invalid PCM WAV") from error


def parse_multipart(content_type, body):
    if not content_type.startswith("multipart/form-data;"):
        raise ValueError("Expected multipart/form-data")
    message = BytesParser(policy=email_policy).parsebytes(("Content-Type: " + content_type + "\r\nMIME-Version: 1.0\r\n\r\n").encode("ascii") + body)
    if not message.is_multipart() or message.defects:
        raise ValueError("Invalid multipart body")
    fields = {}
    for part in message.iter_parts():
        name = part.get_param("name", header="content-disposition")
        if name not in ["file", "model", "response_format", "language", "timestamp_granularities[]"] or name in fields:
            raise ValueError("Unexpected or duplicate field")
        value = part.get_payload(decode=True)
        if not isinstance(value, bytes):
            raise ValueError("Invalid multipart value")
        fields[name] = value if name == "file" else value.decode("utf-8", errors="strict")
    if fields.get("model", MODEL_ID) != MODEL_ID:
        raise ValueError("Unknown model")
    if fields.get("response_format", "json") not in ["json", "verbose_json"]:
        raise ValueError("Supported formats: json, verbose_json")
    if fields.get("language", "auto") not in ["", "auto", "zh", "en", "ja", "ko", "yue"]:
        raise ValueError("Unsupported language")
    if fields.get("timestamp_granularities[]", "segment") != "segment" or "file" not in fields:
        raise ValueError("A WAV file and segment granularity are required")
    parse_wav(fields["file"])
    return fields


def worker(config):
    import numpy as np
    import sherpa_onnx
    vad_config = sherpa_onnx.VadModelConfig()
    vad_config.silero_vad.model = config["vad_path"]
    vad_config.silero_vad.threshold = 0.5
    vad_config.silero_vad.min_silence_duration = 0.4
    vad_config.silero_vad.min_speech_duration = 0.2
    vad_config.silero_vad.max_speech_duration = 20
    vad_config.num_threads = 1
    vad_config.provider = "cpu"
    vad_config.sample_rate = 16000
    vad = sherpa_onnx.VoiceActivityDetector(vad_config, buffer_size_in_seconds=MAX_SECONDS + 5)
    recognizer, language = None, None
    print(json.dumps({"ready": True, "worker_pid": os.getpid()}), flush=True)
    for line in sys.stdin:
        try:
            started, cpu_started = time.perf_counter(), time.process_time()
            request = json.loads(line)
            pcm, duration = parse_wav(base64.b64decode(request["wav"], validate=True))
            samples = np.frombuffer(pcm, dtype="<i2").astype(np.float32) / 32768
            padded = np.concatenate([samples, np.zeros(8000, dtype=np.float32)])
            vad.reset()
            for start in range(0, len(padded), 512):
                chunk = padded[start:start + 512]
                if len(chunk) < 512:
                    chunk = np.pad(chunk, (0, 512 - len(chunk)))
                vad.accept_waveform(chunk)
            vad.flush()
            segments, load_seconds = [], 0
            requested_language = request.get("language") or "auto"
            while not vad.empty():
                speech = vad.front
                raw_start, raw_count = speech.start / 16000, len(speech.samples)
                vad.pop()
                # Keep a little context so VAD does not clip initial consonants.
                start = max(0, raw_start - 0.2)
                end = min(duration, raw_start + raw_count / 16000 + 0.1)
                if start >= duration or end <= start:
                    continue
                speech_samples = samples[int(start * 16000):int(end * 16000)]
                if recognizer is None or language != requested_language:
                    loaded_at = time.perf_counter()
                    recognizer = sherpa_onnx.OfflineRecognizer.from_sense_voice(model=config["model_path"], tokens=config["tokens_path"], num_threads=config["threads"], provider="cpu", language=requested_language, use_itn=True, debug=False)
                    language = requested_language
                    load_seconds += time.perf_counter() - loaded_at
                stream = recognizer.create_stream()
                stream.accept_waveform(16000, speech_samples)
                recognizer.decode_stream(stream)
                text = re.sub(r"<\|[^>]+\|>", "", stream.result.text).strip()
                if text and any(character.isalnum() for character in text):
                    segments.append({"start": round(start, 3), "end": round(end, 3), "text": text})
            elapsed = time.perf_counter() - started
            result = {"text": "".join(segment["text"] for segment in segments), "segments": segments, "timestamp_source": "vad", "duration": duration,
                      "metrics": {"elapsed_seconds": round(elapsed, 4), "cpu_seconds": round(time.process_time() - cpu_started, 4), "load_seconds": round(load_seconds, 4), "real_time_factor": round(elapsed / duration, 4), "speech_seconds": round(sum(segment["end"] - segment["start"] for segment in segments), 3), "threads": config["threads"], "provider": "cpu", "model_loaded": recognizer is not None, **memory(os.getpid())}}
            print(json.dumps(result, ensure_ascii=False), flush=True)
        except Exception:
            print(json.dumps({"error": "Local speech recognition failed"}), flush=True)


class ModelManager:
    def __init__(self, config, config_path):
        self.config, self.config_path = config, config_path
        self.process, self.responses, self.actual_pid = None, None, None
        self.lock = threading.Lock()
        self.last_used, self.closed = time.monotonic(), False
        self.metrics = {}
        self.last_error = None
        threading.Thread(target=self.reap, daemon=True).start()

    def start(self):
        if self.process is not None and self.process.poll() is None:
            return
        environment = {**os.environ, "PYTHONUNBUFFERED": "1", "PYTHONIOENCODING": "utf-8", "OMP_NUM_THREADS": str(self.config["threads"]), "OPENBLAS_NUM_THREADS": "1", "MKL_NUM_THREADS": "1"}
        flags = subprocess.CREATE_NO_WINDOW | subprocess.BELOW_NORMAL_PRIORITY_CLASS if sys.platform == "win32" else 0
        self.responses = queue.Queue(maxsize=4)
        self.process = subprocess.Popen([sys.executable, "-I", str(Path(__file__).resolve()), "--config", str(self.config_path), "--worker"], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, encoding="utf-8", env=environment, creationflags=flags, bufsize=1)
        process, responses = self.process, self.responses
        def read():
            try:
                for line in process.stdout:
                    if len(line) > 1048576:
                        break
                    responses.put_nowait(json.loads(line))
            except Exception:
                pass
            finally:
                try:
                    responses.put_nowait({"error": "Worker stopped"})
                except queue.Full:
                    pass
        threading.Thread(target=read, daemon=True).start()
        ready = responses.get(timeout=45)
        if not ready.get("ready"):
            self.stop()
            raise RuntimeError("ASR worker could not start")
        self.actual_pid = int(ready["worker_pid"])

    def stop(self):
        process, self.process = self.process, None
        self.actual_pid = None
        if process is not None:
            if process.poll() is None:
                if sys.platform == "win32":
                    # Windows venv python.exe can be a redirector with a real
                    # Python child. Release that entire owned worker tree.
                    subprocess.run([str(Path(os.environ.get("SystemRoot", "C:/Windows")) / "System32" / "taskkill.exe"), "/PID", str(process.pid), "/T", "/F"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=subprocess.CREATE_NO_WINDOW, timeout=10)
                if process.poll() is None:
                    process.kill()
            process.wait(timeout=10)
            for stream in [process.stdin, process.stdout]:
                if stream:
                    stream.close()

    def decode(self, fields):
        with self.lock:
            if self.closed:
                raise RuntimeError("ASR service is closing")
            try:
                self.start()
                self.process.stdin.write(json.dumps({"wav": base64.b64encode(fields["file"]).decode("ascii"), "language": fields.get("language") or "auto"}) + "\n")
                self.process.stdin.flush()
                result = self.responses.get(timeout=120)
                if "error" in result:
                    raise RuntimeError(result["error"])
                self.metrics = result.get("metrics", {})
                self.last_error = None
                return result
            except Exception as error:
                self.last_error = type(error).__name__
                self.stop()
                raise
            finally:
                self.last_used = time.monotonic()

    def reap(self):
        while not self.closed:
            time.sleep(min(5, self.config["idle_seconds"]))
            if time.monotonic() - self.last_used >= self.config["idle_seconds"] and self.lock.acquire(blocking=False):
                try:
                    self.stop()
                finally:
                    self.lock.release()

    def status(self):
        process = self.process
        loaded = process is not None and process.poll() is None
        return {"ok": True, "service": "xuqiao-sensevoice", "model": MODEL_ID, "provider": "cpu", "threads": self.config["threads"], "worker_loaded": loaded, "worker_pid": self.actual_pid if loaded else None, "idle_seconds": self.config["idle_seconds"], "service_pid": os.getpid(), "service_memory": memory(os.getpid()), "worker_memory": memory(self.actual_pid) if loaded and self.actual_pid else {}, "last_metrics": self.metrics,"last_error":self.last_error}


def serve(config, config_path):
    manager = ModelManager(config, config_path)
    pending = threading.BoundedSemaphore(2)
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def reply(self, code, data):
            encoded = json.dumps(data, ensure_ascii=False).encode("utf-8")
            try:
                self.send_response(code)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(encoded)))
                self.send_header("Cache-Control", "no-store")
                self.send_header("Connection", "close")
                self.end_headers()
                self.wfile.write(encoded)
            except (BrokenPipeError, ConnectionResetError):
                pass
            self.close_connection = True

        def authorized(self):
            expected = "Bearer " + config["token"]
            if self.headers.get("Host") not in ["127.0.0.1:" + str(config["port"]), "localhost:" + str(config["port"])] or self.headers.get("Origin") or not hmac.compare_digest(self.headers.get("Authorization", "").encode(), expected.encode()):
                self.reply(401, {"error": "Unauthorized local ASR request"})
                return False
            return True

        def do_GET(self):
            if self.authorized():
                self.reply(200, manager.status()) if self.path == "/healthz" else self.reply(404, {"error": "Not found"})

        def do_POST(self):
            if not self.authorized():
                return
            if self.path in ["/admin/unload", "/admin/shutdown"]:
                if not manager.lock.acquire(blocking=False):
                    self.reply(409, {"error": "ASR is busy"})
                    return
                try:
                    manager.stop()
                finally:
                    manager.lock.release()
                self.reply(200, {"ok": True, "worker_loaded": False})
                if self.path == "/admin/shutdown":
                    threading.Thread(target=self.server.shutdown, daemon=True).start()
                return
            if self.path != "/v1/audio/transcriptions":
                self.reply(404, {"error": "Not found"})
                return
            if not pending.acquire(blocking=False):
                self.reply(429, {"error": "ASR queue is full"})
                return
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if self.headers.get("Transfer-Encoding") or not 0 < length <= MAX_BODY:
                    raise ValueError("Expected Content-Length within 5 MiB")
                self.connection.settimeout(20)
                body = self.rfile.read(length)
                if len(body) != length:
                    raise ValueError("Incomplete request body")
                fields = parse_multipart(self.headers.get("Content-Type", ""), body)
                result = manager.decode(fields)
                if fields.get("response_format", "json") == "json":
                    result = {"text": result["text"], "metrics": result["metrics"]}
                self.reply(200, result)
            except (ValueError, UnicodeError):
                self.reply(400, {"error": "Expected valid mono 16 kHz PCM16 WAV up to 120 seconds and supported transcription fields"})
            except Exception:
                self.reply(503, {"error": "Local ASR failed or timed out"})
            finally:
                pending.release()
    server = ThreadingHTTPServer(("127.0.0.1", config["port"]), Handler)
    server.daemon_threads = True
    try:
        server.serve_forever(poll_interval=0.5)
    finally:
        manager.closed = True
        server.server_close()
        with manager.lock:
            manager.stop()


def main():
    # Isolated Python (-I) ignores PYTHONIOENCODING; set the pipe protocol
    # explicitly so Windows ANSI codepages cannot corrupt Chinese JSON.
    sys.stdin.reconfigure(encoding="utf-8")
    sys.stdout.reconfigure(encoding="utf-8", write_through=True)
    sys.stderr.reconfigure(encoding="utf-8", write_through=True)
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--worker", action="store_true")
    args = parser.parse_args()
    config = json.loads(args.config.read_text(encoding="utf-8"))
    if not 1 <= config["threads"] <= 2 or not 1 <= config["idle_seconds"] <= 3600 or len(config["token"]) < 32 or not 1024 <= config["port"] <= 65535:
        raise ValueError("Invalid local ASR configuration")
    worker(config) if args.worker else serve(config, args.config.resolve())


if __name__ == "__main__":
    main()
