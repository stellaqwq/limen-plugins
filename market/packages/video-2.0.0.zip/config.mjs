import {applyConfigSchema} from '../_host/config-schema.mjs';
import {parameters} from '../_host/schema.mjs';

const field=(type,description,value,group,hint='',extra={})=>({type,description,default:value,group,hint,...extra});
const number=(description,value,min,max,group,hint='',type='int')=>field(type,description,value,group,hint,{slider:{min,max,step:type==='int'?1:0.1}});
export const videoSchema={
  web_enabled:field('bool','允许网页测试对话',true,'访问范围','启用插件后允许已认证的网页对话使用视频工具，不要求 QQ 在线。'),
  allowed_roots:field('list','允许读取的本地视频目录',['./workspace'],'访问范围','每行一个目录。网页上传及当前 QQ 消息中的受管视频附件独立校验，无需放入这些目录。不下载任意网址。'),
  ffmpeg_path:field('string','FFmpeg 可执行文件路径','','媒体处理','留空时查找 runtime/video-tools/bin 和 PATH。'),
  ffprobe_path:field('string','FFprobe 可执行文件路径','','媒体处理','留空时查找 runtime/video-tools/bin 和 PATH。'),
  max_file_mb:number('本地视频大小上限（MiB）',100,1,1024,'媒体处理','网页及 QQ 附件继续受原有合计 10 MiB 限制；较大视频可放入允许目录。'),
  max_duration_seconds:number('视频总时长上限（秒）',7200,1,86400,'媒体处理'),
  max_segment_seconds:number('单次分析时间段上限（秒）',120,1,600,'媒体处理','长视频按段调用；不自动声称已经分析完整视频。'),
  max_frames:number('单次最多图片帧',8,1,8,'画面抽帧','按模型的多图输入能力调整；帧越多，上下文和请求体越大。'),
  frame_width:number('图片最长边（像素）',960,160,1280,'画面抽帧'),
  interval_seconds:number('默认抽帧间隔（秒）',5,0.2,30,'画面抽帧','默认最多8帧，采样位置通常为0、5、10…35秒；需要细看时缩短间隔。','float'),
  storyboard_cells:number('默认分镜格数',9,1,16,'分镜宫格','多个带编号画面合成一张图片；先看分镜，再用 video_zoom 放大局部。'),
  storyboard_cell_width:number('分镜单格宽度（像素）',320,160,480,'分镜宫格','宫格单格保留原始画面比例，以黑边补齐；小字不清时局部回看。'),
  storyboard_scan:field('bool','分析画面变化辅助选帧',true,'分镜宫格','最多扫描 240 个低分辨率采样点；结果是候选变化位置，不保证检测所有镜头切换。失败时明确降级为均匀覆盖。'),
  process_timeout_seconds:number('媒体处理超时（秒）',30,2,120,'媒体处理'),
  asr_url:field('string','语音转写接口完整地址','','语音转写','例如 http://127.0.0.1:8000/v1/audio/transcriptions。留空时画面功能仍可使用，转写明确提示未配置。音轨仅在调用转写工具时发送到此地址。'),
  asr_api_key:field('string','转写 API Key','','语音转写','独立填写，不会自动使用聊天模型的密钥。',{secret:true}),
  asr_model:field('string','转写模型标识','whisper-1','语音转写','填写转写服务实际提供的模型标识。'),
  asr_language:field('string','转写语言（留空自动）','','语音转写','例如 zh 或 en。'),
  asr_format:field('string','转写响应格式','verbose_json','语音转写','verbose_json 可返回分段时间戳；仅支持普通 JSON 的服务可改为 json，不会虚构逐句时间。',{options:['verbose_json','json']}),
  asr_timeout_seconds:number('转写请求超时（秒）',120,2,240,'语音转写')
};
const fail=message=>Object.assign(Error(message),{status:400});
export function videoConfig(value={}) {
  const c=applyConfigSchema(videoSchema,value);
  if(Object.keys(c).some(k=>!Object.hasOwn(videoSchema,k)))throw fail('视频插件包含未知配置项。');
  if(c.allowed_roots.length>16||c.allowed_roots.some(p=>!p.trim()||p.includes('\0')))throw fail('允许目录最多 16 个，不能为空或含空字符。');
  for(const k of ['ffmpeg_path','ffprobe_path','asr_url','asr_api_key','asr_model','asr_language'])if(/[\r\n\0]/.test(c[k]))throw fail('视频配置不能包含换行或空字符。');
  if(!c.asr_model.trim()||c.asr_language.length>20)throw fail('转写模型或语言无效。');
  if(c.asr_url){let u;try{u=new URL(c.asr_url);}catch{throw fail('转写接口地址无效。');}if(!['http:','https:'].includes(u.protocol)||u.username||u.password||u.hash||u.search)throw fail('转写接口应为无账号密码、查询参数或片段的完整 HTTP(S) 地址。');}
  return c;
}
const source={type:'string',minLength:1,maxLength:2048,description:'允许目录内的视频路径，或当前用户附件提供的 video_ref。留空使用本条消息中的第一个视频附件。不能传任意网址。'};
const seconds={type:'number',minimum:0,maximum:86400};
const args=(properties,required=[])=>({...parameters(properties),required});
export const videoTools=[
  {name:'video_info',effect:'read',description:'读取视频时长、画面尺寸、帧率和音轨信息。分析视频先调用此工具确认可读范围；不代表已看过画面或听过声音。',parameters:args({source})},
  {name:'video_frames',effect:'read',description:'按时间段提取 JPEG 图片并直接提供给视觉模型。返回每帧实际时间戳；依图片顺序分析。只看采样画面，快速动作可能遗漏；需要细看时缩短间隔或换时间段。先用 video_info 查询时长。',parameters:args({source,start_seconds:seconds,end_seconds:seconds,interval_seconds:{type:'number',minimum:0.2,maximum:30},max_frames:{type:'integer',minimum:1,maximum:8}})},
  {name:'video_transcript',effect:'read',description:'提取指定时间段的音轨并交给管理员配置的语音识别服务，返回真实转写及可用时间戳。无音轨、服务未配置或失败时说明原因，不能猜测对白。长视频分段调用。',parameters:args({source,start_seconds:seconds,end_seconds:seconds})},
  {name:'video_storyboard',effect:'read',description:'优先使用：把时间段内多个代表画面拼成一张带格号和实际时间的分镜宫格，保留全段时间覆盖并参考画面变化选帧。返回每格时间范围、可用对白及音量条。默认只看首个允许时间段，按 next_start_seconds 续看。快速动作可能遗漏；细节用 video_zoom。transcript=auto 才上传音轨转写，默认 off。',parameters:args({source,start_seconds:seconds,end_seconds:seconds,cells:{type:'integer',minimum:1,maximum:16},transcript:{type:'string',enum:['off','auto']}})},
  {name:'video_zoom',effect:'read',description:'回看指定起止时间，把较少的画面以更大格子拼图，阅读小字或检查快速变化。必须给出时间段；参考上一张分镜的格号和实际时间。不能凭插值推断连续动作。transcript=auto 时才请求对白转写。',parameters:args({source,start_seconds:seconds,end_seconds:seconds,cells:{type:'integer',minimum:1,maximum:9},transcript:{type:'string',enum:['off','auto']}},['start_seconds','end_seconds'])}
];
export const videoTemplate={schema:1,kind:'video-analysis',name:'视频理解',description:'分镜宫格、局部回看、带实际时间的抽帧和按需对白转写；先看结构，再细看内容。',version:'2.0.0',
  source:'// 内置视频理解执行层 v2；分镜宫格与局部回看，使用 FFmpeg / FFprobe 和可选语音转写服务。\n',trigger:'',priority:0,timeout_ms:10000,
  scope:{private_users:[],groups:[],all_private:false,all_groups:false,require_at:true},config:videoConfig(),config_schema:videoSchema,tools:videoTools};
