import { VideoService } from './service.mjs';
import { videoConfig, videoTemplate, videoSchema, videoTools } from './config.mjs';
import { consumeLocalVideoSetup, startConfiguredLocalASR } from './asr/local.mjs';

export const template = () => videoTemplate;
export const config = value => videoConfig(value);
export const schema = () => videoSchema;
export const tools = () => structuredClone(videoTools);

export function create(ctx) {
  const service = new VideoService({ store: ctx.store, config: ctx.config, attachments: ctx.attachments });
  service.pluginFor = (event, job) => ctx.plugins.find('video-analysis', event, job);
  service.toolName = (plugin, tool) => ctx.plugins.toolName(plugin, tool);
  ctx.attachments.video = service;
  return service;
}

export function visible(plugin, { event, job, host }) {
  if (job?.channel === 'web') return plugin.enabled && !!plugin.config.web_enabled;
  return plugin.enabled && host.matches(plugin, event, true);
}

export async function setup(ctx) {
  const service = ctx.plugins.service('video-analysis');
  ctx.plugins.video = service;
  try { await consumeLocalVideoSetup(ctx.plugins); await startConfiguredLocalASR(ctx.plugins); }
  catch (error) { ctx.log?.('warn', 'local_asr_unavailable', { detail: String(error.message).slice(0, 160) }); }
}
