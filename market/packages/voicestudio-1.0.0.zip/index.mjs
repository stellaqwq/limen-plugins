import { VoiceStudioService, voiceStudioConfig, voiceStudioTemplate } from './service.mjs';

export const template = () => voiceStudioTemplate;
export const config = value => voiceStudioConfig(value);

export function create(ctx) {
  const service = new VoiceStudioService({
    store: ctx.store, config: ctx.config, log: ctx.log,
    memes: ctx.get('meme-manager'), random: ctx.overrides.random
  });
  service.pluginFor = event => ctx.plugins.find('voicestudio', event);
  return service;
}

export const run = (service, plugin, event, { dryRun }) => service.handle(plugin, event, { dryRun });
